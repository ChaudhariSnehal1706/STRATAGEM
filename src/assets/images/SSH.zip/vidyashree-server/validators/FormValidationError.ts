import HttpStatusCode from '../util/http-status-code';

interface ErrorDetails {
  [fieldName: string]: string | string[];
}

export class FormValidationError extends Error {
  status: number;
  errors: ErrorDetails;

  constructor(errors: ErrorDetails) {
    super('Validation failed');
    this.name = 'ValidationError';
    this.status = HttpStatusCode.VALIDATION_ERROR;
    this.errors = errors;
  }
}
