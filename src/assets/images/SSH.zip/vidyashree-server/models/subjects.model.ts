import mongoose, { Schema, Document } from 'mongoose';

export type ISubject = {
  name: string;
  subcategory?: mongoose.Types.ObjectId;
  status: boolean;
  iconurl: string;
  category:mongoose.Types.ObjectId;
  board:mongoose.Types.ObjectId;
};

const SubjectSchema: Schema = new Schema(
  {
    name: { type: String, required: true },
    subcategory: {
      type: Schema.Types.ObjectId,
      ref: 'Subcategory',
      required: true,
    },
    category: {
      type: Schema.Types.ObjectId,
      ref: 'Category',
      required: true
    },
    board: {
      type: Schema.Types.ObjectId,
      ref: 'Board',
      required: true
    },
    status: { type: Boolean, required: true },
    iconurl: { type: String, required: true },
  },
  { timestamps: true }
);

const SubjectModel = mongoose.model<ISubject>('Subject', SubjectSchema);

export { SubjectModel };
