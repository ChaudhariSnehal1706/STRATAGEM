import mongoose, { Schema, Document } from 'mongoose';

export type ICategory = {
  name: string;
  status: boolean;
  iconUrl: string;
  totalTestSeries: number;
};

const CategorySchema: Schema = new Schema(
  {
    name: { type: String, required: true, unique: true },
    status: { type: Boolean, required: true },
    iconUrl: { type: String, required: true },
    totalTestSeries: { type: Number, required: false },
  },
  { timestamps: true }
);

const CategoryModel = mongoose.model<ICategory>('Category', CategorySchema);

export { CategoryModel };
