import mongoose, { Schema, Document } from 'mongoose';

export type ITestSeries = {
  name: string;
  description: string;
  noOfQuestions: number;
  durationMinutes: number;
  maxMarks: number;
  scheduleStartTime: Date;
  scheduleEndTime: Date;
  category?: mongoose.Types.ObjectId;
  status: boolean;
  banner_url: string;
  subcategory?: mongoose.Types.ObjectId;
  featured_flag: boolean;
};

const TestSeriesSchema: Schema = new Schema(
  {
    name: { type: String, required: true },
    noOfQuestions: { type: Number, required: true },
    category: {
      type: Schema.Types.ObjectId,
      ref: 'Category',
      required: true,
    },
    subcategory: {
      type: Schema.Types.ObjectId,
      ref: 'Subcategory',
      required: true,
    },
    banner_url: { type: String, required: true },
    description: { type: String, required: true },
    durationMinutes: { type: Number, required: true },
    maxMarks: { type: Number, required: true },
    scheduleStartTime: { type: Date, required: true },
    scheduleEndTime: { type: Date, required: true },
    status: { type: Boolean, required: true },
    featured_flag: { type: Boolean, required: true },
  },
  { timestamps: true }
);

const TestSeriesModel = mongoose.model<ITestSeries>(
  'TestSeries',
  TestSeriesSchema
);

export { TestSeriesModel };
