import bcrypt from 'bcrypt';
import mongoose, { Document, Schema } from 'mongoose';
import JwtHelper from '../util/jwt-helper';
import otpGenerator from 'otp-generator';

export enum OtpType {
  REGISTER_EMAIL = 'REGISTER_EMAIL',
  REGISTER_MOBILE = 'REGISTER_MOBILE',
  LOGIN_MOBILE = 'LOGIN_MOBILE',
  LOGIN_EMAIL_VERIFY = 'LOGIN_EMAIL_VERIFY',
  FORGET_PASSWORD = 'FORGET_PASSWORD',
  // Add more OTP types as needed
}

interface IAuthToken {
  token: string;
  createdAt: Date;
  expiresAt: Date;
}

interface IOtp {
  type: OtpType;
  value: string;
  expiredAt: Date;
}

interface IStudent extends Document {
  name: string;
  email?: string;
  mobileNumber?: string;
  password?: string;
  otp?: IOtp[];
  isMobileVerified?: boolean;
  isEmailVerified?: boolean;
  category?: mongoose.Types.ObjectId;
  subcategory?: mongoose.Types.ObjectId;
  authTokens?: IAuthToken[];

  // Method to get primary fields
  getPrimaryFields(): IStudentPrimaryFields;
  comparePassword(candidatePassword: string): Promise<boolean>;
  generateAuthToken(): Promise<{ token: string; expiresInMs: number }>;
  generateOtp(type: OtpType): Promise<string>;
  verifyOtp(
    otpValue: string,
    otpType: OtpType,
    dontRemove?: boolean
  ): Promise<boolean>;
}

type IStudentPrimaryFields = Pick<
  IStudent,
  | '_id'
  | 'name'
  | 'email'
  | 'mobileNumber'
  | 'isMobileVerified'
  | 'isEmailVerified'
  | 'category'
  | 'subcategory'
>;

const StudentSchema: Schema<IStudent> = new Schema(
  {
    name: { type: String, required: true },
    email: { type: String },
    mobileNumber: { type: String },
    password: { type: String },
    otp: [
      {
        type: { type: String, enum: Object.values(OtpType) },
        value: { type: String },
        expiredAt: { type: Date },
      },
    ],
    isMobileVerified: { type: Boolean, default: false },
    isEmailVerified: { type: Boolean, default: false },
    category: { type: Schema.Types.ObjectId, ref: 'Category' },
    subcategory: { type: Schema.Types.ObjectId, ref: 'Subcategory' },
    authTokens: [
      new Schema<IAuthToken>({
        token: { type: String },
        createdAt: { type: Date, default: Date.now },
        expiresAt: { type: Date },
      }),
    ],
  },
  { timestamps: true }
);

// Pre-save hook to encrypt password
StudentSchema.pre<IStudent>('save', async function (next) {
  if (!this.isModified('password')) {
    return next();
  }

  const password = this.password;

  if (!password) {
    return next(new Error('Password is required.'));
  }

  try {
    const saltRounds = 10;
    const hashedPassword = await bcrypt.hash(password, saltRounds);
    this.password = hashedPassword;
    next();
  } catch (error: any) {
    next(error);
  }
});

StudentSchema.pre<any>('findOneAndUpdate', async function (next) {
  // Check if the 'password' field is being modified
  if (this._update.password) {
    try {
      const saltRounds = 10;
      const hashedPassword = await bcrypt.hash(
        this._update.password,
        saltRounds
      );
      this._update.password = hashedPassword;
      next();
    } catch (error: any) {
      next(error);
    }
  } else {
    // Password field is not being modified, proceed to next middleware
    next();
  }
});

StudentSchema.methods.comparePassword = async function (
  candidatePassword: string
): Promise<boolean> {
  return bcrypt.compare(candidatePassword, this.password);
};

StudentSchema.methods.generateAuthToken = async function (): Promise<{
  token: string;
  expiresInMs: number;
}> {
  const jwtHelper = new JwtHelper();
  const payload = { _id: this._id };
  const token = jwtHelper.generateToken(payload);

  // Set the expiration time of the token (you can customize this as needed)
  const expiresInMs = jwtHelper.expiresInToMilliseconds();
  const expiresAt = new Date(Date.now() + expiresInMs);

  // Check if there are already 5 tokens in authTokens array
  if (this.authTokens.length >= 5) {
    // Sort tokens by createdAt date in ascending order
    this.authTokens.sort(
      (a: IAuthToken, b: IAuthToken) =>
        a.createdAt.getTime() - b.createdAt.getTime()
    );

    // Remove the oldest token
    this.authTokens.shift();
  }

  // Append the new token with its metadata to the authTokens array
  this.authTokens.push({ token, createdAt: new Date(), expiresAt });

  // Save the document to persist the new token
  await this.save();

  return { token, expiresInMs };
};

StudentSchema.methods.generateOtp = async function (
  otpType: OtpType
): Promise<string> {
  // Generate a random 6-digit OTP
  const otpValue = otpGenerator.generate(6, {
    upperCaseAlphabets: false,
    specialChars: false,
    lowerCaseAlphabets: false,
  });
  const otpExpiration = new Date(Date.now() + 5 * 60 * 1000); // Set OTP expiration to 5 minutes

  // Create an otp object
  const otp: IOtp = {
    type: otpType,
    value: otpValue.toString(),
    expiredAt: otpExpiration,
  };

  const otpObject = (this.otp as IOtp[]).find(otp => otp.type === otpType);
  if (otpObject) {
    const index = this.otp.indexOf(otpObject);
    this.otp.splice(index, 1);
  }

  // Push the otp object into the otp array
  this.otp.push(otp);

  // Save the document to persist the OTP
  await this.save();

  return otpValue;
};

StudentSchema.methods.verifyOtp = async function (
  otpValue: string,
  otpType: OtpType,
  dontRemove?: boolean
): Promise<boolean> {
  // Find the corresponding OTP object in the otp array based on value and type
  const otpObject = (this.otp as IOtp[]).find(
    otp => otp.value === otpValue && otp.type === otpType
  );

  // Check if the OTP object exists and has not expired
  if (otpObject && otpObject.expiredAt > new Date()) {
    if (!dontRemove) {
      const index = this.otp.indexOf(otpObject);
      this.otp.splice(index, 1);

      // Save the document to persist the removal of the OTP object
      await this.save();
    }

    return true; // OTP verification successful
  }

  return false; // OTP verification failed
};

StudentSchema.methods.getPrimaryFields = function (): IStudentPrimaryFields {
  return {
    _id: this._id,
    name: this.name,
    email: this.email,
    mobileNumber: this.mobileNumber,
    isMobileVerified: this.isMobileVerified,
    isEmailVerified: this.isEmailVerified,
    category: this.category,
    subcategory: this.subcategory,
    // Add other primary fields as needed
  };
};

const StudentModel = mongoose.model<IStudent>('Student', StudentSchema);

export { StudentModel };
