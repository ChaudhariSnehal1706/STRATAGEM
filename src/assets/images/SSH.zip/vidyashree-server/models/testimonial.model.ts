import mongoose, { Schema, Document } from 'mongoose';

export type ITestimonial = {
  name: string;
  position: string;
  textContent: string;
  mediaUrl: string;
  mediaType: string;
  status: boolean;
};

const TestimonialSchema: Schema = new Schema(
  {
    name: { type: String, required: true, unique: true },
    status: { type: Boolean, required: true },
    position: { type: String, required: true },
    textContent: { type: String, required: true },
    mediaUrl: { type: String, required: true },
    mediaType: { type: String, required: true },
  },
  { timestamps: true }
);

const TestimonialModel = mongoose.model<ITestimonial>(
  'Testimonial',
  TestimonialSchema
);

export { TestimonialModel };
