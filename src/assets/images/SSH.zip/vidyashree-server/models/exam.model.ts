import mongoose, { Schema, Document } from 'mongoose';

export type IExam = {
  name: string;
};

const ExamSchema: Schema = new Schema(
  {
    name: { type: String, required: true, unique: true },
  },
  { timestamps: true }
);

const ExamModel = mongoose.model<IExam>('Exam', ExamSchema);

export { ExamModel };
