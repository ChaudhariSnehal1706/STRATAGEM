// import { Schema } from "mongoose";

// const mongoose = require('mongoose');
// export type IQuiz = {
//     question: string;
//     options: string[];
//     correctOption: number;
//   };

//   const quizSchema: Schema = new Schema({
//   question: {
//     type: String,
//     required: true
//   },
//   options: {
//     type: [String],
//     required: true
//   },
//   correctOption: {
//     type: Number,
//     required: true
//   }
// },
// { timestamps: true }

// );

// const QuizModel = mongoose.model<IQuiz>('Quiz', quizSchema);
// export{QuizModel}

import mongoose, { Schema } from 'mongoose';

export type IQuiz = {
  question: string;
  options: string[];
  correctOption: string[];
};

const quizSchema: Schema = new Schema(
  {
    question: {
      type: String,
      required: true,
    },
    options: {
      type: [String],
      required: true,
    },
    correctOption: {
      type: [String],
      required: true,
    },
  },
  { timestamps: true }
);

const QuizModel = mongoose.model<IQuiz>('Quiz', quizSchema);

export { QuizModel };
