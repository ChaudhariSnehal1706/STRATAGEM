import mongoose, { Schema } from 'mongoose';

export type IPartner = {
  name: string;
  status: boolean;
  logoURL: string;
};

const PartnerSchema: Schema = new Schema(
  {
    name: { type: String, required: true, unique: true },
    status: { type: Boolean, required: true },
    logoURL: { type: String, required: true },
  },
  { timestamps: true }
);

const PartnerModel = mongoose.model<IPartner>('Partner', PartnerSchema);

export { PartnerModel };
