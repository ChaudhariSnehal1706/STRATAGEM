import mongoose, { Schema } from "mongoose";

export type IQuestion = {
    category:string;
    board:string;
    subcategory:string;
    subject:string;
    chapter:string;
    topic:string;
    status:boolean;
    subTopic:string;
    question:string;
    questionType: mongoose.Types.ObjectId;
    questionLevel: mongoose.Types.ObjectId;
    markingScheme:boolean;
    questionMarks:number;
    questionImage:string;
    referenceTags:string;
    favQuestion:boolean;
    option1:string;
    option2:string;
    option3:string;
    option4:string;
    correctOption:string;
};

const QuestionSchema: Schema = new Schema(
    {
      subcategory: {type: Schema.Types.ObjectId,ref: 'Subcategory',required: true},
      board: { type: Schema.Types.ObjectId, ref: 'Board', required: true },
      category: { type: Schema.Types.ObjectId, ref: 'Category', required: true },
      subject: { type: Schema.Types.ObjectId, ref: 'Subject', required: true },
      chapter: { type: Schema.Types.ObjectId, ref: 'Chapter', required: true },
      topic: { type: Schema.Types.ObjectId, ref: 'Topic', required: true },
      subTopic: { type: Schema.Types.ObjectId, ref: 'SubTopic', required: true },
      question: { type: String, required: true},
      questionType: { type: Schema.Types.ObjectId, ref: 'Questiontype', required: true},
      questionLevel: { type: Schema.Types.ObjectId, ref: 'QuestionLevel', required: true},
      markingScheme: { type:Boolean, required: true},
      questionMarks:{type:Number, required: true},
      questionImage:{ type:String},
      referenceTags: {type:String,required:true},
      favQuestion:{type:Boolean,required:true},
      option1:{type:String, required:true},
      option2:{type:String, required:true},
      option3:{type:String, required:true},
      option4:{type:String, required:true},
      status: { type: Boolean, required: true }, 
      correctOption:{type:String, required:true}
    },
    { timestamps: true }
);

const QuestionModel = mongoose.model<IQuestion>('Question', QuestionSchema);

export { QuestionModel };
  