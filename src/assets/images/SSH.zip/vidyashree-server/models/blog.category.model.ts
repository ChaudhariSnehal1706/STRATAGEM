import mongoose, { Schema } from 'mongoose';

export type IBlogCategory = {
  name: string;
  status: boolean;
};

const BlogCategorySchema: Schema = new Schema(
  {
    name: { type: String, required: true },
    status: { type: Boolean, required: true },
  },
  { timestamps: true }
);

const BlogCategoryModel = mongoose.model<IBlogCategory>(
  'Blog Category',
  BlogCategorySchema
);

export { BlogCategoryModel };
