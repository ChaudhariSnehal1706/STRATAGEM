import mongoose, { Schema } from 'mongoose';

export type IQuestionType = {
  status: boolean;
  type: string;
};

const QuestionTypeSchema: Schema = new Schema(
  {
    type: { type: String, required: true, unique: true },
    status: { type: Boolean, required: true },
  },
  { timestamps: true }
);

const QuestionTypeModel = mongoose.model<IQuestionType>(
  'Questiontype',
  QuestionTypeSchema
);

export { QuestionTypeModel };
