import mongoose, { Schema } from 'mongoose';
export type IBoard = {
  board: string;
  status: boolean;
  category: string;
};

const BoardSchema: Schema = new Schema(
  {
    board: { type: String, required: true, unique: true },
    category: { type: Schema.Types.ObjectId, ref: 'Category', required: true },
    status: { type: Boolean, required: true },
  },
  { timestamps: true }
);

const BoardModel = mongoose.model<IBoard>('Board', BoardSchema);

export { BoardModel };
