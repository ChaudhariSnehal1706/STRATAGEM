import mongoose, { Schema, Document } from 'mongoose';

export type IQuestionLevel = {
  status: boolean;
  level: string;
};

const QuestionLevelSchema: Schema = new Schema(
  {
    level: { type: String, required: true, unique: true },
    status: { type: Boolean, required: true },
  },
  { timestamps: true }
);

const QuestionLevelModel = mongoose.model<IQuestionLevel>(
  'QuestionLevel',
  QuestionLevelSchema
);

export { QuestionLevelModel };
