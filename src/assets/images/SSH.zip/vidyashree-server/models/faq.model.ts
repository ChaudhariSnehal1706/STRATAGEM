import mongoose, { Schema, Document } from 'mongoose';

export type IFaq = {
  title: string;
  category?: mongoose.Types.ObjectId;
  description: string;
};

const Faq: Schema = new Schema(
  {
    title: { type: String, required: true, unique: true },
    description: { type: String, required: true },
    category: {
      type: Schema.Types.ObjectId,
      ref: 'Category',
      required: true,
    },
  },
  { timestamps: true }
);

const FaqModel = mongoose.model<IFaq>('Faq', Faq);

export { FaqModel };
