import mongoose, { Schema, Document } from 'mongoose';

export type IUser = {
  name: string;
  email: string;
  mobile_number: string;
  password: string;
  workExperience?: number;
  areaOfExpertise?: string;
  otp?: number;
  otpExpireAt?: Date;
  isMobileVerified?: boolean;
  isEmailVerified?: boolean;
  referral_code?: string;
  otp_expiration?: Date | null;
  latest_otp?: string | null;
};

const UserSchema: Schema = new Schema(
  {
    name: { type: String, required: true },
    email: { type: String, required: true },
    mobile_number: { type: String, required: false },
    password: { type: String, required: true },
    areaOfExpertise: { type: String, required: false },
    workExperience: { type: Number, required: false },
    otp: { type: Number, required: false },
    otpExpireAt: { type: Date, required: false },
    isMobileVerified: { type: Boolean, required: false },
    isEmailVerified: { type: Boolean, required: false },
    referral_code: { type: String, required: false },
    otp_expiration: { type: Date, required: false },
    latest_otp: { type: String, required: false },
  },
  { timestamps: true }
);

const UserModel = mongoose.model<IUser>('User', UserSchema);

export { UserModel };
