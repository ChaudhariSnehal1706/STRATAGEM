import mongoose, { Schema } from 'mongoose';

export type IBlog = {
  author: string;
  blogDate: Date;
  title: string;
  category?: mongoose.Types.ObjectId;
  content: string;
  tags: string;
  likes: number;
  imageUrl: string;
  slug?: string;
};

const BlogSchema: Schema = new Schema(
  {
    author: { type: String, required: true },
    blogDate: { type: Date, required: true },
    title: { type: String, required: true },
    imageUrl: { type: String, required: true },
    category: {
      type: Schema.Types.ObjectId,
      ref: 'Blog Category',
      required: false,
    },
    content: { type: String, required: true },
    tags: { type: String, required: true },
    likes: { type: Number, required: false },
    slug: { type: String, slug: 'title' },
  },
  { timestamps: true }
);

const BlogModel = mongoose.model<IBlog>('Blog', BlogSchema);

export { BlogModel };
