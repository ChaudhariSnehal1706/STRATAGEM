import mongoose, { Schema, Document } from 'mongoose';

export type IWallOfFame = {
  name: string;
  imageUrl: string;
  rank: string;
  category?: mongoose.Types.ObjectId;
};

const WallOfFameSchema: Schema = new Schema(
  {
    name: { type: String, required: true, unique: true },
    imageUrl: { type: String, required: true },
    rank: { type: String, required: true },
    category: {
      type: Schema.Types.ObjectId,
      ref: 'Category',
      required: true,
    },
  },
  { timestamps: true }
);

const WallOfFameModel = mongoose.model<IWallOfFame>(
  'WallOfFame',
  WallOfFameSchema
);

export { WallOfFameModel };
