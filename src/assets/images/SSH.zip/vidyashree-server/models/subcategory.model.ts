import mongoose, { Schema, Document } from 'mongoose';

export type ISubcategory = {
  name: string;
  category?: mongoose.Types.ObjectId;
  status: boolean;
  board: mongoose.Types.ObjectId; 
};

const SubcategorySchema: Schema = new Schema(
  {
    name: { type: String, required: true },
    category: { type: Schema.Types.ObjectId, ref: 'Category', required: true },
    board: { type: Schema.Types.ObjectId, ref: 'Board', required: true },
    status: { type: Boolean, required: true }
  },
  { timestamps: true }
);

const SubcategoryModel = mongoose.model<ISubcategory>(
  'Subcategory',
  SubcategorySchema
);

export { SubcategoryModel };
