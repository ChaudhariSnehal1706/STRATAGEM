import mongoose, { Schema } from 'mongoose';

export type ISubTopic = {
  category: string;
  board: string;
  subcategory: string;
  subject: string;
  chapter: string;
  topic: string;
  status: boolean;
  subTopic: string;
};

const SubTopicSchema: Schema = new Schema(
  {
    subcategory: {
      type: Schema.Types.ObjectId,
      ref: 'Subcategory',
      required: true,
    },
    board: { type: Schema.Types.ObjectId, ref: 'Board', required: true },
    category: { type: Schema.Types.ObjectId, ref: 'Category', required: true },
    subject: { type: Schema.Types.ObjectId, ref: 'Subject', required: true },
    chapter: { type: Schema.Types.ObjectId, ref: 'Chapter', required: true },
    topic: { type: Schema.Types.ObjectId, ref: 'Topic', required: true },
    subTopic: { type: String, required: true, unique: true },
    status: { type: Boolean, required: true },
  },
  { timestamps: true }
);

const SubTopicModel = mongoose.model<ISubTopic>('SubTopic', SubTopicSchema);

export { SubTopicModel };
