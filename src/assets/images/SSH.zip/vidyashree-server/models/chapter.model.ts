import mongoose, { Schema } from 'mongoose';

export type IChapter = {
  category: string;
  board: string;
  subcategory: string;
  subject: string;
  chapter: string;
  status: boolean;
};

const ChapterSchema: Schema = new Schema(
  {
    subcategory: {
      type: Schema.Types.ObjectId,
      ref: 'Subcategory',
      required: true,
    },
    board: { type: Schema.Types.ObjectId, ref: 'Board', required: true },
    category: { type: Schema.Types.ObjectId, ref: 'Category', required: true },
    subject: { type: Schema.Types.ObjectId, ref: 'Subject', required: true },
    chapter: { type: String, required: true, unique: true },
    status: { type: Boolean, required: true },
  },
  { timestamps: true }
);

const ChapterModel = mongoose.model<IChapter>('Chapter', ChapterSchema);

export { ChapterModel };
