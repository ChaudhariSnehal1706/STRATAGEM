import {
  IsNotEmpty,
  IsString,
  IsEmail,
  Length,
  IsOptional,
  IsBoolean,
  IsBooleanString,
} from 'class-validator';
import 'reflect-metadata';

export class PartnersUpdateDTO {
  @IsOptional()
  @IsString({ message: 'Name must be a string' })
  name!: string;

  @IsOptional()
  @IsBooleanString()
  status!: boolean;

  @IsOptional()
  @IsString({ message: 'Logo URL must be a string' })
  logoURL!: string;
}
