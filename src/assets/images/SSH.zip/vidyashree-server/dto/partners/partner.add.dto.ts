import { IsNotEmpty, IsString, IsOptional } from 'class-validator';
import 'reflect-metadata';

export class PartnersAddDTO {
  @IsNotEmpty({ message: 'Name cannot be empty' })
  @IsString({ message: 'Name must be a string' })
  name!: string;

  @IsOptional()
  @IsString({ message: 'logo url must be a string' })
  logoURL!: string;
}
