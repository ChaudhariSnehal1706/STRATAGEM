import { IsBooleanString, IsOptional, IsString } from 'class-validator';

export class TopicsUpdateDTO {
  @IsString({ message: 'Category must be a string' })
  @IsOptional()
  category!: string;

  @IsOptional()
  @IsString({ message: 'Board must be a string' })
  board!: string;

  @IsOptional()
  @IsString({ message: 'Subcategory must be a string' })
  subcategory!: string;

  @IsString({ message: 'Subject must be a string' })
  @IsOptional()
  subject!: string;

  @IsOptional()
  @IsString({ message: 'Chapter must be a string' })
  chapter!: string;

  @IsString({ message: 'Topic must be a string' })
  @IsOptional()
  topic!: string;

  @IsBooleanString({ message: 'Status must be a boolean' })
  @IsOptional()
  status!: boolean;
}
