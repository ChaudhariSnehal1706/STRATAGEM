import {
  IsNotEmpty,
  IsString,
  IsEmail,
  Length,
  IsOptional,
} from 'class-validator';
import 'reflect-metadata';

export class SubjectsAddDTO {
  @IsNotEmpty({ message: 'Name cannot be empty' })
  @IsString({ message: 'Name must be a string' })
  name!: string;

  @IsNotEmpty({ message: 'Subcategory cannot be empty' })
  @IsString({ message: 'Subcategory must be a string' })
  subcategory!: string;

  @IsString({ message: 'Icon URL must be a string' })
  @IsOptional()
  iconurl!: string;

  @IsNotEmpty({ message: 'Board cannot be empty' })
  @IsString({ message: 'Board must be a string' })
  board!:string;

  @IsNotEmpty({ message: 'Category cannot be empty' })
  @IsString({ message: 'Category must be a string' })
  category!:string
}
