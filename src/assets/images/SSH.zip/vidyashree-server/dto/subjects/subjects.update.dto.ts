import {
  IsNotEmpty,
  IsString,
  IsOptional,
  IsBooleanString
} from 'class-validator';
import 'reflect-metadata';

export class SubjectsUpdateDTO {
  @IsNotEmpty({ message: 'Name cannot be empty' })
  @IsString({ message: 'Name must be a string' })
  name!: string;

  @IsOptional()
  @IsBooleanString({ message: 'Status must be a boolean' })
  status!: boolean;

  @IsOptional()
  @IsString({ message: 'Icon URL must be a string' })
  iconurl!: string;

  @IsOptional()
  @IsString({ message: 'Subcategory must be a string' })
  subcategory!: string;

  @IsOptional()
  @IsString({ message: 'Category must be a string' })
  category!:string;

  @IsOptional()
  @IsString({ message: 'Board must be a string' })
  board!:string
}
