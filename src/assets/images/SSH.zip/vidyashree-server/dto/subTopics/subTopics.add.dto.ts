import { IsNotEmpty, IsString } from 'class-validator';

export class SubTopicsAddDTO {
  @IsString({ message: 'Category must be a string' })
  @IsNotEmpty({ message: 'Category cannot be empty' })
  category!: string;

  @IsNotEmpty({ message: 'Board cannot be empty' })
  @IsString({ message: 'Board must be a string' })
  board!: string;

  @IsNotEmpty({ message: 'Subategory cannot be empty' })
  @IsString({ message: 'Subcategory must be a string' })
  subcategory!: string;

  @IsString({ message: 'Subject must be a string' })
  @IsNotEmpty({ message: 'Subject cannot be empty' })
  subject!: string;

  @IsNotEmpty({ message: 'chapter cannot be empty' })
  @IsString({ message: 'Chapter must be a string' })
  chapter!: string;

  @IsString({ message: 'Topic must be a string' })
  @IsNotEmpty({ message: 'Topic cannot be empty' })
  topic!: string;

  @IsString({ message: 'Sub Topic must be a string' })
  @IsNotEmpty({ message: 'Sub Topic cannot be empty' })
  subTopic!: string;
}
