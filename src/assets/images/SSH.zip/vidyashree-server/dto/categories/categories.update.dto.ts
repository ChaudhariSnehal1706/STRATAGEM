import {
  IsString,
  IsOptional,
  IsBooleanString,
  IsNumberString,
} from 'class-validator';
import 'reflect-metadata';

export class CategoriesUpdateDTO {
  @IsOptional()
  @IsString({ message: 'Name must be a string' })
  name!: string;

  @IsOptional()
  @IsBooleanString({ message: 'Status must be a boolean' })
  status!: boolean;

  @IsOptional()
  @IsString({ message: 'Icon url must be a string' })
  iconUrl!: string;

  @IsOptional()
  @IsNumberString()
  totalTestSeries!: number;
}
