import {
  IsNotEmpty,
  IsString,
  IsEmail,
  Length,
  IsNumber,
  IsOptional,
} from 'class-validator';
import 'reflect-metadata';

export class CategoriesAddDTO {
  @IsNotEmpty({ message: 'Name cannot be empty' })
  @IsString({ message: 'Name must be a string' })
  name!: string;

  @IsOptional()
  @IsString({ message: 'Icon url must be a string' })
  iconUrl!: string;

  // @IsNotEmpty({ message: 'Total test series cannot be empty' })
  @IsOptional()
  @IsNumber()
  totalTestSeries!: number;
}
