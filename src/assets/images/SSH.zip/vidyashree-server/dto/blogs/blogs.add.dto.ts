import {
  IsNotEmpty,
  IsString,
  IsDateString,
  IsNumber,
  IsNumberString,
  IsOptional,
} from 'class-validator';
import 'reflect-metadata';

export class BlogsAddDTO {
  @IsNotEmpty({ message: 'Author cannot be empty' })
  @IsString({ message: 'Author must be a string' })
  author!: string;

  @IsNotEmpty({ message: 'Likes cannot be empty' })
  @IsNumberString()
  likes!: number;

  @IsNotEmpty({ message: 'Date cannot be empty' })
  @IsDateString()
  blogDate!: Date;

  @IsNotEmpty({ message: 'Title cannot be empty' })
  @IsString({ message: 'Title must be a string' })
  title!: string;

  @IsNotEmpty({ message: 'Category cannot be empty' })
  @IsString({ message: 'Category must be a string' })
  category!: string;

  @IsNotEmpty({ message: 'Content cannot be empty' })
  @IsString({ message: 'Content must be a string' })
  content!: string;

  @IsNotEmpty({ message: 'Tags cannot be empty' })
  @IsString({ message: 'Tags must be a string' })
  tags!: string;

  // @IsNotEmpty({ message: 'Image cannot be empty' })
  // image!: any;

  @IsOptional()
  @IsString()
  imageUrl!: string;
}
