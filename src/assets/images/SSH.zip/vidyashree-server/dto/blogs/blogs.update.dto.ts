import {
  IsString,
  IsDateString,
  IsOptional,
  IsNumberString,
  IsNumber,
} from 'class-validator';
import 'reflect-metadata';

export class BlogsUpdateDTO {
  @IsOptional()
  @IsString({ message: 'Author must be a string' })
  author!: string;

  @IsOptional()
  @IsDateString()
  blogDate!: Date;

  @IsOptional()
  @IsString({ message: 'Title must be a string' })
  title!: string;

  @IsOptional()
  @IsString({ message: 'Category must be a string' })
  category!: string;

  @IsOptional()
  @IsString({ message: 'Content must be a string' })
  content!: string;

  @IsOptional()
  @IsString({ message: 'Tags must be a string' })
  tags!: string;

  @IsOptional()
  @IsNumberString()
  likes!: number;

  @IsOptional()
  @IsString()
  imageUrl!: string;
}
