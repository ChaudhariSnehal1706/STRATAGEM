import { IsArray, IsBoolean, IsBooleanString, IsNotEmpty, IsNumber, IsNumberString, IsOptional, IsString } from "class-validator";

export default class QuestionsAddDto {
    @IsString({message:'Question must be a string'})
    @IsNotEmpty({message:'Question must not be empty'})
    question!:string;

    @IsString({message:'Category must be a string'})
    @IsNotEmpty({message:'Category must not be empty'})
    category!:string;

    @IsString({message:'Sub Category must be a string'})
    @IsNotEmpty({message:'Sub Category must not be empty'})
    subcategory!:string;

    @IsString({message:'Board must be a string'})
    @IsNotEmpty({message:'Board must not be empty'})
    board!:string;

    @IsString({message:'Subject must be a string'})
    @IsNotEmpty({message:'Subject must not be empty'})
    subject!:string;

    @IsString({message:'Topic must be a string'})
    @IsNotEmpty({message:'Topic must not be empty'})
    topic!:string;

    @IsString({message:'Chapter must be a string'})
    @IsNotEmpty({message:'Chapter must not be empty'})
    chapter!:string;

    @IsString({message:'Sub Topic must be a string'})
    @IsNotEmpty({message:'Sub Topic must not be empty'})
    subTopic!:string;
    
    @IsString({message:'Question Level must be a string'})
    @IsNotEmpty({message:'Question Level must not be empty'})
    questionLevel!:string;

    @IsString({message:'Question Type must be a string'})
    @IsNotEmpty({message:'Question Type must not be empty'})
    questionType!:string;

    @IsNumberString()
    @IsNotEmpty({message:'Question marks must not be empty'})
    questionMarks!:number;

    @IsString({message:'Question Image must be a string'})
    //@IsNotEmpty({message:'Question Image must not be empty'})
    @IsOptional()
    questionImage!:string;

    @IsBooleanString({message:'Marking scheme must be a boolean'})
    @IsNotEmpty({message:'Marking scheme must not be empty'})
    markingScheme!:boolean;

    @IsString({message:'Reference Tags must be a string'})
    @IsNotEmpty({message:'Reference Tags must not be empty'})
    referenceTags!:string;

    @IsBooleanString({message:'Favourite question must be a boolean'})
    @IsNotEmpty({message:'Favourite question must not be empty'})
    favQuestion!:boolean;

    @IsString({message:'Options must be a string'})
    @IsNotEmpty({message:'Options must not be empty'})
    option1!:string;

    @IsString({message:'Options must be a string'})
    @IsNotEmpty({message:'Options must not be empty'})
    option2!:string;

    @IsString({message:'Options must be a string'})
    @IsNotEmpty({message:'Options must not be empty'})
    option3!:string;

    @IsString({message:'Options must be a string'})
    @IsNotEmpty({message:'Options must not be empty'})
    option4!:string;

    @IsNotEmpty({message:'Correct Option must not be empty'})
    @IsString({message:'Correct Option must be a string'})
    correctOption!:string;

}