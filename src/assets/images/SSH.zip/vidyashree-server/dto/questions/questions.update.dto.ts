import { IsBoolean, IsBooleanString, IsNumberString, IsOptional, IsString } from "class-validator";

export default class QuestionsUpdateDto {
    @IsString({message:'Question must be a string'})
    @IsOptional()
    question!:string;

    @IsString({message:'Category must be a string'})
    @IsOptional()
    category!:string;

    @IsString({message:'Sub Category must be a string'})
    @IsOptional()
    subcategory!:string;

    @IsString({message:'Board must be a string'})
    @IsOptional()
    board!:string;

    @IsString({message:'Subject must be a string'})
    @IsOptional()
    subject!:string;

    @IsString({message:'Topic must be a string'})
    @IsOptional()
    topic!:string;

    @IsString({message:'Chapter must be a string'})
    @IsOptional()
    chapter!:string;

    @IsString({message:'Sub Topic must be a string'})
    @IsOptional()
    subTopic!:string;
    
    @IsString({message:'Question Level must be a string'})
    @IsOptional()
    questionLevel!:string;

    @IsString({message:'Question Type must be a string'})
    @IsOptional()
    questionType!:string;

    @IsNumberString()
    @IsOptional()
    questionMarks!:number;

    @IsString({message:'Question Image must be a string'})
    @IsOptional()
    questionImage!:string;

    @IsBooleanString({message:'Marking scheme must be a boolean'})
    @IsOptional()
    markingScheme!:boolean;

    @IsString({message:'Reference Tags must be a string'})
    @IsOptional()
    referenceTags!:string;

    @IsBooleanString({message:'Favourite question must be a string'})
    @IsOptional()
    favQuestion!:boolean;

    @IsOptional()
    @IsString({message:'Options must not be empty'})
    option1!:string;

    @IsOptional()
    @IsString({message:'Options must not be empty'})
    option2!:string;

    @IsOptional()
    @IsString({message:'Options must not be empty'})
    option3!:string;

    @IsOptional()
    @IsString({message:'Options must not be empty'})
    option4!:string;

    @IsOptional()
    @IsBooleanString({message:'status must be a boolean'})
    status!: boolean;

    @IsOptional()
    @IsString({message:'Correct Option must be a string'})
    correctOption!:string;
}