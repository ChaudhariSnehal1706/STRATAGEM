//level

import { IsBooleanString, IsOptional, IsString } from 'class-validator';

//status
export class QuestionsLevelUpdateDTO {
  @IsString({ message: 'Level name must be string' })
  @IsOptional()
  level!: string;

  @IsBooleanString({ message: 'Status must be boolean' })
  @IsOptional()
  status!: boolean;
}
