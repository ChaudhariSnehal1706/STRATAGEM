//level

import { IsNotEmpty, IsString } from 'class-validator';

//status
export class QuestionsLevelAddDTO {
  @IsString({ message: 'Level name must be string' })
  @IsNotEmpty({ message: 'Level name cannot be empty' })
  level!: string;
}
