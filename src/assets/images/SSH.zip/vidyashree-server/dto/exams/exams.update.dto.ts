import {
  IsNotEmpty,
  IsString,
  IsEmail,
  Length,
  IsOptional,
  IsBoolean,
} from 'class-validator';
import 'reflect-metadata';

export class ExamsUpdateDTO {
  @IsOptional()
  @IsString({ message: 'Name must be a string' })
  name!: string;

  @IsOptional()
  @IsBoolean()
  status!: boolean;
}
