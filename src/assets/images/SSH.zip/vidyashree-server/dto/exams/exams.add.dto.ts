import { IsNotEmpty, IsString, IsEmail, Length } from 'class-validator';
import 'reflect-metadata';

export class ExamsAddDTO {
  @IsNotEmpty({ message: 'Name cannot be empty' })
  @IsString({ message: 'Name must be a string' })
  name!: string;
}
