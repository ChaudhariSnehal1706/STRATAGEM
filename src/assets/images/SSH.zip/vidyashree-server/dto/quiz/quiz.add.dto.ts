import { IsNotEmpty, IsNumberString, IsString } from 'class-validator';

export class QuizAddDTO {
  @IsNotEmpty()
  @IsString()
  question!: string;

  @IsNotEmpty()
  options!: string[];

  @IsNotEmpty()
  correctOption!: string[];
}
