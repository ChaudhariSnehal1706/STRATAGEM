import {
  IsString,
  IsOptional,
  IsNumberString,
  IsArray,
  ArrayMinSize,
  ArrayMaxSize,
} from 'class-validator';
import 'reflect-metadata';

export class QuizUpdateDTO {
  @IsOptional()
  @IsString()
  question!: string;

  @IsOptional()
  @IsArray()
  @ArrayMinSize(2)
  @ArrayMaxSize(4)
  options!: string[];

  @IsOptional()
  @IsString()
  correctOption!: string[];
}
