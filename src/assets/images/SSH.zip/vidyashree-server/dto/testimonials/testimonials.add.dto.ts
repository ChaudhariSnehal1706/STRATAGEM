import {
  IsNotEmpty,
  IsString,
  IsEmail,
  Length,
  IsBoolean,
} from 'class-validator';
import 'reflect-metadata';

export class TestimonialsAddDTO {
  @IsNotEmpty({ message: 'Name cannot be empty' })
  @IsString({ message: 'Name must be a string' })
  name!: string;

  @IsNotEmpty({ message: 'Position cannot be empty' })
  @IsString({ message: 'Position must be a string' })
  position!: string;

  @IsNotEmpty({ message: 'Content cannot be empty' })
  @IsString({ message: 'Content must be a string' })
  textContent!: string;

  @IsNotEmpty({ message: 'Content cannot be empty' })
  @IsString({ message: 'Content must be a string' })
  mediaUrl!: string;

  @IsNotEmpty({ message: 'Content cannot be empty' })
  @IsString({ message: 'Content must be a string' })
  mediaType!: string;
}
