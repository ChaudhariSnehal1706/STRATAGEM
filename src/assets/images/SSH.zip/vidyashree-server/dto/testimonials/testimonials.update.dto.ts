import {
  IsNotEmpty,
  IsString,
  IsEmail,
  Length,
  IsBooleanString,
  IsOptional,
} from 'class-validator';
import 'reflect-metadata';

export class TestimonialsUpdateDTO {
  @IsOptional()
  @IsString({ message: 'Name must be a string' })
  name!: string;

  @IsOptional()
  @IsBooleanString({ message: 'status must be a boolean' })
  status!: boolean;

  @IsOptional()
  @IsString({ message: 'Position must be a string' })
  position!: string;

  @IsOptional()
  @IsString({ message: 'Content must be a string' })
  textContent!: string;

  @IsOptional()
  @IsString({ message: 'URL must be a string' })
  mediaUrl!: string;

  @IsOptional()
  @IsString({ message: 'Media type must be a string' })
  mediaType!: string;
}
