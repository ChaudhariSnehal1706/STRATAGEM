import {
  IsNotEmpty,
  IsString,
  IsEmail,
  Length,
  IsBoolean,
} from 'class-validator';
import 'reflect-metadata';

export class faqAddDTO {
  @IsNotEmpty({ message: 'Title cannot be empty' })
  @IsString({ message: 'Title must be a string' })
  title!: string;

  @IsNotEmpty({ message: 'Description cannot be empty' })
  @IsString({ message: 'Description must be a string' })
  description!: string;

  @IsNotEmpty({ message: 'Category cannot be empty' })
  @IsString({ message: 'Category must be a string' })
  category!: string;
}
