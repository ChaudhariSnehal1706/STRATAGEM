import {
  IsNotEmpty,
  IsString,
  IsEmail,
  Length,
  IsOptional,
  IsBoolean,
  IsBooleanString,
} from 'class-validator';
import 'reflect-metadata';

export class FaqUpdateDTO {
  @IsOptional()
  @IsString({ message: 'title must be a string' })
  title!: string;

  @IsOptional()
  @IsString()
  description!: string;

  @IsOptional()
  @IsString({ message: 'Logo URL must be a string' })
  category!: string;
}
