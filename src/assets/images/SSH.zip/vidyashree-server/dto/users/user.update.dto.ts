import { IsString, IsEmail, IsOptional, IsMobilePhone } from 'class-validator';
import 'reflect-metadata';

export class UserUpdateDTO {
  @IsOptional()
  @IsString({ message: 'Name must be a string' })
  name!: string;

  @IsOptional()
  @IsEmail({}, { message: 'Invalid email format' })
  email!: string;

  @IsOptional()
  @IsString({ message: 'Password must be a string' })
  password!: string;

  @IsOptional()
  @IsMobilePhone()
  mobile_number!: string;
}
