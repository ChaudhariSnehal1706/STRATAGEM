import {
  IsNotEmpty,
  IsString,
  IsEmail,
  Length,
  IsMobilePhone,
} from 'class-validator';
import 'reflect-metadata';

export class UserAddDTO {
  @IsNotEmpty({ message: 'Name cannot be empty' })
  @IsString({ message: 'Name must be a string' })
  @Length(2, 50, { message: 'Name must be between 2 and 50 characters' })
  name!: string;

  @IsNotEmpty({ message: 'Email cannot be empty' })
  @IsEmail({}, { message: 'Invalid email format' })
  email!: string;

  @IsNotEmpty({ message: 'Password cannot be empty' })
  @IsString({ message: 'Password must be a string' })
  password!: string;

  // @IsNotEmpty({ message: 'Password cannot be empty' })
  // @IsString({ message: 'Password must be a string' })
  // category!: string;

  // @IsNotEmpty({ message: 'Password cannot be empty' })
  // @IsString({ message: 'Password must be a string' })
  // subject!: string;

  @IsNotEmpty({ message: 'Mobile Number cannot be empty' })
  @IsMobilePhone()
  mobile_number!: string;
}
