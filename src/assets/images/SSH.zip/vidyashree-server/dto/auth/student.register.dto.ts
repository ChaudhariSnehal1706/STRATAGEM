import {
  IsEmail,
  IsMobilePhone,
  IsNotEmpty,
  IsOptional,
  IsString,
  Length,
} from 'class-validator';
import 'reflect-metadata';

export class StudentRegisterDTO {
  @IsNotEmpty({ message: 'Name cannot be empty' })
  @IsString({ message: 'Name must be a string' })
  @Length(2, 50, { message: 'Name must be between 2 and 50 characters' })
  name!: string;

  @IsNotEmpty({ message: 'Email cannot be empty' })
  @IsEmail({}, { message: 'Invalid email format' })
  email!: string;

  @IsNotEmpty({ message: 'Password cannot be empty' })
  @IsString({ message: 'Password must be a string' })
  password!: string;

  // @IsOptional()
  // @ValidateIf(o => !!o.last)
  @IsNotEmpty()
  @IsMobilePhone(
    undefined,
    {},
    { message: 'Invalid mobile number format', always: false }
  )
  mobileNumber!: string;

  @IsNotEmpty({ message: 'Category cannot be empty' })
  @IsString({ message: 'Category must be a string' })
  category!: string;

  @IsNotEmpty({ message: 'Subcategory cannot be empty' })
  @IsString({ message: 'Subcategory must be a string' })
  subcategory!: string;
}

export class StudentRegisterOtpVerifyDTO {
  @IsNotEmpty({ message: 'Email cannot be empty' })
  @IsEmail({}, { message: 'Invalid email format' })
  email!: string;

  @IsNotEmpty({ message: 'Id cannot be empty' })
  @IsString({ message: 'Id must be a string' })
  studentId!: string;

  @IsNotEmpty({ message: 'OTP cannot be empty' })
  @IsString({ message: 'OTP must be a string' })
  otp!: string;
}

export class StudentLoginDTO {
  @IsNotEmpty({ message: 'Email cannot be empty' })
  @IsEmail({}, { message: 'Invalid email format' })
  email!: string;

  @IsNotEmpty({ message: 'Password cannot be empty' })
  @IsString({ message: 'Password must be a string' })
  password!: string;

  @IsOptional()
  @IsString({ message: 'OTP must be a string' })
  otp?: string;
}

export class StudentLoginOtpDTO {
  @IsNotEmpty()
  @IsMobilePhone(
    undefined,
    {},
    { message: 'Invalid mobile number format', always: false }
  )
  mobileNumber!: string;
}

export class StudentLoginMobileDTO extends StudentLoginOtpDTO {
  @IsNotEmpty({ message: 'OTP cannot be empty' })
  @IsString({ message: 'OTP must be a string' })
  otp!: string;
}

export class ForgetPasswordRequestOtpDTO {
  @IsNotEmpty({ message: 'Email or mobile number cannot be empty' })
  @IsString({ message: 'Email or mobile number must be a string' })
  emailOrMobileNumber!: string;
}

export class ForgetPasswordVerifyOtpDTO {
  @IsNotEmpty({ message: 'Email or mobile number cannot be empty' })
  @IsString({ message: 'Email or mobile number must be a string' })
  emailOrMobileNumber!: string;

  @IsNotEmpty({ message: 'OTP cannot be empty' })
  @IsString({ message: 'OTP must be a string' })
  otp!: string;
}

export class ResetPasswordDTO {
  @IsNotEmpty({ message: 'Email or mobile number cannot be empty' })
  @IsString({ message: 'Email or mobile number must be a string' })
  emailOrMobileNumber!: string;

  @IsNotEmpty({ message: 'OTP cannot be empty' })
  @IsString({ message: 'OTP must be a string' })
  otp!: string;

  @IsNotEmpty({ message: 'New password cannot be empty' })
  @IsString({ message: 'New password must be a string' })
  newPassword!: string;
}
