import { IsString, IsOptional, IsBooleanString } from 'class-validator';
import 'reflect-metadata';

export class BlogsCategoryUpdateDTO {
  @IsOptional()
  @IsString({ message: 'Author must be a string' })
  categoryName!: string;

  @IsOptional()
  @IsBooleanString()
  status!: boolean;
}
