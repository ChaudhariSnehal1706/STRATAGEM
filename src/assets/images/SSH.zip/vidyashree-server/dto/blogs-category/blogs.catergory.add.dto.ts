import { IsNotEmpty, IsString, IsBooleanString } from 'class-validator';
import 'reflect-metadata';

export class BlogsCategoryAddDTO {
  @IsNotEmpty({ message: 'Author cannot be empty' })
  @IsString({ message: 'Author must be a string' })
  categoryName!: string;
}
