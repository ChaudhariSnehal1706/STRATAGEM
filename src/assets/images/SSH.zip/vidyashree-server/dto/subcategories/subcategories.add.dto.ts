import { IsNotEmpty, IsString, IsEmail, Length } from 'class-validator';
import 'reflect-metadata';

export class SubCategoriesAddDTO {
  @IsNotEmpty({ message: 'Name cannot be empty' })
  @IsString({ message: 'Name must be a string' })
  name!: string;

  @IsNotEmpty({ message: 'Category cannot be empty' })
  @IsString({ message: 'category must be a string' })
  category!: string;

  @IsNotEmpty({ message: 'Board cannot be empty' })
  @IsString({ message: 'Board must be a string' })
  board!: string;
}
