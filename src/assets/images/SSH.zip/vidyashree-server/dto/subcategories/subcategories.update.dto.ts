import {
  IsNotEmpty,
  IsString,
  IsEmail,
  Length,
  IsOptional,
  IsBooleanString,
} from 'class-validator';
import 'reflect-metadata';

export class SubCategoriesUpdateDTO {
  @IsOptional()
  @IsString({ message: 'Name must be a string' })
  name!: string;

  @IsOptional()
  @IsString({ message: 'Category must be a string' })
  category!: string;

  @IsOptional()
  @IsBooleanString({ message: 'Status must be a boolean' })
  status!: boolean;

  @IsOptional()
  @IsString({ message: 'Board must be a string' })
  board!: string;
}
