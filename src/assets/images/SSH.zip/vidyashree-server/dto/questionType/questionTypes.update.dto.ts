//level

import { IsBooleanString, IsOptional, IsString } from 'class-validator';

//status
export class QuestionsTypeUpdateDTO {
  @IsString({ message: 'Type name must be string' })
  @IsOptional()
  type!: string;

  @IsBooleanString({ message: 'Status must be boolean' })
  @IsOptional()
  status!: boolean;
}
