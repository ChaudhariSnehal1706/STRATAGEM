//level

import { IsNotEmpty, IsString } from 'class-validator';

//status
export class QuestionsTypeAddDTO {
  @IsString({ message: 'Type name must be string' })
  @IsNotEmpty({ message: 'Type name cannot be empty' })
  type!: string;
}
