import {
  IsString,
  IsOptional,
  IsBooleanString,
  IsNumber,
  IsDateString,
  IsBoolean,
  IsNumberString,
} from 'class-validator';
import 'reflect-metadata';

export class TestSeriesUpdateDTO {
  @IsOptional()
  @IsString({ message: 'Name must be a string' })
  name!: string;

  @IsOptional()
  @IsString({ message: 'Description must be a string' })
  description!: string;

  @IsOptional()
  @IsString({ message: 'TestCategory must be a string' })
  category!: string;

  @IsOptional()
  @IsString({ message: 'TestCategory must be a string' })
  subcategory!: string;

  @IsOptional()
  @IsString({ message: 'Banner url must be a string' })
  banner_url!: string;

  @IsOptional()
  @IsNumberString()
  noOfQuestions!: number;

  @IsOptional()
  @IsNumberString()
  durationMinutes!: number;

  @IsOptional()
  @IsNumberString()
  maxMarks!: number;

  @IsOptional()
  @IsDateString()
  scheduleStartTime!: Date;

  @IsOptional()
  @IsDateString()
  scheduleEndTime!: Date;

  @IsOptional()
  @IsBooleanString()
  status!: boolean;

  @IsOptional()
  @IsBooleanString()
  featured_flag!: boolean;
}
