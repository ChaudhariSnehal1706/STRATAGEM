import {
  IsNotEmpty,
  IsString,
  IsEmail,
  Length,
  IsBoolean,
  IsNumber,
  IsDate,
  IsDateString,
  IsBooleanString,
  IsOptional,
  IsNumberString,
} from 'class-validator';
import 'reflect-metadata';

export class TestSeriesAddDTO {
  @IsNotEmpty({ message: 'Name cannot be empty' })
  @IsString({ message: 'Name must be a string' })
  name!: string;

  @IsNotEmpty({ message: 'Description cannot be empty' })
  @IsString({ message: 'Description must be a string' })
  description!: string;

  @IsNotEmpty({ message: 'Test Category cannot be empty' })
  @IsString({ message: 'Test Category must be a string' })
  category!: string;

  @IsNotEmpty({ message: 'Sub Category cannot be empty' })
  @IsString({ message: 'Sub Category must be a string' })
  subcategory!: string;

  @IsOptional()
  @IsString({ message: 'Banner URL must be a string' })
  banner_url!: string;

  @IsNotEmpty({ message: 'Number of questions cannot be empty' })
  @IsNumberString()
  noOfQuestions!: number;

  @IsNotEmpty({ message: 'Duration Minutes of questions cannot be empty' })
  @IsNumberString()
  durationMinutes!: number;

  @IsNotEmpty({ message: 'Maximum marks cannot be empty' })
  @IsNumberString()
  maxMarks!: number;

  @IsNotEmpty({ message: 'Schedule start time cannot be empty' })
  @IsDateString()
  scheduleStartTime!: Date;

  @IsNotEmpty({ message: 'Schedule end time cannot be empty' })
  @IsDateString()
  scheduleEndTime!: Date;

  @IsNotEmpty()
  @IsBooleanString()
  featured_flag!: boolean;
}
