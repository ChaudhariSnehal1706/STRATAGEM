import { IsBooleanString, IsOptional, IsString } from 'class-validator';

export class BoardsUpdateDto {
  @IsOptional()
  @IsString({ message: 'Board name must be a string' })
  board!: string;

  @IsOptional()
  @IsBooleanString({ message: 'status must be a boolean' })
  status!: boolean;

  @IsOptional()
  @IsString({ message: 'Category must be a string' })
  category!: string;
}
