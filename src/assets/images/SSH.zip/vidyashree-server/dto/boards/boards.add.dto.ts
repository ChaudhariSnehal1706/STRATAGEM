import { IsBooleanString, IsNotEmpty, IsString } from 'class-validator';

export class BoardsAddDto {
  @IsNotEmpty({ message: 'Board name cannot be empty' })
  @IsString({ message: 'Board name must be a string' })
  board!: string;

  @IsNotEmpty({ message: 'Category cannot be empty' })
  @IsString({ message: 'Category must be a string' })
  category!: string;
}
