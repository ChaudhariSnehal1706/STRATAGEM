import { IsNotEmpty, IsString } from 'class-validator';

export default class ChapterAddDto {
  @IsString({ message: 'chapter must be a string' })
  @IsNotEmpty({ message: 'chapter must not be empty' })
  chapter!: string;

  @IsString({ message: 'category must be a string' })
  @IsNotEmpty({ message: 'category cannot be empty' })
  category!: string;

  @IsString({ message: 'Subcategory must be string' })
  @IsNotEmpty({ message: 'Subcategory cannot be empty' })
  subcategory!: string;

  @IsString({ message: 'Subject must be string' })
  @IsNotEmpty({ message: 'Subject cannot be empty' })
  subject!: string;

  @IsString({ message: 'Board must be string' })
  @IsNotEmpty({ message: 'Board cannot be empty' })
  board!: string;
}
