import { IsBooleanString, IsOptional, IsString } from 'class-validator';

export default class ChapterUpdateDto {
  @IsString({ message: 'chapter must be a string' })
  @IsOptional()
  chapter!: string;

  @IsString({ message: 'category must be a string' })
  @IsOptional()
  category!: string;

  @IsString({ message: 'Subcategory must be string' })
  @IsOptional()
  subcategory!: string;

  @IsString({ message: 'Subject must be string' })
  @IsOptional()
  subject!: string;

  @IsString({ message: 'Board must be string' })
  @IsOptional()
  board!: string;

  @IsBooleanString({ message: 'Status must be Boolean' })
  @IsOptional()
  status!: boolean;
}
