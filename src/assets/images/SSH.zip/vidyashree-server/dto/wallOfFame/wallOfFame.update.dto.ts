import { IsNotEmpty, IsOptional, IsString } from 'class-validator';
import 'reflect-metadata';

export class WallOfFameUpdateDTO {
  @IsOptional()
  @IsString({ message: 'Name must be a string' })
  name!: string;

  @IsOptional()
  @IsString({ message: 'logo url must be a string' })
  imageUrl!: string;

  @IsOptional()
  @IsString({ message: 'Category must be a string' })
  category!: string;

  @IsOptional()
  @IsString({ message: 'Rank must be a string' })
  rank!: string;
}
