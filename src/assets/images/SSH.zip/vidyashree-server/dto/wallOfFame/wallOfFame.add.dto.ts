import { IsNotEmpty, IsOptional, IsString } from 'class-validator';
import 'reflect-metadata';

export class WallOfFameAddDTO {
  @IsNotEmpty({ message: 'Name cannot be empty' })
  @IsString({ message: 'Name must be a string' })
  name!: string;

  @IsOptional()
  @IsString({ message: 'ImageURL must be a string' })
  imageUrl!: string;

  @IsNotEmpty({ message: 'Category cannot be empty' })
  @IsString({ message: 'Category must be a string' })
  category!: string;

  @IsNotEmpty({ message: 'Rank cannot be empty' })
  @IsString({ message: 'Rank must be a string' })
  rank!: string;
}
