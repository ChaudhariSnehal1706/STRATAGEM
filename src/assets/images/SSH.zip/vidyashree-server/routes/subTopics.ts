import express from 'express';
import RateLimiter from '../util/rate-limiter';
import { validateAndTransform } from '../middlewares/class-validator.middleware';
import SubTopicController from '../controllers/subTopic/subTopic.controller';
import { SubTopicsAddDTO } from '../dto/subTopics/subTopics.add.dto';
import { SubTopicsUpdateDTO } from '../dto/subTopics/subTopics.update.dto';

const router = express.Router();
const controller = new SubTopicController();
const rateLimiter = new RateLimiter();

router.get('/', rateLimiter.getLimiter, controller.getSubTopics);

router.post(
  '/',
  rateLimiter.getLimiter,
  validateAndTransform(SubTopicsAddDTO),
  controller.addSubTopic
);
router.delete('/:id', rateLimiter.getLimiter, controller.deleteSubTopic);
router.put(
  '/:id',
  rateLimiter.getLimiter,
  validateAndTransform(SubTopicsUpdateDTO),
  controller.updateSubTopic
);

export default router;
