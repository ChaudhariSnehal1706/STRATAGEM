import express from 'express';
import AuthenticationMiddleware from '../middlewares/authentication.middleware';
import RateLimiter from '../util/rate-limiter';
import { validateAndTransform } from '../middlewares/class-validator.middleware';
import PartnerController from '../controllers/partners/partners.controller';
import { PartnersAddDTO } from '../dto/partners/partner.add.dto';
import { PartnersUpdateDTO } from '../dto/partners/partner.update.dto';
import { faqAddDTO } from '../dto/faq/faq.add.dto';
import { FaqUpdateDTO } from '../dto/faq/faq.update.dto';
import FaqController from '../controllers/faq/faq.controller';

const router = express.Router();
const controller = new FaqController();
const authController = new AuthenticationMiddleware();
const rateLimiter = new RateLimiter();

router.get('/', rateLimiter.getLimiter, controller.getFaq);
router.get('/:id', rateLimiter.getLimiter, controller.getFaqById);
router.post(
  '/',
  rateLimiter.getLimiter,
  validateAndTransform(faqAddDTO),
  controller.addFaq
);
router.delete('/:id', rateLimiter.getLimiter, controller.deleteFaq);
router.put(
  '/:id',
  rateLimiter.getLimiter,
  validateAndTransform(FaqUpdateDTO),
  controller.updateFaq
);

export default router;
