import express from 'express';
import AuthenticationMiddleware from '../middlewares/authentication.middleware';
import RateLimiter from '../util/rate-limiter';
import SubCategoriesController from '../controllers/subcategories/subcategories.controller';
import { validateAndTransform } from '../middlewares/class-validator.middleware';
import { SubCategoriesUpdateDTO } from '../dto/subcategories/subcategories.update.dto';
import { SubCategoriesAddDTO } from '../dto/subcategories/subcategories.add.dto';
const router = express.Router();
const controller = new SubCategoriesController();
const authController = new AuthenticationMiddleware();
const rateLimiter = new RateLimiter();

router.get('/', rateLimiter.getLimiter, controller.getSubCategories);
router.get('/:id', rateLimiter.getLimiter, controller.getSubCategoriesById);
router.get(
  '/category/:categoryId',
  rateLimiter.getLimiter,
  controller.getSubCategoriesByCategoryId
);
router.post(
  '/',
  rateLimiter.getLimiter,
  validateAndTransform(SubCategoriesAddDTO),
  controller.addSubCategories
);
router.delete('/:id', rateLimiter.getLimiter, controller.deleteSubCategories);
router.put(
  '/:id',
  rateLimiter.getLimiter,
  validateAndTransform(SubCategoriesUpdateDTO),
  controller.updateSubCategories
);

export default router;
