import express from 'express';
import RateLimiter from '../util/rate-limiter';
import { validateAndTransform } from '../middlewares/class-validator.middleware';
import QuestionController from '../controllers/questions/questions.controller';
import QuestionsAddDto from '../dto/questions/questions.add.dto';
import QuestionsUpdateDto from '../dto/questions/questions.update.dto';

const router = express.Router();
const controller = new QuestionController();
const rateLimiter = new RateLimiter();

router.get('/', rateLimiter.getLimiter, controller.getQuestions);
router.put(
  '/:id',
  rateLimiter.getLimiter,
  validateAndTransform(QuestionsUpdateDto),
  controller.updateQuestion
);
router.post(
  '/',
  rateLimiter.getLimiter,
  validateAndTransform(QuestionsAddDto),
  controller.createQuestion
);
router.delete('/:id', rateLimiter.getLimiter, controller.deleteQuestion);


export default router;
