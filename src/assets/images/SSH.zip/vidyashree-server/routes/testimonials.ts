import express from 'express';
import AuthenticationMiddleware from '../middlewares/authentication.middleware';
import RateLimiter from '../util/rate-limiter';
import { validateAndTransform } from '../middlewares/class-validator.middleware';
import { PartnersAddDTO } from '../dto/partners/partner.add.dto';
import { PartnersUpdateDTO } from '../dto/partners/partner.update.dto';
import TestimonialsController from '../controllers/testimonials/testimonials.controller';
import { TestimonialsAddDTO } from '../dto/testimonials/testimonials.add.dto';
import { TestimonialsUpdateDTO } from '../dto/testimonials/testimonials.update.dto';

const router = express.Router();
const controller = new TestimonialsController();
const authController = new AuthenticationMiddleware();
const rateLimiter = new RateLimiter();

router.get('/', rateLimiter.getLimiter, controller.getTestimonials);
router.get(
  '/:id',
  rateLimiter.getLimiter,
  authController.authenticateJWT,
  controller.getTestimonialsById
);
router.post(
  '/',
  rateLimiter.getLimiter,
  validateAndTransform(TestimonialsAddDTO),
  controller.addTestimonials
);
router.delete('/:id', rateLimiter.getLimiter, controller.deleteTestimonials);
router.put(
  '/:id',
  rateLimiter.getLimiter,
  validateAndTransform(TestimonialsUpdateDTO),
  controller.updateTestimonials
);

export default router;
