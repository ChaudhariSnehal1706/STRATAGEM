import express from 'express';
import AuthenticationMiddleware from '../middlewares/authentication.middleware';
import RateLimiter from '../util/rate-limiter';
import { validateAndTransform } from '../middlewares/class-validator.middleware';
import PartnerController from '../controllers/partners/partners.controller';
import { PartnersAddDTO } from '../dto/partners/partner.add.dto';
import { PartnersUpdateDTO } from '../dto/partners/partner.update.dto';
import upload from '../middlewares/upload.middleware';

const router = express.Router();
const controller = new PartnerController();
const authController = new AuthenticationMiddleware();
const rateLimiter = new RateLimiter();

router.get('/', rateLimiter.getLimiter, controller.getPartners);
router.get('/:id', rateLimiter.getLimiter, controller.getPartnersById);
router.post(
  '/',
  rateLimiter.getLimiter,
  upload.single('image'),
  validateAndTransform(PartnersAddDTO),
  controller.addPartners
);
router.delete('/:id', rateLimiter.getLimiter, controller.deletePartners);
router.put(
  '/:id',
  rateLimiter.getLimiter,
  upload.single('image'),
  validateAndTransform(PartnersUpdateDTO),
  controller.updatePartners
);

export default router;
