import express from 'express';
import AuthenticationMiddleware from '../middlewares/authentication.middleware';
import RateLimiter from '../util/rate-limiter';
import { validateAndTransform } from '../middlewares/class-validator.middleware';
import QuestionLevelController from '../controllers/questionLevels/questionLevels.controller';
import { QuestionsLevelAddDTO } from '../dto/questionsLevel/questionLevel.add.dto';
import { QuestionsLevelUpdateDTO } from '../dto/questionsLevel/questionLevel.update.dto';

const router = express.Router();
const controller = new QuestionLevelController();
const authController = new AuthenticationMiddleware();
const rateLimiter = new RateLimiter();

router.get('/', rateLimiter.getLimiter, controller.getQuestionLevel);
router.get(
  '/:id',
  rateLimiter.getLimiter,
  authController.authenticateJWT,
  controller.getQuestionLevelById
);
router.post(
  '/',
  rateLimiter.getLimiter,
  validateAndTransform(QuestionsLevelAddDTO),
  controller.addQuestionLevel
);
router.delete('/:id', rateLimiter.getLimiter, controller.deleteQuestionLevel);
router.put(
  '/:id',
  rateLimiter.getLimiter,
  validateAndTransform(QuestionsLevelUpdateDTO),
  controller.updateQuestionLevel
);

export default router;
