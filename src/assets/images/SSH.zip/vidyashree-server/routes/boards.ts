import express from 'express';
import AuthenticationMiddleware from '../middlewares/authentication.middleware';
import RateLimiter from '../util/rate-limiter';

import { CategoriesAddDTO } from '../dto/categories/categories.add.dto';
import { validateAndTransform } from '../middlewares/class-validator.middleware';
import { CategoriesUpdateDTO } from '../dto/categories/categories.update.dto';
import upload from '../middlewares/upload.middleware';
import BoardController from '../controllers/boards/boards.controller';
import { BoardsAddDto } from '../dto/boards/boards.add.dto';
import { BoardsUpdateDto } from '../dto/boards/boards.update.dto';

const router = express.Router();
const controller = new BoardController();
const authController = new AuthenticationMiddleware();
const rateLimiter = new RateLimiter();

router.get('/', rateLimiter.getLimiter, controller.getBoard);
router.get(
  '/:id',
  rateLimiter.getLimiter,
  authController.authenticateJWT,
  controller.getBoardById
);
router.post(
  '/',
  rateLimiter.getLimiter,
  validateAndTransform(BoardsAddDto),
  controller.createBoard
);
router.delete('/:id', rateLimiter.getLimiter, controller.deleteBoard);
router.put(
  '/:id',
  rateLimiter.getLimiter,
  validateAndTransform(BoardsUpdateDto),
  controller.updateBoard
);

export default router;
