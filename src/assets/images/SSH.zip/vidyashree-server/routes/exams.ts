import express from 'express';
import AuthenticationMiddleware from '../middlewares/authentication.middleware';
import RateLimiter from '../util/rate-limiter';

import ExamsController from '../controllers/exams/exams.controller';
import { validateAndTransform } from '../middlewares/class-validator.middleware';
import { ExamsAddDTO } from '../dto/exams/exams.add.dto';
import { ExamsUpdateDTO } from '../dto/exams/exams.update.dto';

const router = express.Router();
const controller = new ExamsController();
const authController = new AuthenticationMiddleware();
const rateLimiter = new RateLimiter();

router.get(
  '/',
  rateLimiter.getLimiter,
  authController.authenticateJWT,
  controller.getExams
);
router.get(
  '/:id',
  rateLimiter.getLimiter,
  authController.authenticateJWT,
  controller.getExamsById
);
router.post(
  '/',
  rateLimiter.getLimiter,
  authController.authenticateJWT,
  validateAndTransform(ExamsAddDTO),
  controller.addExams
);
router.delete(
  '/:id',
  rateLimiter.getLimiter,
  authController.authenticateJWT,
  controller.deleteExams
);
router.put('/:id', rateLimiter.getLimiter, authController.authenticateJWT),
  validateAndTransform(ExamsUpdateDTO),
  controller.updateExams;

export default router;
