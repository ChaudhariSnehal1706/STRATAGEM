import express from 'express';
import AuthenticationMiddleware from '../middlewares/authentication.middleware';
import RateLimiter from '../util/rate-limiter';
import { validateAndTransform } from '../middlewares/class-validator.middleware';
import PartnerController from '../controllers/partners/partners.controller';
import { PartnersAddDTO } from '../dto/partners/partner.add.dto';
import { PartnersUpdateDTO } from '../dto/partners/partner.update.dto';
import QuizController from '../controllers/quiz/quiz.controller';
import { QuizUpdateDTO } from '../dto/quiz/quiz.update.dto';
import { QuizAddDTO } from '../dto/quiz/quiz.add.dto';

const router = express.Router();
const controller = new QuizController();
const authController = new AuthenticationMiddleware();
const rateLimiter = new RateLimiter();

router.get('/', rateLimiter.getLimiter, controller.getQuiz);
router.get('/:id', rateLimiter.getLimiter, controller.getQuizById);
router.post(
  '/',
  rateLimiter.getLimiter,
  validateAndTransform(QuizAddDTO),
  controller.addQuiz
);
router.delete('/:id', rateLimiter.getLimiter, controller.deleteQuiz);
router.put(
  '/:id',
  rateLimiter.getLimiter,
  validateAndTransform(QuizUpdateDTO),
  controller.updateQuiz
);

export default router;
