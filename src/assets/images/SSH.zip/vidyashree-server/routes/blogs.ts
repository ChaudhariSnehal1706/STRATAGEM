import express from 'express';
import AuthenticationMiddleware from '../middlewares/authentication.middleware';
import RateLimiter from '../util/rate-limiter';
import { validateAndTransform } from '../middlewares/class-validator.middleware';
import BlogController from '../controllers/blogs/blogs.controller';
import { BlogsAddDTO } from '../dto/blogs/blogs.add.dto';
import { BlogsUpdateDTO } from '../dto/blogs/blogs.update.dto';
import upload from '../middlewares/upload.middleware';

const router = express.Router();
const controller = new BlogController();
const authController = new AuthenticationMiddleware();
const rateLimiter = new RateLimiter();

router.get('/', rateLimiter.getLimiter, controller.getBlogs);
router.get('/recent', rateLimiter.getLimiter, controller.getRecentBlog);
router.get('/:id', rateLimiter.getLimiter, controller.getBlogById);

router.post(
  '/',
  rateLimiter.getLimiter,
  upload.single('image'),
  validateAndTransform(BlogsAddDTO),
  controller.addBlog
);
router.delete('/:id', rateLimiter.getLimiter, controller.deleteBlog);
router.put(
  '/:id',
  rateLimiter.getLimiter,
  upload.single('image'),
  validateAndTransform(BlogsUpdateDTO),
  controller.updateBlog
);

export default router;
