import express from 'express';
import AuthenticationMiddleware from '../middlewares/authentication.middleware';
import RateLimiter from '../util/rate-limiter';
import { validateAndTransform } from '../middlewares/class-validator.middleware';
import BlogCategoryController from '../controllers/blogs-categories/blogsCategory.controller';
import { BlogsCategoryUpdateDTO } from '../dto/blogs-category/blogs.catergory.update.dto';
import { BlogsCategoryAddDTO } from '../dto/blogs-category/blogs.catergory.add.dto';
import upload from '../middlewares/upload.middleware';

const router = express.Router();
const controller = new BlogCategoryController();
const authController = new AuthenticationMiddleware();
const rateLimiter = new RateLimiter();

router.get('/', rateLimiter.getLimiter, controller.getBlogCategory);

router.get('/:id', rateLimiter.getLimiter, controller.getBlogCategoryById);

router.post(
  '/',
  rateLimiter.getLimiter,
  validateAndTransform(BlogsCategoryAddDTO),
  upload.single('image'),
  controller.addBlogCategory
);
router.delete('/:id', rateLimiter.getLimiter, controller.deleteBlogCategory);
router.put(
  '/:id',
  rateLimiter.getLimiter,

  validateAndTransform(BlogsCategoryUpdateDTO),
  controller.updateBlogCategory
);

export default router;
