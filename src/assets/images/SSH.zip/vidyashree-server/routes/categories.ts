import express from 'express';
import AuthenticationMiddleware from '../middlewares/authentication.middleware';
import RateLimiter from '../util/rate-limiter';
import CategoriesController from '../controllers/categories/categories.controller';
import { CategoriesAddDTO } from '../dto/categories/categories.add.dto';
import { validateAndTransform } from '../middlewares/class-validator.middleware';
import { CategoriesUpdateDTO } from '../dto/categories/categories.update.dto';
import upload from '../middlewares/upload.middleware';

const router = express.Router();
const controller = new CategoriesController();
const authController = new AuthenticationMiddleware();
const rateLimiter = new RateLimiter();

router.get('/', rateLimiter.getLimiter, controller.getCategories);
router.get(
  '/:id',
  rateLimiter.getLimiter,
  authController.authenticateJWT,
  controller.getCategoriesById
);
router.post(
  '/',
  rateLimiter.getLimiter,
  upload.single('image'),
  validateAndTransform(CategoriesAddDTO),
  controller.addCategories
);
router.delete('/:id', rateLimiter.getLimiter, controller.deleteCategories);
router.put(
  '/:id',
  rateLimiter.getLimiter,
  upload.single('image'),
  validateAndTransform(CategoriesUpdateDTO),
  controller.updateCategories
);

export default router;
