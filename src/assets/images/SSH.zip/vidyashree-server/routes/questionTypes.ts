import express from 'express';
import AuthenticationMiddleware from '../middlewares/authentication.middleware';
import RateLimiter from '../util/rate-limiter';
import { validateAndTransform } from '../middlewares/class-validator.middleware';
import QuestionTypeController from '../controllers/questionTypes/questionTypes.controller';
import { QuestionsTypeAddDTO } from '../dto/questionType/questionTypes.add.dto';
import { QuestionsTypeUpdateDTO } from '../dto/questionType/questionTypes.update.dto';

const router = express.Router();
const controller = new QuestionTypeController();
const authController = new AuthenticationMiddleware();
const rateLimiter = new RateLimiter();

router.get('/', rateLimiter.getLimiter, controller.getQuestionType);
router.get(
  '/:id',
  rateLimiter.getLimiter,
  authController.authenticateJWT,
  controller.getQuestionTypeById
);
router.post(
  '/',
  rateLimiter.getLimiter,
  validateAndTransform(QuestionsTypeAddDTO),
  controller.addQuestionType
);
router.delete('/:id', rateLimiter.getLimiter, controller.deleteQuestionType);
router.put(
  '/:id',
  rateLimiter.getLimiter,
  validateAndTransform(QuestionsTypeUpdateDTO),
  controller.updateQuestionType
);

export default router;
