import express from 'express';
import AuthenticationMiddleware from '../middlewares/authentication.middleware';
import RateLimiter from '../util/rate-limiter';
import { validateAndTransform } from '../middlewares/class-validator.middleware';
import TestSeriesController from '../controllers/testSeries/testSeries.controller';
import { TestSeriesAddDTO } from '../dto/testSeries/testSeries.add.dto';
import { TestSeriesUpdateDTO } from '../dto/testSeries/testSeries.update.dto';
import upload from '../middlewares/upload.middleware';

const router = express.Router();
const controller = new TestSeriesController();
const authController = new AuthenticationMiddleware();
const rateLimiter = new RateLimiter();

router.get('/', rateLimiter.getLimiter, controller.getTestSeries);

router.get(
  '/featured-testseries',
  rateLimiter.getLimiter,
  controller.getFeaturedTestSeries
);
router.get(
  '/upcoming-testseries',
  rateLimiter.getLimiter,
  controller.getUpcomingTestSeries
);
router.get(
  '/recommended-testseries',
  rateLimiter.getLimiter,
  controller.getRecommendedTestSeries
);
router.get('/:id', rateLimiter.getLimiter, controller.getTestSeriesById);
router.post(
  '/',
  rateLimiter.getLimiter,
  upload.single('image'),
  validateAndTransform(TestSeriesAddDTO),
  controller.addTestSeries
);
router.delete('/:id', rateLimiter.getLimiter, controller.deleteTestSeries);
router.put(
  '/:id',
  rateLimiter.getLimiter,
  upload.single('image'),
  validateAndTransform(TestSeriesUpdateDTO),
  controller.updateTestSeries
);

export default router;
