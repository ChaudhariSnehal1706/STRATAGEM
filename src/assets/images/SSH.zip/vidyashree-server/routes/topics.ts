import express from 'express';
import RateLimiter from '../util/rate-limiter';
import { validateAndTransform } from '../middlewares/class-validator.middleware';
import ChapterAddDto from '../dto/chapters/chapters.add.dto';
import ChapterUpdateDto from '../dto/chapters/chapters.update.dto';
import TopicController from '../controllers/topics/topics.controller';

const router = express.Router();
const controller = new TopicController();
const rateLimiter = new RateLimiter();

router.get('/', rateLimiter.getLimiter, controller.getTopics);

router.post(
  '/',
  rateLimiter.getLimiter,
  validateAndTransform(ChapterAddDto),
  controller.addTopic
);
router.delete('/:id', rateLimiter.getLimiter, controller.deleteTopic);
router.put(
  '/:id',
  rateLimiter.getLimiter,
  validateAndTransform(ChapterUpdateDto),
  controller.updateTopic
);

export default router;
