import express from 'express';
import AuthController from '../controllers/auth/auth.controller';
import {
  StudentLoginDTO,
  StudentLoginMobileDTO,
  StudentLoginOtpDTO,
  StudentRegisterDTO,
  StudentRegisterOtpVerifyDTO,
  ForgetPasswordRequestOtpDTO,
  ForgetPasswordVerifyOtpDTO,
  ResetPasswordDTO,
} from '../dto/auth/student.register.dto';
import AuthenticationMiddleware from '../middlewares/authentication.middleware';
import { validateAndTransform } from '../middlewares/class-validator.middleware';
import RateLimiter from '../util/rate-limiter';

const router = express.Router();
const controller = new AuthController();
const rateLimiter = new RateLimiter();
const authMiddleware = new AuthenticationMiddleware();

router.post(
  '/register-student',
  rateLimiter.postLimiter,
  validateAndTransform(StudentRegisterDTO),
  controller.studentRegister
);

router.post(
  '/register-student-verify-otp',
  rateLimiter.postLimiter,
  validateAndTransform(StudentRegisterOtpVerifyDTO),
  controller.studentRegisterOtpVerify
);

router.post(
  '/login-student',
  rateLimiter.postLimiter,
  validateAndTransform(StudentLoginDTO),
  controller.studentLogin
);

router.post(
  '/login-student-otp',
  rateLimiter.postLimiter,
  validateAndTransform(StudentLoginOtpDTO),
  controller.studentLoginOtpSend
);

router.post(
  '/login-student-mobile',
  rateLimiter.postLimiter,
  validateAndTransform(StudentLoginMobileDTO),
  controller.studentLoginMobile
);

router.post(
  '/forget-password/request-otp',
  rateLimiter.postLimiter,
  validateAndTransform(ForgetPasswordRequestOtpDTO),
  controller.forgetPasswordRequestOtp
);

router.post(
  '/forget-password/verify-otp',
  rateLimiter.postLimiter,
  validateAndTransform(ForgetPasswordVerifyOtpDTO),
  controller.forgetPasswordVerifyOtp
);

router.post(
  '/reset-password',
  rateLimiter.postLimiter,
  validateAndTransform(ResetPasswordDTO),
  controller.resetPassword
);

router.get(
  '/initial-detail',
  rateLimiter.getLimiter,
  authMiddleware.authenticateJWT,
  controller.initialUserDetail
);

export default router;
