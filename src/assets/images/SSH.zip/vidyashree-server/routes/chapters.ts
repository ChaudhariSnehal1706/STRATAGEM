import express from 'express';
import AuthenticationMiddleware from '../middlewares/authentication.middleware';
import RateLimiter from '../util/rate-limiter';
import { validateAndTransform } from '../middlewares/class-validator.middleware';
import ChapterController from '../controllers/chapters/chapters.controller';
import ChapterAddDto from '../dto/chapters/chapters.add.dto';
import ChapterUpdateDto from '../dto/chapters/chapters.update.dto';

const router = express.Router();
const controller = new ChapterController();
const authController = new AuthenticationMiddleware();
const rateLimiter = new RateLimiter();

router.get('/', rateLimiter.getLimiter, controller.getChapter);
router.get('/:id', rateLimiter.getLimiter, controller.getChapterById);
router.post(
  '/',
  rateLimiter.getLimiter,
  validateAndTransform(ChapterAddDto),
  controller.addChapter
);
router.delete('/:id', rateLimiter.getLimiter, controller.deleteChapter);
router.put(
  '/:id',
  rateLimiter.getLimiter,
  validateAndTransform(ChapterUpdateDto),
  controller.updateChapter
);

export default router;
