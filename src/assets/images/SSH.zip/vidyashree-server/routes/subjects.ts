import express from 'express';
import AuthenticationMiddleware from '../middlewares/authentication.middleware';
import RateLimiter from '../util/rate-limiter';
import SubjectsController from '../controllers/subjects/subjects.controller';
import { validateAndTransform } from '../middlewares/class-validator.middleware';
import { SubjectsAddDTO } from '../dto/subjects/subjects.add.dto';
import { SubjectsUpdateDTO } from '../dto/subjects/subjects.update.dto';
import upload from '../middlewares/upload.middleware';

const router = express.Router();
const controller = new SubjectsController();
const authController = new AuthenticationMiddleware();
const rateLimiter = new RateLimiter();

router.get('/', rateLimiter.getLimiter, controller.getSubjects);
router.get(
  '/:id',
  rateLimiter.getLimiter,
  authController.authenticateJWT,
  controller.getSubjectsById
);
router.post(
  '/',
  rateLimiter.getLimiter,
  upload.single('image'),
  validateAndTransform(SubjectsAddDTO),
  controller.addSubjects
);
router.delete('/:id', rateLimiter.getLimiter, controller.deleteSubjects);
router.put(
  '/:id',
  rateLimiter.getLimiter,
  upload.single('image'),
  validateAndTransform(SubjectsUpdateDTO),
  controller.updateSubjects
);

// Route to get subjects by subcategory ID
router.get(
  '/subcategory/:subcategoryId',
  rateLimiter.getLimiter,
  controller.getSubjectsBySubcategoryId
);

export default router;
