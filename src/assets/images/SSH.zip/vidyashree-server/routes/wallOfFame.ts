import express from 'express';
import AuthenticationMiddleware from '../middlewares/authentication.middleware';
import RateLimiter from '../util/rate-limiter';
import { validateAndTransform } from '../middlewares/class-validator.middleware';
import { PartnersAddDTO } from '../dto/partners/partner.add.dto';
import { PartnersUpdateDTO } from '../dto/partners/partner.update.dto';
import WallOfFameController from '../controllers/wallOfFame/wallOfFame.controller';
import { WallOfFameAddDTO } from '../dto/wallOfFame/wallOfFame.add.dto';
import { WallOfFameUpdateDTO } from '../dto/wallOfFame/wallOfFame.update.dto';
import upload from '../middlewares/upload.middleware';

const router = express.Router();
const controller = new WallOfFameController();
const authController = new AuthenticationMiddleware();
const rateLimiter = new RateLimiter();

router.get('/', rateLimiter.getLimiter, controller.getWallOfFame);
router.get('/:id', rateLimiter.getLimiter, controller.getWallOfFameById);
router.post(
  '/',
  rateLimiter.getLimiter,
  upload.single('image'),
  validateAndTransform(WallOfFameAddDTO),
  controller.addWallOfFame
);
router.delete('/:id', rateLimiter.getLimiter, controller.deleteWallOfFame);
router.put(
  '/:id',
  rateLimiter.getLimiter,
  upload.single('image'),
  validateAndTransform(WallOfFameUpdateDTO),
  controller.updateWallOfFame
);

export default router;
