import { QuestionsLevelAddDTO } from '../../dto/questionsLevel/questionLevel.add.dto';
import { QuestionsLevelUpdateDTO } from '../../dto/questionsLevel/questionLevel.update.dto';
import QuestionLevelService from '../../services/questionLevel.service';
import HttpStatusCode from '../../util/http-status-code';

export default class QuestionLevelController {
  readonly questionLevelService = new QuestionLevelService();
  getQuestionLevel = async (request: any, response: any) => {
    try {
      const data = await this.questionLevelService.getQuestionLevel(
        request.query
      );
      response.success(data);
    } catch (error: any) {
      response.error(
        'Failed to save Question level',
        HttpStatusCode.BAD_REQUEST,
        error.message
      );
    }
  };
  getQuestionLevelById = async (request: any, response: any) => {};
  addQuestionLevel = async (request: any, response: any) => {
    try {
      const questionLevelDataDTO: QuestionsLevelAddDTO = request.data;

      const data =
        await this.questionLevelService.createQuestionLevel(
          questionLevelDataDTO
        );
      response.success(
        data,
        HttpStatusCode.CREATED,
        'Question Level created successfully'
      );
    } catch (error: any) {
      response.error(
        'Failed to save Question Level',
        HttpStatusCode.BAD_REQUEST,
        error.message
      );
    }
  };
  deleteQuestionLevel = async (request: any, response: any) => {
    try {
      const questionLevelId: string = request.params.id;
      const data =
        await this.questionLevelService.deleteQuestionLevel(questionLevelId);
      response.success(
        data,
        HttpStatusCode.OK,
        'Question Level deleted successfully'
      );
    } catch (error: any) {
      response.error(
        'Failed to delete Question Level',
        HttpStatusCode.BAD_REQUEST,
        error.message
      );
    }
  };
  updateQuestionLevel = async (request: any, response: any) => {
    try {
      const questionLevelDataDTO: QuestionsLevelUpdateDTO = request.data;

      const data = await this.questionLevelService.updateQuestionLevel(
        request.params.id,
        questionLevelDataDTO
      );
      response.success(
        data,
        HttpStatusCode.OK,
        'Question Level updated successfully'
      );
    } catch (error: any) {
      response.error(
        'Failed to update Question Level',
        HttpStatusCode.BAD_REQUEST,
        error.message
      );
    }
  };
}
