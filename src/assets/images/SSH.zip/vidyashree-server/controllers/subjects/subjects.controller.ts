import { Request, Response } from 'express';
import { SubjectsAddDTO } from '../../dto/subjects/subjects.add.dto';
import { SubjectsUpdateDTO } from '../../dto/subjects/subjects.update.dto';
import SubjectService from '../../services/subject.service';
import HttpStatusCode from '../../util/http-status-code';

export default class SubjectsController {
  readonly subjectService = new SubjectService();
  getSubjects = async (request: any, response: any) => {
    try {
      const data = await this.subjectService.getSubject(request.query);
      response.success(data);
    } catch (error: any) {
      response.error(
        'Failed to save subjects',
        HttpStatusCode.BAD_REQUEST,
        error.message
      );
    }
  };
  getSubjectsById = (request: any, response: any) => {};
  addSubjects = async (request: any, response: any) => {
    try {
      const file = request.file;
      if (!file) {
        return response.error(
          'Failed to save Category',
          HttpStatusCode.BAD_REQUEST,
          'Please choose category image'
        );
      }
      const subjectsDataDTO: SubjectsAddDTO = request.data;
      subjectsDataDTO.iconurl = file.filename;
      const data = await this.subjectService.createSubject(subjectsDataDTO);
      response.success(
        data,
        HttpStatusCode.CREATED,
        'Subject created successfully'
      );
    } catch (error: any) {
      response.error(
        'Failed to save subject',
        HttpStatusCode.BAD_REQUEST,
        error.message
      );
    }
  };
  deleteSubjects = async (request: any, response: any) => {
    try {
      const subjectId: string = request.params.id;
      const data = await this.subjectService.deleteSubject(subjectId);
      response.success(data, HttpStatusCode.OK, 'subject deleted successfully');
    } catch (error: any) {
      response.error(
        'Failed to delete subject',
        HttpStatusCode.BAD_REQUEST,
        error.message
      );
    }
  };
  updateSubjects = async (request: any, response: any) => {
    try {
      const subjectDataDTO: SubjectsUpdateDTO = request.data;
      const file = request.file;
      if (file) {
        subjectDataDTO.iconurl = file.filename;
      } else {
        subjectDataDTO.iconurl = '';
      }
      const data = await this.subjectService.updateSubject(
        request.params.id,
        subjectDataDTO
      );
      response.success(
        data,
        HttpStatusCode.CREATED,
        'Subject updated successfully'
      );
    } catch (error: any) {
      response.error(
        'Failed to update subject',
        HttpStatusCode.BAD_REQUEST,
        error.message
      );
    }
  };

  getSubjectsBySubcategoryId = async (req: any, res: any) => {
    try {
      const subcategoryId = req.params.subcategoryId;
      const subjects =
        await this.subjectService.getSubjectsBySubcategoryId(subcategoryId);
      res.success(subjects);
    } catch (error: any) {
      res.error(
        'Failed to fetch subjects by subcategory ID',
        HttpStatusCode.BAD_REQUEST,
        error.message
      );
    }
  };

 
}
