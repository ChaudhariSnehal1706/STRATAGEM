import { request } from 'http';
import { TestSeriesAddDTO } from '../../dto/testSeries/testSeries.add.dto';
import { TestSeriesUpdateDTO } from '../../dto/testSeries/testSeries.update.dto';
import TestSeriesService from '../../services/testSeries.service';
import HttpStatusCode from '../../util/http-status-code';
export default class TestSeriesController {
  readonly testSeriesService = new TestSeriesService();
  getTestSeries = async (request: any, response: any) => {
    try {
      const data = await this.testSeriesService.getTestSeries(request.query);
      response.success(data);
    } catch (error: any) {
      response.error(
        'Failed to save test series',
        HttpStatusCode.BAD_REQUEST,
        error.message
      );
    }
  };
  getTestSeriesById = async (request: any, response: any) => {
    try {
      const { id } = request.params;
      const blog = await this.testSeriesService.getTestSeriesById(id);
      response.success(blog);
    } catch (error: any) {
      console.log(error);
      response.error(
        'Failed to save test series',
        HttpStatusCode.BAD_REQUEST,
        error.message
      );
    }
  };
  getFeaturedTestSeries = async (request: any, response: any) => {
    try {
      const data = await this.testSeriesService.getFeaturedTestSeries(
        request.query
      );
      response.success(data);
    } catch (error: any) {
      response.error(
        'Failed to save test series',
        HttpStatusCode.BAD_REQUEST,
        error.message
      );
    }
  };
  getRecommendedTestSeries = async (request: any, response: any) => {
    try {
      const data = await this.testSeriesService.getRecommendedTestSeries(
        request.query
      );
      response.success(data);
    } catch (error: any) {
      response.error(
        'Failed to save test series',
        HttpStatusCode.BAD_REQUEST,
        error.message
      );
    }
  };
  getUpcomingTestSeries = async (request: any, response: any) => {
    try {
      const data = await this.testSeriesService.getUpcomingTestSeries(
        request.query
      );
      response.success(data);
    } catch (error: any) {
      response.error(
        'Failed to save test series',
        HttpStatusCode.BAD_REQUEST,
        error.message
      );
    }
  };
  addTestSeries = async (request: any, response: any) => {
    try {
      const testSeriesDataDTO: TestSeriesAddDTO = request.data;
      const data =
        await this.testSeriesService.createTestSeries(testSeriesDataDTO);
      response.success(
        data,
        HttpStatusCode.CREATED,
        'Test Series created successfully'
      );
    } catch (error: any) {
      response.error(
        'Failed to save Test Series',
        HttpStatusCode.BAD_REQUEST,
        error.message
      );
    }
  };
  deleteTestSeries = async (request: any, response: any) => {
    try {
      const testSeriesId: string = request.params.id;
      const data = await this.testSeriesService.deleteTestSeries(testSeriesId);
      response.success(
        data,
        HttpStatusCode.OK,
        'TestSeries deleted successfully'
      );
    } catch (error: any) {
      response.error(
        'Failed to delete TestSeries',
        HttpStatusCode.BAD_REQUEST,
        error.message
      );
    }
  };
  updateTestSeries = async (request: any, response: any) => {
    try {
      const testSeriesDataDTO: TestSeriesUpdateDTO = request.data;
      const file = request.file;
      if (file) {
        console.log(file);
        testSeriesDataDTO.banner_url = file.filename;
      } else {
        testSeriesDataDTO.banner_url = '';
      }
      const data = await this.testSeriesService.updateTestSeries(
        request.params.id,
        testSeriesDataDTO
      );
      response.success(
        data,
        HttpStatusCode.OK,
        'TestSeries updated successfully'
      );
    } catch (error: any) {
      response.error(
        'Failed to update TestSeries',
        HttpStatusCode.BAD_REQUEST,
        error.message
      );
    }
  };
}
