import { WallOfFameAddDTO } from '../../dto/wallOfFame/wallOfFame.add.dto';
import { WallOfFameUpdateDTO } from '../../dto/wallOfFame/wallOfFame.update.dto';

import WallOfFameService from '../../services/wallOfFame.service';
import HttpStatusCode from '../../util/http-status-code';

export default class WallOfFameController {
  readonly wallOfFameService = new WallOfFameService();
  getWallOfFame = async (request: any, response: any) => {
    try {
      const data = await this.wallOfFameService.getWallOfFame();
      response.success(data);
    } catch (error: any) {
      response.error(
        'Failed to save Wall Of fame',
        HttpStatusCode.BAD_REQUEST,
        error.message
      );
    }
  };
  getWallOfFameById = async (request: any, response: any) => {};
  addWallOfFame = async (request: any, response: any) => {
    try {
      const file = request.file;
      if (!file) {
        return response.error(
          'Failed to save partners',
          HttpStatusCode.BAD_REQUEST,
          'Please choose partners image'
        );
      }
      const wallOfFameDataDTO: WallOfFameAddDTO = request.data;
      wallOfFameDataDTO.imageUrl = file.filename;
      const data =
        await this.wallOfFameService.createWallOfFame(wallOfFameDataDTO);
      response.success(
        data,
        HttpStatusCode.CREATED,
        'Wall Of fame created successfully'
      );
    } catch (error: any) {
      response.error(
        'Failed to save Wall Of fame',
        HttpStatusCode.BAD_REQUEST,
        error.message
      );
    }
  };
  deleteWallOfFame = async (request: any, response: any) => {
    try {
      const wallOfFameId: string = request.params.id;
      const data = await this.wallOfFameService.deleteWallOfFame(wallOfFameId);
      response.success(
        data,
        HttpStatusCode.OK,
        'Wall Of fame deleted successfully'
      );
    } catch (error: any) {
      response.error(
        'Failed to delete Wall Of fame',
        HttpStatusCode.BAD_REQUEST,
        error.message
      );
    }
  };
  updateWallOfFame = async (request: any, response: any) => {
    try {
      const wallOfFameDataDTO: WallOfFameUpdateDTO = request.data;
      const file = request.file;
      if (file) {
        wallOfFameDataDTO.imageUrl = file.filename;
      } else {
        wallOfFameDataDTO.imageUrl = '';
      }
      const data = await this.wallOfFameService.updateWallOfFame(
        request.params.id,
        wallOfFameDataDTO
      );
      response.success(
        data,
        HttpStatusCode.CREATED,
        'Wall Of fame updated successfully'
      );
    } catch (error: any) {
      response.error(
        'Failed to update Wall Of fame',
        HttpStatusCode.BAD_REQUEST,
        error.message
      );
    }
  };
}
