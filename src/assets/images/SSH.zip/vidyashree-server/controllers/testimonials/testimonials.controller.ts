import { TestimonialsAddDTO } from '../../dto/testimonials/testimonials.add.dto';
import { TestimonialsUpdateDTO } from '../../dto/testimonials/testimonials.update.dto';
import TestimonialsService from '../../services/testimonial.service';
import HttpStatusCode from '../../util/http-status-code';

export default class TestimonialsController {
  readonly testimonialsService = new TestimonialsService();
  getTestimonials = async (request: any, response: any) => {
    try {
      const data = await this.testimonialsService.getTestimonials();
      response.success(data);
    } catch (error: any) {
      response.error(
        'Failed to save Testimonial',
        HttpStatusCode.BAD_REQUEST,
        error.message
      );
    }
  };
  getTestimonialsById = async () => {};
  addTestimonials = async (request: any, response: any) => {
    try {
      const testimonialDataDTO: TestimonialsAddDTO = request.data;
      const data =
        await this.testimonialsService.createTestimonials(testimonialDataDTO);
      response.success(
        data,
        HttpStatusCode.CREATED,
        'Testimonial created successfully'
      );
    } catch (error: any) {
      response.error(
        'Failed to save Testimonial',
        HttpStatusCode.BAD_REQUEST,
        error.message
      );
    }
  };
  deleteTestimonials = async (request: any, response: any) => {
    try {
      const testimonialId: string = request.params.id;
      const data =
        await this.testimonialsService.deleteTestimonial(testimonialId);
      response.success(
        data,
        HttpStatusCode.OK,
        'Testimonial deleted successfully'
      );
    } catch (error: any) {
      response.error(
        'Failed to delete Testimonial',
        HttpStatusCode.BAD_REQUEST,
        error.message
      );
    }
  };
  updateTestimonials = async (request: any, response: any) => {
    try {
      const testimonialDataDTO: TestimonialsUpdateDTO = request.data;
      const data = await this.testimonialsService.updateTestimonials(
        request.params.id,
        testimonialDataDTO
      );
      response.success(
        data,
        HttpStatusCode.CREATED,
        'Testimonial updated successfully'
      );
    } catch (error: any) {
      response.error(
        'Failed to update Testimonial',
        HttpStatusCode.BAD_REQUEST,
        error.message
      );
    }
  };
}
