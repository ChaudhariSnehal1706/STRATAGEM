import ChapterAddDto from '../../dto/chapters/chapters.add.dto';
import ChapterUpdateDto from '../../dto/chapters/chapters.update.dto';
import ChapterService from '../../services/chapter.service';
import HttpStatusCode from '../../util/http-status-code';

export default class ChapterController {
  readonly chapterService = new ChapterService();
  getChapter = async (request: any, response: any) => {
    try {
      const data = await this.chapterService.getChapter(request.query);
      response.success(data);
    } catch (error: any) {
      response.error(
        'Failed to save chapter',
        HttpStatusCode.BAD_REQUEST,
        error.message
      );
    }
  };
  addChapter = async (request: any, response: any) => {
    try {
      const chapterDataDTO: ChapterAddDto = request.data;
      const data = await this.chapterService.createChapter(chapterDataDTO);
      response.success(
        data,
        HttpStatusCode.CREATED,
        'Chapter created successfully'
      );
    } catch (error: any) {
      response.error(
        'Failed to save chapter',
        HttpStatusCode.BAD_REQUEST,
        error.message
      );
    }
  };

  updateChapter = async (request: any, response: any) => {
    try {
      const chapterDataDto: ChapterUpdateDto = request.data;
      const data = await this.chapterService.updateChapter(
        request.params.id,
        chapterDataDto
      );
      response.success(data, HttpStatusCode.OK, 'Chapter updated successfully');
    } catch (error: any) {
      response.error(
        'Failed to update chapter',
        HttpStatusCode.BAD_REQUEST,
        error.message
      );
    }
  };
  deleteChapter = async (request: any, response: any) => {
    try {
      const chapterId: string = request.params.id;
      const data = await this.chapterService.deleteChapter(chapterId);
      response.success(data, HttpStatusCode.OK, 'Chapter deleted successfully');
    } catch (error: any) {
      response.error(
        'Failed to delete chapter',
        HttpStatusCode.BAD_REQUEST,
        error.message
      );
    }
  };
  getChapterById = async (request: any, response: any) => {
    try {
      const { id } = request.params;
      const chapter = await this.chapterService.getChapterById(id);
      response.success(chapter);
    } catch (error: any) {
      response.error(
        'Failed to fetch chapter',
        HttpStatusCode.BAD_REQUEST,
        error.message
      );
    }
  };
}
