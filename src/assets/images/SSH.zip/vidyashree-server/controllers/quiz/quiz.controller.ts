import QuizService from '../../services/quiz.service';
import { QuizUpdateDTO } from '../../dto/quiz/quiz.update.dto';
import HttpStatusCode from '../../util/http-status-code';
import { QuizAddDTO } from '../../dto/quiz/quiz.add.dto';

export default class QuizController {
  readonly quizService = new QuizService();

  getQuiz = async (request: any, response: any) => {
    try {
      const data = await this.quizService.getQuiz();
      response.success(data);
    } catch (error: any) {
      response.error(
        'Failed to save quiz',
        HttpStatusCode.BAD_REQUEST,
        error.message
      );
    }
  };
  getQuizById = async (request: any, response: any) => {};
  addQuiz = async (request: any, response: any) => {
    try {
      const quizDataDTO: QuizAddDTO = request.data;
      const data = await this.quizService.createQuiz(quizDataDTO);
      response.success(
        data,
        HttpStatusCode.CREATED,
        'Quiz created successfully'
      );
    } catch (error: any) {
      response.error(
        'Failed to save Quiz',
        HttpStatusCode.BAD_REQUEST,
        error.message
      );
    }
  };
  deleteQuiz = async (request: any, response: any) => {
    try {
      const quizId: string = request.params.id;
      const data = await this.quizService.deleteQuiz(quizId);
      response.success(data, HttpStatusCode.OK, 'Quiz deleted successfully');
    } catch (error: any) {
      response.error(
        'Failed to delete Quiz',
        HttpStatusCode.BAD_REQUEST,
        error.message
      );
    }
  };
  updateQuiz = async (request: any, response: any) => {
    try {
      const quizDataDTO: QuizUpdateDTO = request.data;
      const data = await this.quizService.updateQuiz(
        request.params.id,
        quizDataDTO
      );
      response.success(
        data,
        HttpStatusCode.CREATED,
        'Quiz updated successfully'
      );
    } catch (error: any) {
      response.error(
        'Failed to update Quiz',
        HttpStatusCode.BAD_REQUEST,
        error.message
      );
    }
  };
}
