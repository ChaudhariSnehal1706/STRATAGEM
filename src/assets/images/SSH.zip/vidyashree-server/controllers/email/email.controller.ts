import { Request, NextFunction } from 'express';
import HttpStatusCode from '../../util/http-status-code';
// The below client is used to send email functionality
import EmailService from '../../services/emailProvider.service';

export default class EmailController {
  readonly brevoEmailService = new EmailService();
  sendEmailUsingBrevo = async (
    request: Request,
    response: any,
    next: NextFunction
  ) => {
    try {
      const receiverList = [
        {
          email: 'pat.vishad@gmail.com ',
          name: 'Demo User',
        },
      ];

      const params = {
        name: 'John',
        surname: 'Doe',
      };

      // const data = await this.brevoEmailService.sendEmailUsingBrevo(
      //   1,
      //   receiverList,
      //   params
      // );
      // response.success(data);
    } catch (error: any) {
      console.log(error.message);
      response.error(
        'Unable to send email',
        HttpStatusCode.INTERNAL_SERVER_ERROR,
        error.message
      );
    }
  };

  sendEmailUsingSendGrid = async (
    request: Request,
    response: any,
    next: NextFunction
  ) => {
    try {
      const receiverList = [
        {
          email: 'pat.vishad@gmail.com ',
          name: 'Demo User',
        },
      ];

      const params = {
        total: '$ 239.85',
        items: [
          {
            text: 'New Line Sneakers',
            image:
              'https://marketing-image-production.s3.amazonaws.com/uploads/8dda1131320a6d978b515cc04ed479df259a458d5d45d58b6b381cae0bf9588113e80ef912f69e8c4cc1ef1a0297e8eefdb7b270064cc046b79a44e21b811802.png',
            price: '$ 79.95',
          },
          {
            text: 'Old Line Sneakers',
            image:
              'https://marketing-image-production.s3.amazonaws.com/uploads/3629f54390ead663d4eb7c53702e492de63299d7c5f7239efdc693b09b9b28c82c924225dcd8dcb65732d5ca7b7b753c5f17e056405bbd4596e4e63a96ae5018.png',
            price: '$ 79.95',
          },
          {
            text: 'Blue Line Sneakers',
            image:
              'https://marketing-image-production.s3.amazonaws.com/uploads/00731ed18eff0ad5da890d876c456c3124a4e44cb48196533e9b95fb2b959b7194c2dc7637b788341d1ff4f88d1dc88e23f7e3704726d313c57f350911dd2bd0.png',
            price: '$ 79.95',
          },
        ],
        receipt: true,
        name: 'Sample Name',
        address01: '1234 Fake St.',
        address02: 'Apt. 123',
        city: 'Place',
        state: 'CO',
        zip: '80202',
      };

      // const data = await this.brevoEmailService.sendEmailUsingSendgrid(
      //   'd-12345678901234567890123456789012',
      //   receiverList,
      //   params
      // );
      // response.success(data);
    } catch (error: any) {
      console.log(error.message);
      response.error(
        'Unable to send email',
        HttpStatusCode.INTERNAL_SERVER_ERROR,
        error.message
      );
    }
  };
}
