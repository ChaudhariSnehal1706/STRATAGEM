import { faqAddDTO } from '../../dto/faq/faq.add.dto';
import { FaqUpdateDTO } from '../../dto/faq/faq.update.dto';
import FaqService from '../../services/faq.service';
import PartnerService from '../../services/partner.service';
import HttpStatusCode from '../../util/http-status-code';

export default class FaqController {
  readonly faqService = new FaqService();
  getFaq = async (request: any, response: any) => {
    try {
      const data = await this.faqService.getFaq();
      response.success(data);
    } catch (error: any) {
      response.error(
        'Failed to save FAQ',
        HttpStatusCode.BAD_REQUEST,
        error.message
      );
    }
  };
  getFaqById = async (request: any, response: any) => {};
  addFaq = async (request: any, response: any) => {
    try {
      const faqDataDTO: faqAddDTO = request.data;
      const data = await this.faqService.createFaq(faqDataDTO);
      response.success(
        data,
        HttpStatusCode.CREATED,
        'FAQ created successfully'
      );
    } catch (error: any) {
      response.error(
        'Failed to save FAQ',
        HttpStatusCode.BAD_REQUEST,
        error.message
      );
    }
  };
  deleteFaq = async (request: any, response: any) => {
    try {
      const faqID: string = request.params.id;
      const data = await this.faqService.deleteFaq(faqID);
      response.success(data, HttpStatusCode.OK, 'FAQ deleted successfully');
    } catch (error: any) {
      response.error(
        'Failed to delete FAQ',
        HttpStatusCode.BAD_REQUEST,
        error.message
      );
    }
  };
  updateFaq = async (request: any, response: any) => {
    try {
      const faqDataDTO: FaqUpdateDTO = request.data;
      const data = await this.faqService.updateFaq(
        request.params.id,
        faqDataDTO
      );
      response.success(
        data,
        HttpStatusCode.CREATED,
        'FAQ updated successfully'
      );
    } catch (error: any) {
      response.error(
        'Failed to update FAQ',
        HttpStatusCode.BAD_REQUEST,
        error.message
      );
    }
  };
}
