import { SubCategoriesAddDTO } from '../../dto/subcategories/subcategories.add.dto';
import { SubCategoriesUpdateDTO } from '../../dto/subcategories/subcategories.update.dto';
import SubcategoryService from '../../services/subcategory.service';
import HttpStatusCode from '../../util/http-status-code';

export default class SubCategoriesController {
  readonly subcategoryService = new SubcategoryService();

  getSubCategories = async (request: any, response: any) => {
    try {
      const query = request.query;
      console.log(query)
      const data = await this.subcategoryService.getSubcategory(query);
      response.success(data);
    } catch (error: any) {
      response.error(
        'Failed to save subcategory',
        HttpStatusCode.BAD_REQUEST,
        error.message
      );
    }
  };

  deleteSubcategory = async (request: any, response: any) => {
    try {
      const subcategoryId: string = request.params.id;
      const data =
        await this.subcategoryService.deleteSubcategory(subcategoryId);
      response.success(
        data,
        HttpStatusCode.OK,
        'Subcategory deleted successfully'
      );
    } catch (error: any) {
      response.error(
        'Failed to delete Subcategory',
        HttpStatusCode.BAD_REQUEST,
        error.message
      );
    }
  };

  getSubCategoriesById = (request: any, response: any) => {};

  addSubCategories = async (request: any, response: any) => {
    try {
      const subcategoryDataDTO: SubCategoriesAddDTO = request.data;
      const data =
        await this.subcategoryService.createSubcategory(subcategoryDataDTO);
      response.success(
        data,
        HttpStatusCode.CREATED,
        'SubCategory created successfully'
      );
    } catch (error: any) {
      response.error(
        'Failed to save category',
        HttpStatusCode.BAD_REQUEST,
        error.message
      );
    }
  };

  deleteSubCategories = async (request: any, response: any) => {
    try {
      const categoryId: string = request.params.id;
      const data = await this.subcategoryService.deleteSubcategory(categoryId);
      response.success(
        data,
        HttpStatusCode.OK,
        'SubCategory deleted successfully'
      );
    } catch (error: any) {
      response.error(
        'Failed to delete Sub Category',
        HttpStatusCode.BAD_REQUEST,
        error.message
      );
    }
  };

  updateSubCategories = async (request: any, response: any) => {
    try {
      const subcategoryDataDTO: SubCategoriesUpdateDTO = request.data;
      const data = await this.subcategoryService.updateSubcategory(
        request.params.id,
        subcategoryDataDTO
      );
      response.success(
        data,
        HttpStatusCode.CREATED,
        'SubCategory updated successfully'
      );
    } catch (error: any) {
      response.error(
        'Failed to update subcategory',
        HttpStatusCode.BAD_REQUEST,
        error.message
      );
    }
  };

  getSubCategoriesByCategoryId = async (request: any, response: any) => {
    try {
      const categoryId: string = request.params.categoryId;
      const data =
        await this.subcategoryService.getSubCategoriesByCategoryId(categoryId);
      response.success(data);
    } catch (error: any) {
      response.error(
        'Failed to fetch subcategories by category ID',
        HttpStatusCode.BAD_REQUEST,
        error.message
      );
    }
  };
}
