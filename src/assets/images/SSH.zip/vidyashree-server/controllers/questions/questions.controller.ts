import QuestionsAddDto from "../../dto/questions/questions.add.dto";
import QuestionsUpdateDto from "../../dto/questions/questions.update.dto";
import QuestionService from "../../services/question.service";
import HttpStatusCode from "../../util/http-status-code";

export default class QuestionController{
    readonly questionService = new QuestionService();
    getQuestions = async (request: any, response: any) => {
        try {
            const query = request.query;
            const data = await this.questionService.getQuestions(query);
            response.success(data);
        } catch (error: any) {
            response.error(
                'Failed to save question',
                HttpStatusCode.BAD_REQUEST,
                error.message
            )
        }
    }
    createQuestion = async (request: any, response: any) => {
        try {
            const questionDataDto : QuestionsAddDto= request.data;
            const data = await this.questionService.createQuestion(questionDataDto);
            response.success(data,
                HttpStatusCode.CREATED,
                'Question created successfully'
            );
        } catch (error: any) {
            response.error(
                'Failed to create question',
                HttpStatusCode.BAD_REQUEST,
                error.message
            )
        }
    }
    updateQuestion = async (request: any, response: any) => {
        try {
            const questionDataDto: QuestionsUpdateDto = request.data;
            const data = await this.questionService.updateQuestion(request.params.id, questionDataDto);
            response.success(data,
                HttpStatusCode.CREATED,
                'Question updated successfully'
            );
        } catch (error: any) {
            response.error(
                'Failed to update question',
                HttpStatusCode.BAD_REQUEST,
                error.message
            )
        }
    }
    deleteQuestion = async (request: any, response: any) => {
        try {
            const questionId = request.params.id;
            const data = await this.questionService.deleteQuestion(questionId);
            response.success(data,
                HttpStatusCode.OK,
                'Question deleted successfully'
            );
        } catch (error: any) {
            response.error(
                'Failed to delete question',
                HttpStatusCode.BAD_REQUEST,
                error.message
            )
        }
    }
}