import { BlogsCategoryAddDTO } from '../../dto/blogs-category/blogs.catergory.add.dto';
import { BlogsCategoryUpdateDTO } from '../../dto/blogs-category/blogs.catergory.update.dto';
import BlogCategoryService from '../../services/blog.category.service';
import HttpStatusCode from '../../util/http-status-code';

export default class BlogCategoryController {
  readonly blogCategoryService = new BlogCategoryService();
  getBlogCategory = async (request: any, response: any) => {
    try {
      const data = await this.blogCategoryService.getBlogCategory(
        request.query
      );

      response.success(data);
    } catch (error: any) {
      response.error(
        'Failed to save blog Category',
        HttpStatusCode.BAD_REQUEST,
        error.message
      );
    }
  };
  getBlogCategoryById = async (request: any, response: any) => {
    try {
      const { id } = request.params;
      const blog = await this.blogCategoryService.getBlogCategoryById(id);
      response.success(blog);
    } catch (error: any) {
      console.log(error);
      response.error(
        'Failed to save blog Category',
        HttpStatusCode.BAD_REQUEST,
        error.message
      );
    }
  };
  addBlogCategory = async (request: any, response: any) => {
    try {
      const blogDataDTO: BlogsCategoryAddDTO = request.data;

      const data =
        await this.blogCategoryService.createBlogCategory(blogDataDTO);
      response.success(
        data,
        HttpStatusCode.CREATED,
        'Blog Catgeory created successfully'
      );
    } catch (error: any) {
      response.error(
        'Failed to save Blog Category',
        HttpStatusCode.BAD_REQUEST,
        error.message
      );
    }
  };
  deleteBlogCategory = async (request: any, response: any) => {
    try {
      const blogId: string = request.params.id;
      const data = await this.blogCategoryService.deleteBlogCategory(blogId);
      response.success(
        data,
        HttpStatusCode.OK,
        'Blog Category deleted successfully'
      );
    } catch (error: any) {
      response.error(
        'Failed to delete Blog Category',
        HttpStatusCode.BAD_REQUEST,
        error.message
      );
    }
  };
  updateBlogCategory = async (request: any, response: any) => {
    try {
      const blogDataDTO: BlogsCategoryUpdateDTO = request.data;
      const data = await this.blogCategoryService.updateBlogCategory(
        request.params.id,
        blogDataDTO
      );
      response.success(
        data,
        HttpStatusCode.CREATED,
        'Blog Category updated successfully'
      );
    } catch (error: any) {
      response.error(
        'Failed to update Blog Category',
        HttpStatusCode.BAD_REQUEST,
        error.message
      );
    }
  };
}
