import { TopicsAddDTO } from "../../dto/topics/topic.add.dto";
import { TopicsUpdateDTO } from "../../dto/topics/topic.update.dto";
import TopicService from "../../services/topic.service";
import HttpStatusCode from "../../util/http-status-code";

export default class TopicController {
    readonly topicService = new TopicService();
    getTopics = async (request: any, response: any) => {
        try {
            const data = await this.topicService.getTopics(request.query);
            response.success(data);
        } catch (error: any) {
            response.error(
                'Failed to fetch topics',
                HttpStatusCode.BAD_REQUEST,
                error.message
            )}
    }
    addTopic = async (request: any, response: any) => {
        try {
            const topicDataDTO: TopicsAddDTO = request.data;
            const data = await this.topicService.createTopic(topicDataDTO);
            response.success(
                data,
                HttpStatusCode.CREATED,
                'Topic created successfully'
            );
        } catch (error: any) {
            response.error(
                'Failed to save topic',
                HttpStatusCode.BAD_REQUEST,
                error.message
            )}
    }
    updateTopic = async (request: any, response: any) => {
        try {
            
            const topicDataDTO: TopicsUpdateDTO = request.data;
            const data = await this.topicService.updateTopic(request.params.id, topicDataDTO);
            response.success(
                data,
                HttpStatusCode.OK,
                'Topic updated successfully'
            );
        } catch (error: any) {
            response.error(
                'Failed to update topic',
                HttpStatusCode.BAD_REQUEST,
                error.message
            )}
    }
    deleteTopic = async (request: any, response: any) => {
        try {
            const topicId = request.params.id
            const data = await this.topicService.deleteTopic(topicId);
            response.success(
                data,
                HttpStatusCode.OK,
                'Topic deleted successfully'
            );
        } catch (error: any) {
            response.error(
                'Failed to delete topic',
                HttpStatusCode.BAD_REQUEST,
                error.message
            )}
    }
    // getTopicById = async (request: any, response: any) => {}
}