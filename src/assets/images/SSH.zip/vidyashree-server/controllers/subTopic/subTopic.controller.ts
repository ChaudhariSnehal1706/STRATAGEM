import { SubTopicsAddDTO } from '../../dto/subTopics/subTopics.add.dto';
import { SubTopicsUpdateDTO } from '../../dto/subTopics/subTopics.update.dto';
import { SubCategoriesAddDTO } from '../../dto/subcategories/subcategories.add.dto';
import SubTopicService from '../../services/subTopic.service';
import HttpStatusCode from '../../util/http-status-code';

export default class SubTopicController {
  readonly subTopicService = new SubTopicService();
  getSubTopics = async (request: any, response: any) => {
    try {
      const data = await this.subTopicService.getSubTopic(request.query);
      response.success(data);
    } catch (error: any) {
      response.error(
        'Failed to save sub topic',
        HttpStatusCode.BAD_REQUEST,
        error.message
      );
    }
  }
    addSubTopic = async (request: any, response: any) => {
        try {
            const subTopicDataDTO: SubTopicsAddDTO = request.data;
            const data = await this.subTopicService.createSubTopic(subTopicDataDTO);
            response.success(data,
                HttpStatusCode.CREATED,
                'Sub Topic created successfully'
            );
        } catch (error: any) {
            response.error(
                'Failed to create sub topic',
                HttpStatusCode.BAD_REQUEST,
                error.message
            )
        }

    }
  
  updateSubTopic = async (request: any, response: any) => {
    try {
      const subTopicDataDTO: SubTopicsUpdateDTO = request.data;
      const data = await this.subTopicService.updateSubTopic(
        request.params.id,
        subTopicDataDTO
      );
      response.success(
        data,
        HttpStatusCode.OK,
        'Sub Topic updated successfully'
      );
    } catch (error: any) {
      response.error(
        'Failed to Update sub topic',
        HttpStatusCode.BAD_REQUEST,
        error.message
      );
    }
  };
  deleteSubTopic = async (request: any, response: any) => {
    try {
      const subTopicId = request.params.id;
      const data = await this.subTopicService.deleteSubTopic(subTopicId);
      response.success(
        data,
        HttpStatusCode.OK,
        'Sub Topic deleted successfully'
      );
    } catch (error: any) {
      response.error(
        'Failed to delete Sub Topic',
        HttpStatusCode.BAD_REQUEST,
        error.message
      );
    }
  };
}
