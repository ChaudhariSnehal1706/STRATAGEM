import { PartnersUpdateDTO } from '../../dto/partners/partner.update.dto';
import { PartnersAddDTO } from '../../dto/partners/partner.add.dto';
import PartnerService from '../../services/partner.service';
import HttpStatusCode from '../../util/http-status-code';

export default class PartnerController {
  readonly partnerService = new PartnerService();
  getPartners = async (request: any, response: any) => {
    try {
      const data = await this.partnerService.getPartner();
      response.success(data);
    } catch (error: any) {
      response.error(
        'Failed to save partner',
        HttpStatusCode.BAD_REQUEST,
        error.message
      );
    }
  };
  getPartnersById = async (request: any, response: any) => {};
  addPartners = async (request: any, response: any) => {
    try {
      const file = request.file;
      if (!file) {
        return response.error(
          'Failed to save partners',
          HttpStatusCode.BAD_REQUEST,
          'Please choose partners image'
        );
      }
      const partnerDataDTO: PartnersAddDTO = request.data;
      partnerDataDTO.logoURL = file.filename;
      const data = await this.partnerService.createPartner(partnerDataDTO);
      response.success(
        data,
        HttpStatusCode.CREATED,
        'Partner created successfully'
      );
    } catch (error: any) {
      response.error(
        'Failed to save Partner',
        HttpStatusCode.BAD_REQUEST,
        error.message
      );
    }
  };
  deletePartners = async (request: any, response: any) => {
    try {
      const partnerId: string = request.params.id;
      const data = await this.partnerService.deletePartner(partnerId);
      response.success(data, HttpStatusCode.OK, 'Partner deleted successfully');
    } catch (error: any) {
      response.error(
        'Failed to delete Partner',
        HttpStatusCode.BAD_REQUEST,
        error.message
      );
    }
  };
  updatePartners = async (request: any, response: any) => {
    try {
      const partnerDataDTO: PartnersUpdateDTO = request.data;
      const file = request.file;
      if (file) {
        partnerDataDTO.logoURL = file.filename;
      } else {
        partnerDataDTO.logoURL = '';
      }
      const data = await this.partnerService.updatePartner(
        request.params.id,
        partnerDataDTO
      );
      response.success(
        data,
        HttpStatusCode.CREATED,
        'Partner updated successfully'
      );
    } catch (error: any) {
      response.error(
        'Failed to update Partner',
        HttpStatusCode.BAD_REQUEST,
        error.message
      );
    }
  };
}
