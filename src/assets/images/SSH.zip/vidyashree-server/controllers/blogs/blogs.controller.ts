import { BlogsAddDTO } from '../../dto/blogs/blogs.add.dto';
import { BlogsUpdateDTO } from '../../dto/blogs/blogs.update.dto';
import BlogService from '../../services/blog.service';
import HttpStatusCode from '../../util/http-status-code';

export default class BlogController {
  readonly blogService = new BlogService();
  getBlogs = async (request: any, response: any) => {
    try {
      const data = await this.blogService.getBlog(request.query);
      response.success(data);
    } catch (error: any) {
      response.error(
        'Failed to save blog',
        HttpStatusCode.BAD_REQUEST,
        error.message
      );
    }
  };
  getBlogById = async (request: any, response: any) => {
    try {
      const { id } = request.params;
      const blog = await this.blogService.getBlogById(id);
      response.success(blog);
    } catch (error: any) {
      console.log(error);
      response.error(
        'Failed to fetch blog',
        HttpStatusCode.BAD_REQUEST,
        error.message
      );
    }
  };
  addBlog = async (request: any, response: any) => {
    try {
      const file = request.file;
      if (!file) {
        return response.error(
          'Failed to save Blog Category',
          HttpStatusCode.BAD_REQUEST,
          'Please choose blog image'
        );
      }
      const blogDataDTO: BlogsAddDTO = request.data;
      blogDataDTO.imageUrl = file.filename;
      const data = await this.blogService.createBlog(blogDataDTO);
      response.success(
        data,
        HttpStatusCode.CREATED,
        'Blog created successfully'
      );
    } catch (error: any) {
      response.error(
        'Failed to save BLog',
        HttpStatusCode.BAD_REQUEST,
        error.message
      );
    }
  };
  deleteBlog = async (request: any, response: any) => {
    try {
      const blogId: string = request.params.id;
      const data = await this.blogService.deleteBlog(blogId);
      response.success(data, HttpStatusCode.OK, 'Blog deleted successfully');
    } catch (error: any) {
      response.error(
        'Failed to delete Blog',
        HttpStatusCode.BAD_REQUEST,
        error.message
      );
    }
  };
  updateBlog = async (request: any, response: any) => {
    try {
      console.log(request.data);
      const blogDataDTO: BlogsUpdateDTO = request.data;
      const file = request.file;
      if (file) {
        blogDataDTO.imageUrl = file.filename;
      } else {
        blogDataDTO.imageUrl = '';
      }
      const data = await this.blogService.updateBlog(
        request.params.id,
        blogDataDTO
      );
      response.success(data, HttpStatusCode.OK, 'Blog updated successfully');
    } catch (error: any) {
      response.error(
        'Failed to update Blog',
        HttpStatusCode.BAD_REQUEST,
        error.message
      );
    }
  };
  getRecentBlog = async (request: any, response: any) => {
    try {
      const data = await this.blogService.getRecentBlog();
      response.success(data);
    } catch (error: any) {
      response.error(
        'Failed to get blog',
        HttpStatusCode.BAD_REQUEST,
        error.message
      );
    }
  };
}
