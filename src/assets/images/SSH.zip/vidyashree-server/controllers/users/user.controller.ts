import { NextFunction, Request, Response } from 'express';
import HttpStatusCode from './../../util/http-status-code';
import { UserAddDTO } from '../../dto/users/user.add.dto';
import UserService from '../../services/user.service';
import { UserUpdateDTO } from '../../dto/users/user.update.dto';
/**
 * This controller handle all the resource request related to the
 * User resource
 */
export default class UserController {
  readonly userService = new UserService();

  getUser = async (request: any, response: any) => {
    try {
      const data = await this.userService.getUser();
      response.success(data);
    } catch (error: any) {
      response.error(
        'Failed to save user',
        HttpStatusCode.BAD_REQUEST,
        error.message
      );
    }
  };
  addUser = async (request: any, response: any) => {
    try {
      const userDataDTO: UserAddDTO = request.data;
      const data = await this.userService.createUser(userDataDTO);
      response.success(
        data,
        HttpStatusCode.CREATED,
        'User created successfully'
      );
    } catch (error: any) {
      response.error(
        'Failed to save User',
        HttpStatusCode.BAD_REQUEST,
        error.message
      );
    }
  };
  loginUser = async (request: any, response: any) => {
    // try {
    //   const userDataDTO: UserLoginDTO = request.data;
    //   const data =
    //     await this.userService.validateUser(userDataDTO);
    //   if (data) {
    //     response.success(
    //       data,
    //       HttpStatusCode.CREATED,
    //       'User created successfully'
    //     );
    //   } else {
    //     response.error(
    //       'Failed to authenticate user',
    //       HttpStatusCode.BAD_REQUEST,
    //       'Invalid username and password'
    //     );
    //   }
    // } catch (error: any) {
    //   response.error(
    //     'Failed to save User',
    //     HttpStatusCode.BAD_REQUEST,
    //     error.message
    //   );
    // }
  };
  removeUser = (request: Request, response: any, next: NextFunction) => {};

  updateUser = async (request: any, response: any) => {
    try {
      const userDTOData: UserUpdateDTO = request.data;
      const data = await this.userService.updateUser(
        request.params.id,
        userDTOData
      );
      response.success(
        data,
        HttpStatusCode.CREATED,
        'SubCategory updated successfully'
      );
    } catch (error: any) {
      response.error(
        'Failed to update subcategory',
        HttpStatusCode.BAD_REQUEST,
        error.message
      );
    }
  };
}
