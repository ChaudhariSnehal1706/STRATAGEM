import { BoardsAddDto } from '../../dto/boards/boards.add.dto';
import { BoardsUpdateDto } from '../../dto/boards/boards.update.dto';
import BoardService from '../../services/board.service';
import HttpStatusCode from '../../util/http-status-code';
export default class BoardController {
  readonly boardService = new BoardService();
  getBoard = async (request: any, response: any) => {
    try {
      const query = request.query
      const data = await this.boardService.getBoard(query);
      response.success(data);
    } catch (error: any) {
      response.error(
        'Failed to save Board',
        HttpStatusCode.BAD_REQUEST,
        error.message
      );
    }
  };
  getBoardById = async (request: any, response: any) => {};
  createBoard = async (request: any, response: any) => {
    try {
      const boardDataDto: BoardsAddDto = request.data;
      const data = await this.boardService.createBoard(boardDataDto);
      response.success(
        data,
        HttpStatusCode.CREATED,
        'Board created successfully'
      );
    } catch (error: any) {
      response.error(
        'Failed to save Board',
        HttpStatusCode.BAD_REQUEST,
        error.message
      );
    }
  };
  updateBoard = async (request: any, response: any) => {
    try {
      const boardDataDto: BoardsUpdateDto = request.data;
      const data = await this.boardService.updateBoard(
        request.params.id,
        boardDataDto
      );
      response.success(
        data,
        HttpStatusCode.CREATED,
        'Board updated successfully'
      );
    } catch (error: any) {
      response.error(
        'Failed to save Board',
        HttpStatusCode.BAD_REQUEST,
        error.message
      );
    }
  };
  deleteBoard = async (request: any, response: any) => {
    try {
      const boardId: string = request.params.id;
      const data = await this.boardService.deleteBoard(boardId);
      response.success(data, HttpStatusCode.OK, 'Board deleted successfully');
    } catch (error: any) {
      response.error(
        'Failed to save Board',
        HttpStatusCode.BAD_REQUEST,
        error.message
      );
    }
  };
}
