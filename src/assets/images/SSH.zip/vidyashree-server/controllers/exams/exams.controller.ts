import ExamService from '../../services/exam.service';
import HttpStatusCode from '../../util/http-status-code';

export default class ExamsController {
  readonly examService = new ExamService();
  getExams = async (request: any, response: any) => {
    try {
      const data = await this.examService.getExam();
      response.success(data);
    } catch (error: any) {
      response.error(
        'Failed to save exam',
        HttpStatusCode.BAD_REQUEST,
        error.message
      );
    }
  };
  getExamsById = async (request: any, response: any) => {};
  addExams = async (request: any, response: any) => {};
  deleteExams = async (request: any, response: any) => {};
  updateExams = (request: any, response: any) => {};
}
