import { CategoriesAddDTO } from '../../dto/categories/categories.add.dto';
import { CategoriesUpdateDTO } from '../../dto/categories/categories.update.dto';
import CategoryService from '../../services/category.service';
import HttpStatusCode from '../../util/http-status-code';

export default class CategoriesController {
  readonly categoryService = new CategoryService();
  getCategories = async (request: any, response: any) => {
    try {
      const data = await this.categoryService.getCategories();
      response.success(data);
    } catch (error: any) {
      response.error(
        'Failed to save category',
        HttpStatusCode.BAD_REQUEST,
        error.message
      );
    }
  };
  getCategoriesById = async (request: any, response: any) => {};
  addCategories = async (request: any, response: any) => {
    try {
      const file = request.file;
      if (!file) {
        return response.error(
          'Failed to save Category',
          HttpStatusCode.BAD_REQUEST,
          'Please choose category image'
        );
      }
      const categoryDataDTO: CategoriesAddDTO = request.data;
      categoryDataDTO.iconUrl = file.filename;
      const data = await this.categoryService.createCategory(categoryDataDTO);
      response.success(
        data,
        HttpStatusCode.CREATED,
        'Category created successfully'
      );
    } catch (error: any) {
      response.error(
        'Failed to save category',
        HttpStatusCode.BAD_REQUEST,
        error.message
      );
    }
  };
  deleteCategories = async (request: any, response: any) => {
    try {
      const categoryId: string = request.params.id;
      const data = await this.categoryService.deleteCategory(categoryId);
      response.success(
        data,
        HttpStatusCode.OK,
        'Category deleted successfully'
      );
    } catch (error: any) {
      response.error(
        'Failed to delete Category',
        HttpStatusCode.BAD_REQUEST,
        error.message
      );
    }
  };
  updateCategories = async (request: any, response: any) => {
    try {
      const categoryDataDTO: CategoriesUpdateDTO = request.data;
      const file = request.file;
      if (file) {
        categoryDataDTO.iconUrl = file.filename;
      } else {
        categoryDataDTO.iconUrl = '';
      }

      const data = await this.categoryService.updateCategory(
        request.params.id,
        categoryDataDTO
      );
      response.success(
        data,
        HttpStatusCode.CREATED,
        'Category updated successfully'
      );
    } catch (error: any) {
      response.error(
        'Failed to update category',
        HttpStatusCode.BAD_REQUEST,
        error.message
      );
    }
  };
}
