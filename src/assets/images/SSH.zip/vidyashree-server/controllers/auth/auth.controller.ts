import { NextFunction, Request, Response } from 'express';
import {
  ForgetPasswordRequestOtpDTO,
  ForgetPasswordVerifyOtpDTO,
  ResetPasswordDTO,
} from '../../dto/auth/student.register.dto';
import AuthService from '../../services/auth.service';
import { asyncErrorHandler } from '../../util/async-error-handler';
import HttpStatusCode from '../../util/http-status-code';

export default class AuthController {
  readonly authService = new AuthService();

  studentRegister = asyncErrorHandler(
    async (request: Request, response: Response, _next: NextFunction) => {
      const dto: any = request.body;
      const data = await this.authService.registerStudent(dto);
      response.status(HttpStatusCode.CREATED).json({
        message: 'Student registered successfully',
        data: data,
      });
    }
  );

  studentRegisterOtpVerify = asyncErrorHandler(
    async (request: Request, response: Response, _next: NextFunction) => {
      const dto: any = request.body;
      const data = await this.authService.studentRegisterOtpVerify(dto);
      response.status(HttpStatusCode.CREATED).json({
        message: 'OTP verified successfully',
        data: data,
      });
    }
  );

  studentLogin = asyncErrorHandler(
    async (request: Request, response: Response, _next: NextFunction) => {
      const dto: any = request.body;
      const data = await this.authService.studentLogin(dto);
      response.status(HttpStatusCode.OK).json(data);
    }
  );

  studentLoginOtpSend = asyncErrorHandler(
    async (request: Request, response: Response, _next: NextFunction) => {
      const dto: any = request.body;
      const data = await this.authService.studentLoginOtpSend(dto);
      response.status(HttpStatusCode.OK).json({
        message: 'OTP sent successfully',
        data: data,
      });
    }
  );

  studentLoginMobile = asyncErrorHandler(
    async (request: Request, response: Response, _next: NextFunction) => {
      const dto: any = request.body;
      const data = await this.authService.studentLoginMobile(dto);
      response.status(HttpStatusCode.OK).json({
        message: 'Logged in successfully',
        data: data,
      });
    }
  );

  initialUserDetail = asyncErrorHandler(
    async (request: any, response: Response, _next: NextFunction) => {
      const studentId = request?.user?._id;

      const data = await this.authService.initialUserDetail(studentId);
      response.status(HttpStatusCode.OK).json({
        message: 'data fetched successfully',
        data: data,
      });
    }
  );

  forgetPasswordRequestOtp = asyncErrorHandler(
    async (request: Request, response: Response, _next: NextFunction) => {
      const dto: ForgetPasswordRequestOtpDTO = request.body;
      const data = await this.authService.forgetPasswordRequestOtp(dto);
      response.status(HttpStatusCode.OK).json({
        message: 'OTP requested successfully',
        data: data,
      });
    }
  );

  forgetPasswordVerifyOtp = asyncErrorHandler(
    async (request: Request, response: Response, _next: NextFunction) => {
      const dto: ForgetPasswordVerifyOtpDTO = request.body;
      const data = await this.authService.forgetPasswordVerifyOtp(dto);
      response.status(HttpStatusCode.OK).json({
        message: 'OTP verified successfully',
        data: data,
      });
    }
  );

  resetPassword = asyncErrorHandler(
    async (request: Request, response: Response, _next: NextFunction) => {
      const dto: ResetPasswordDTO = request.body;
      const data = await this.authService.resetPassword(dto);
      response.status(HttpStatusCode.OK).json({
        message: 'Password reset successfully',
        data: data,
      });
    }
  );
}
