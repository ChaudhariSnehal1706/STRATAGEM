import { QuestionsTypeAddDTO } from '../../dto/questionType/questionTypes.add.dto';
import { QuestionsTypeUpdateDTO } from '../../dto/questionType/questionTypes.update.dto';
import QuestionTypeService from '../../services/questionType.service';
import HttpStatusCode from '../../util/http-status-code';

export default class QuestionTypeController {
  readonly questionTypeService = new QuestionTypeService();
  getQuestionType = async (request: any, response: any) => {
    try {
      const data = await this.questionTypeService.getQuestionType(
        request.query
      );
      response.success(data);
    } catch (error: any) {
      response.error(
        'Failed to save Question Type',
        HttpStatusCode.BAD_REQUEST,
        error.message
      );
    }
  };
  getQuestionTypeById = async (request: any, response: any) => {};
  addQuestionType = async (request: any, response: any) => {
    try {
      const questionTypeDataDTO: QuestionsTypeAddDTO = request.data;

      const data =
        await this.questionTypeService.createQuestionType(questionTypeDataDTO);
      response.success(
        data,
        HttpStatusCode.CREATED,
        'Question Type created successfully'
      );
    } catch (error: any) {
      response.error(
        'Failed to save Question Type',
        HttpStatusCode.BAD_REQUEST,
        error.message
      );
    }
  };
  deleteQuestionType = async (request: any, response: any) => {
    try {
      const questionTypeId: string = request.params.id;
      const data =
        await this.questionTypeService.deleteQuestionType(questionTypeId);
      response.success(
        data,
        HttpStatusCode.OK,
        'Question Type deleted successfully'
      );
    } catch (error: any) {
      response.error(
        'Failed to delete Question Type',
        HttpStatusCode.BAD_REQUEST,
        error.message
      );
    }
  };
  updateQuestionType = async (request: any, response: any) => {
    try {
      const questionTypeDataDTO: QuestionsTypeUpdateDTO = request.data;

      const data = await this.questionTypeService.updateQuestionType(
        request.params.id,
        questionTypeDataDTO
      );
      response.success(
        data,
        HttpStatusCode.CREATED,
        'Question Type updated successfully'
      );
    } catch (error: any) {
      response.error(
        'Failed to update Question Type',
        HttpStatusCode.BAD_REQUEST,
        error.message
      );
    }
  };
}
