import { NextFunction, Request } from 'express';
import BaseDTO from '../dto/base.dto';
import HttpStatusCode from './../util/http-status-code';

const ResponseFormatter = (_req: Request, res: any, next: NextFunction) => {
  // Success response
  res.success = (
    data: BaseDTO,
    status = HttpStatusCode.OK,
    message = 'Success'
  ) => {
    res.status(status).json({
      success: true,
      message,
      data,
    });
  };

  // Error response with details
  res.error = (
    message = 'Internal Server Error',
    statusCode = HttpStatusCode.INTERNAL_SERVER_ERROR,
    errorDetails = null
  ) => {
    res.status(statusCode).json({
      success: false,
      message,
      error: errorDetails,
    });
  };

  next();
};

export default ResponseFormatter;
