const multer = require('multer');
const path = require('path');
// Cloudinary Configuration
// cloudinary.config({
//     cloud_name: 'dgivdchdh',
//     api_key: '753851882298782',
//     api_secret: 'YOUR_API_SECRET'
//   });

//   // Multer Storage for Cloudinary
//   const storage = new CloudinaryStorage({
//     cloudinary: cloudinary,
//     params: {
//       folder: 'uploads',
//       allowed_formats: ['jpg', 'png'],
//       transformation: [
//         { width: 500, height: 500, crop: 'limit' },
//         { quality: 'auto', fetch_format: 'auto' } // Additional transformation parameters
//       ]
//     }
//   });

// Multer Middleware
const upload1 = multer({
  fileFilter: function (req: any, file: any, cb: any) {
    // Check file types here (example: allow only images)
    console.log(file);
    if (file.mimetype.startsWith('image/')) {
      cb(null, true);
    } else {
      cb(new Error('Only images are allowed!'));
    }
  },
  filename: (req: any, image: any, callback: any) => {
    console.log('---->', image);
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1e9);
    const originalName = image.originalname;
    const extension = originalName.split('.').pop(); // Get the original extension
    callback(null, uniqueSuffix + '.' + extension); // Generate custom filename with the original extension
  },
  dest: path.join(__dirname, '../public/uploads/'),
  // Destination folder
  limits: { fileSize: 10 * 1024 * 1024 }, // Max file size (10MB)
});

const storage = multer.diskStorage({
  destination: function (req: any, file: any, cb: any) {
    cb(null, path.join(__dirname, '../public/uploads/'));
  },
  filename: function (req: any, file: any, cb: any) {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1e9);
    console.log(file);
    let name: string = file.originalname;
    name = name.replace(' ', '_');
    cb(null, uniqueSuffix + '-' + name);
  },
});

const upload = multer({ storage: storage });
export default upload;
