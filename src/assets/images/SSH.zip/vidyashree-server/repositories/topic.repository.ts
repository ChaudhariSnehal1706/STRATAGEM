import mongoose from "mongoose";
import { ITopic, TopicModel } from "../models/topic.model";

export default class TopicRepository {
    async createTopic(topicData: ITopic): Promise<ITopic> {
        const createdTopic = await TopicModel.create(topicData);
        return createdTopic.toObject();
    }
    async getTopics(): Promise<ITopic[]> {
        return await TopicModel.find().populate({
            path: 'category',            
          }).populate({
            path: 'subcategory',            
          }).populate({
            path: 'board',            
          }).populate({
            path: 'subject',            
          }).populate({
            path: 'chapter',            
          });
    }
  
    async deleteTopic(id: string): Promise<ITopic[] | null> {
        const topicData: ITopic | null = await TopicModel.findById(id);
        if (!topicData) {
            throw new Error(`Topic not found for this id : ${id}`);
        }   
        return await TopicModel.findByIdAndDelete(id);
    }
    async updateTopic(id: string, topic: ITopic): Promise<ITopic | null> {
        const topicData: ITopic | null = await TopicModel.findById(id);
        if (!topicData) {
            throw new Error(`Topic not found for this id : ${id}`);
        }
        if(topic.board){
            topicData.board = topic.board;
        }
        if(topic.category){
            topicData.category = topic.category;
        } 
        if(topic.subcategory){
            topicData.subcategory = topic.subcategory;
        }
        if(topic.subject){
            topicData.subject = topic.subject;
        }
        if(topic.chapter){
            topicData.chapter = topic.chapter;
        }
        if(topic.topic){
            topicData.topic = topic.topic;
        }
        if(topic.status){
            topicData.status = topic.status;
        }
        return await TopicModel.findByIdAndUpdate({ _id: new mongoose.Types.ObjectId(id) },topicData);
    }
}
