import mongoose from 'mongoose';
import { ISubject, SubjectModel } from '../models/subjects.model';

export default class SubjectRepository {
  async createSubject(SubjectData: ISubject): Promise<ISubject> {
    const createdSubject = await SubjectModel.create(SubjectData);
    return createdSubject.toObject();
  }
  async getSubject(query: any): Promise<ISubject[]> {
    return await SubjectModel.find(query).populate({
      path: 'category',
      options: { sort: { name: 1 } } // Sort by author's name in ascending order
    }).populate({
      path: 'subcategory',
      options: { sort: { name: 1 } } // Sort by author's name in ascending order
    }).populate({
      path: 'board',
      options: { sort: { name: 1 } } // Sort by author's name in ascending order
    });
  }
  async deleteSubject(id: string): Promise<ISubject[] | null> {
    const subjectData: ISubject | null = await SubjectModel.findById(id);
    if (!subjectData) {
      throw new Error(`Subject not found for this id : ${id}`);
    }
    return await SubjectModel.findByIdAndDelete(id);
  }
  async updateSubject(id: string, subject: ISubject): Promise<ISubject | null> {
    const subjectData: ISubject | null = await SubjectModel.findById(id);
    if (!subjectData) {
      throw new Error(`Subject not found for this id : ${id}`);
    }
    //update name when only name is passed from the request
    if (subject.iconurl) {
      subjectData.iconurl = subject.iconurl;
    }

    if (subject.name) {
      subjectData.name = subject.name;
    }

    if (subject.status != null) {
      subjectData.status = subject.status;
    }
    if (subject.subcategory != null) {
      subjectData.subcategory = subject.subcategory;
    }
    if(subject.board != null){
      subjectData.board = subject.board;
    }
    if(subject.category != null){
      subjectData.category = subject.category
    }
    return await SubjectModel.findOneAndReplace(
      { _id: new mongoose.Types.ObjectId(id) },
      subjectData
    );
  }

  async getSubjectsBySubcategoryId(subcategoryId: string): Promise<ISubject[]> {
    return SubjectModel.find({ subcategory: subcategoryId });
  }
  // Add more methods as needed
}
