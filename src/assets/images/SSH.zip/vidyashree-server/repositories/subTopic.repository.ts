import mongoose from "mongoose";
import { ISubTopic, SubTopicModel } from "../models/subTopic.model";

export default class SubTopicRespository {
  async createSubTopic(topicData: ISubTopic): Promise<ISubTopic> {
    const createdSubTopic = await SubTopicModel.create(topicData);
    return createdSubTopic.toObject();
  }
  async getSubTopic(query: any): Promise<ISubTopic[]> {
    return await SubTopicModel.find(query)
      .populate({
        path: 'category',
      })
      .populate({
        path: 'subcategory',
      })
      .populate({
        path: 'board',
      })
      .populate({
        path: 'subject',
      })
      .populate({
        path: 'chapter',
      })
      .populate({
        path: 'topic',
      });
  }
  async updateSubTopic(
    id: string,
    subTopic: ISubTopic
  ): Promise<ISubTopic | null> {
    const SubTopicData: ISubTopic | null = await SubTopicModel.findById(id);
    if (!SubTopicData) {
      throw new Error(`Topic not found for this id : ${id}`);
    }
    if (subTopic.board) {
      SubTopicData.board = subTopic.board;
    }
    if (subTopic.category) {
      SubTopicData.category = subTopic.category;
    }
    if (subTopic.subcategory) {
      SubTopicData.subcategory = subTopic.subcategory;
    }
    if (subTopic.subject) {
      SubTopicData.subject = subTopic.subject;
    }
    if (subTopic.chapter) {
      SubTopicData.chapter = subTopic.chapter;
    }
    if (subTopic.topic) {
      SubTopicData.topic = subTopic.topic;
    }
    if (subTopic.status) {
      SubTopicData.status = subTopic.status;
    }
    if (subTopic.subTopic) {
      SubTopicData.subTopic = subTopic.subTopic;
    }

    return await SubTopicModel.findByIdAndUpdate(
      { _id: new mongoose.Types.ObjectId(id) },
      SubTopicData
    );
  }
  async deleteSubTopic(id: string): Promise<any> {
    const SubTopicData: ISubTopic | null = await SubTopicModel.findById(id);
    if (!SubTopicData) {
      throw new Error(`Topic not found for this id : ${id}`);
    }
    return await SubTopicModel.findByIdAndDelete(id);
  }
}
/**
 * 
 * export default class SubTopicRespository {
    async createSubTopic(topicData: ISubTopic): Promise<ISubTopic> {
        const createdSubTopic = await SubTopicModel.create(topicData);
        return createdSubTopic.toObject();
    }
    async getSubTopic(query: any): Promise<ISubTopic[]> {
        return await SubTopicModel.find(query).populate({
            path: 'category',            
          }).populate({
            path: 'subcategory',            
          }).populate({
            path: 'board',            
          }).populate({
            path: 'subject',            
          }).populate({
            path: 'chapter',            
          }).populate({
            path: 'topic',
          });
    }
    async updateSubTopic(id: string, subTopic: ISubTopic): Promise<ISubTopic|null> {
        const SubTopicData: ISubTopic | null = await SubTopicModel.findById(id);
        if (!SubTopicData) {
            throw new Error(`Topic not found for this id : ${id}`);
        }
        if(subTopic.board){
            SubTopicData.board=subTopic.board;
        }
        if(subTopic.category){
            SubTopicData.category=subTopic.category;
        }
        if(subTopic.subcategory){
            SubTopicData.subcategory=subTopic.subcategory;
        }
        if(subTopic.subject){
            SubTopicData.subject=subTopic.subject;
        }
        if(subTopic.chapter){
            SubTopicData.chapter=subTopic.chapter;
        }
        if(subTopic.topic){
            SubTopicData.topic=subTopic.topic;
        }
        if(subTopic.status){
            SubTopicData.status=subTopic.status;
        }
        if(subTopic.subTopic){
            SubTopicData.subTopic=subTopic.subTopic;
        }

        return await SubTopicModel.findByIdAndUpdate({ _id: new mongoose.Types.ObjectId(id) },SubTopicData);
     
    }
    async deleteSubTopic(id: string): Promise<any> {
        const SubTopicData: ISubTopic | null = await SubTopicModel.findById(id);
        if (!SubTopicData) {
            throw new Error(`Topic not found for this id : ${id}`);
        }
        return await SubTopicModel.findByIdAndDelete(id);
    }
}
 */