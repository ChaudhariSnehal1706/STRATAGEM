import mongoose from 'mongoose';
import { FaqModel, IFaq } from '../models/faq.model';

export default class FaqRepository {
  async createFaq(faqData: IFaq): Promise<IFaq> {
    const createdFaq = await FaqModel.create(faqData);
    return createdFaq.toObject();
  }
  async getFaq(): Promise<IFaq[]> {
    return await FaqModel.find().populate({
      path: 'category',
      options: { sort: { name: 1 } }, // Sort by author's name in ascending order
    });
  }
  async deleteFaq(id: string): Promise<IFaq[] | null> {
    const faqData: IFaq | null = await FaqModel.findById(id);
    if (!faqData) {
      throw new Error(`Faq not found for this id : ${id}`);
    }
    return await FaqModel.findByIdAndDelete(id);
  }
  async updateFaq(id: string, faq: IFaq): Promise<IFaq | null> {
    const faqData: IFaq | null = await FaqModel.findById(id);
    if (!faqData) {
      throw new Error(`FAQ not found for this id : ${id}`);
    }
    //update name when only name is passed from the request
    if (faq.title) {
      faqData.title = faq.title;
    }

    if (faq.description != null) {
      faqData.description = faq.description;
    }
    if (faq.category) {
      faqData.category = faq.category;
    }

    return await FaqModel.findOneAndReplace(
      { _id: new mongoose.Types.ObjectId(id) },
      faqData
    );
  }

  // Add more methods as needed
}
