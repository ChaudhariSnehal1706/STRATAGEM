import mongoose from 'mongoose';

import { ITestSeries, TestSeriesModel } from '../models/testSeries.model';

export default class TestSeriesRepository {
  async createTestSeries(testSeriesData: ITestSeries): Promise<ITestSeries> {
    const createdTestSeries = await TestSeriesModel.create(testSeriesData);
    return createdTestSeries.toObject();
  }
  async getTestSeries(query: any): Promise<ITestSeries[]> {
    return await TestSeriesModel.find(query)
      .populate({
        path: 'category',
        options: { sort: { name: 1 } }, // Sort by author's name in ascending order
      })
      .populate({
        path: 'subcategory',
        options: { sort: { name: 1 } },
      });
  }
  async getTestSeriesById(id: string): Promise<any> {
    try {
      // Assuming you have some logic to fetch the blog from the database
      const testSeries = await TestSeriesModel.findById(id);
      if (!testSeries) {
        throw new Error('Test series not found');
      }
      return testSeries;
    } catch (error) {
      throw new Error(`Error fetching Test series`);
    }
  }
  async getFeaturedTestSeries(query: any): Promise<ITestSeries[]> {
    return await TestSeriesModel.find(query)
      .populate({
        path: 'category',
        options: { sort: { name: 1 } }, // Sort by author's name in ascending order
      })
      .populate({
        path: 'subcategory',
        options: { sort: { name: 1 } },
      });
  }
  async getRecommendedTestSeries(query: any): Promise<ITestSeries[]> {
    return await TestSeriesModel.find(query)
      .populate({
        path: 'category',
        options: { sort: { name: 1 } }, // Sort by author's name in ascending order
      })
      .populate({
        path: 'subcategory',
        options: { sort: { name: 1 } },
      });
  }
  async getUpcomingTestSeries(query: any): Promise<ITestSeries[]> {
    const currentTime = new Date();
    query.scheduleStartTime = { $gt: currentTime };
    return await TestSeriesModel.find(query)
      .populate({
        path: 'category',
        options: { sort: { name: 1 } }, // Sort by author's name in ascending order
      })
      .populate({
        path: 'subcategory',
        options: { sort: { name: 1 } },
      });
  }
  async deleteTestSeries(id: string): Promise<ITestSeries[] | null> {
    const testSeriesData: ITestSeries | null =
      await TestSeriesModel.findById(id);
    if (!testSeriesData) {
      throw new Error(`Test Series not found for this id : ${id}`);
    }
    return await TestSeriesModel.findByIdAndDelete(id);
  }
  async updateTestSeries(
    id: string,
    testSeries: ITestSeries
  ): Promise<ITestSeries | null> {
    const testSeriesData: ITestSeries | null =
      await TestSeriesModel.findById(id);
    if (!testSeriesData) {
      throw new Error(`Test Series not found for this id : ${id}`);
    }

    if (testSeries.banner_url) {
      testSeriesData.banner_url = testSeries.banner_url;
    }
    if (testSeries.name) {
      testSeriesData.name = testSeries.name;
    }
    if (testSeries.status != null) {
      testSeriesData.status = testSeries.status;
    }
    if (testSeries.description) {
      testSeriesData.description = testSeries.description;
    }
    if (testSeries.durationMinutes) {
      testSeriesData.durationMinutes = testSeries.durationMinutes;
    }
    if (testSeries.maxMarks) {
      testSeriesData.maxMarks = testSeries.maxMarks;
    }
    if (testSeries.scheduleStartTime) {
      testSeriesData.scheduleStartTime = testSeries.scheduleStartTime;
    }
    if (testSeries.scheduleEndTime) {
      testSeriesData.scheduleEndTime = testSeries.scheduleEndTime;
    }
    if (testSeries.noOfQuestions) {
      testSeriesData.noOfQuestions = testSeries.noOfQuestions;
    }
    if (testSeries.category) {
      testSeriesData.category = testSeries.category;
    }
    if (testSeries.subcategory) {
      testSeriesData.subcategory = testSeries.subcategory;
    }
    if (testSeries.featured_flag) {
      testSeriesData.featured_flag = testSeries.featured_flag;
    }
    return await TestSeriesModel.findOneAndReplace(
      { _id: new mongoose.Types.ObjectId(id) },
      testSeriesData
    );
  }
  // Add more methods as needed
}
