import mongoose from 'mongoose';
import { ICategory, CategoryModel } from '../models/category.model';

export default class CategoryRepository {
  async createCategory(categorytData: ICategory): Promise<ICategory> {
    const createdCategory = await CategoryModel.create(categorytData);
    return createdCategory.toObject();
  }

  async getCategories(): Promise<ICategory[]> {
    return await CategoryModel.find();
  }

  async getCategoryById(id: string): Promise<ICategory | null> {
    return await CategoryModel.findById(id);
  }

  async deleteCategory(id: string): Promise<ICategory[] | null> {
    const categoryData: ICategory | null = await CategoryModel.findById(id);
    if (!categoryData) {
      throw new Error(`Category not found for this id : ${id}`);
    }
    return await CategoryModel.findByIdAndDelete(id);
  }

  async updateCategory(
    id: string,
    category: ICategory
  ): Promise<ICategory | null> {
    const categoryData: ICategory | null = await CategoryModel.findById(id);
    if (!categoryData) {
      throw new Error(`Category not found for this id : ${id}`);
    }
    //update name when only name is passed from the request
    if (category.name) {
      categoryData.name = category.name;
    }
    //update status when only status is passed from the request
    if (category.status) {
      categoryData.status = category.status;
    }
    if (category.iconUrl) {
      categoryData.iconUrl = category.iconUrl;
    }
    if (category.totalTestSeries) {
      categoryData.totalTestSeries = category.totalTestSeries;
    }
    return await CategoryModel.findOneAndReplace(
      { _id: new mongoose.Types.ObjectId(id) },
      categoryData
    );
  }

  // Add more methods as needed
}
