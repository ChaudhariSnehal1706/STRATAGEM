import mongoose from 'mongoose';
import { IUser, UserModel } from '../models/user.model';

export default class UserRepository {
  async createUser(UserData: IUser): Promise<IUser> {
    const createdUser = await UserModel.create(UserData);
    return createdUser.toObject();
  }
  async getUser(): Promise<IUser[]> {
    return await UserModel.find();
  }
  async updateUser(id: string, user: IUser): Promise<IUser | null> {
    const userData: IUser | null = await UserModel.findById(id);
    if (!userData) {
      throw new Error(`Category not found for this id : ${id}`);
    }
    //update name when only name is passed from the request
    if (user.name) {
      userData.name = user.name;
    }
    if (user.email) {
      userData.email = user.email;
    }
    if (user.password) {
      userData.password = user.password;
    }
    if (user.mobile_number) {
      userData.mobile_number = user.mobile_number;
    }
    return await UserModel.findOneAndReplace(
      { _id: new mongoose.Types.ObjectId(id) },
      userData
    );
  }
  // Add more methods as needed
  async getUserByReferralCode(referralCode: string): Promise<IUser | null> {
    return await UserModel.findOne({ referral_code: referralCode });
  }

  // Add more methods as needed
  async getUserById(userId: string): Promise<IUser | null> {
    return await await UserModel.findById(userId);
  }
}
