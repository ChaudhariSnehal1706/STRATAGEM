import mongoose from 'mongoose';
import {
  IQuestionLevel,
  QuestionLevelModel,
} from '../models/questionLevel.model';

export default class QuestionLevelRespository {
  async createQuestionLevel(
    questionLevelData: IQuestionLevel
  ): Promise<IQuestionLevel> {
    const createdQuestionLevel =
      await QuestionLevelModel.create(questionLevelData);
    return createdQuestionLevel.toObject();
  }
  async getQuestionLevel(query: any): Promise<IQuestionLevel[]> {
    return await QuestionLevelModel.find(query);
  }
  async deleteQuestionLevel(id: string): Promise<IQuestionLevel[] | null> {
    const questionLevelData: IQuestionLevel | null =
      await QuestionLevelModel.findById(id);
    if (!questionLevelData) {
      throw new Error(`Question level not found for this id : ${id}`);
    }
    return await QuestionLevelModel.findByIdAndDelete(id);
  }
  async updateQuestionLevel(
    id: string,
    questionLevel: IQuestionLevel
  ): Promise<IQuestionLevel | null> {
    const questionLevelData: IQuestionLevel | null =
      await QuestionLevelModel.findById(id);
    if (!questionLevelData) {
      throw new Error(`Question Level not found for this id : ${id}`);
    }
    //update name when only name is passed from the request
    if (questionLevel.level) {
      questionLevelData.level = questionLevel.level;
    }

    if (questionLevel.status) {
      questionLevelData.status = questionLevel.status;
    }

    return await QuestionLevelModel.findOneAndReplace(
      { _id: new mongoose.Types.ObjectId(id) },
      questionLevelData
    );
  }
}
