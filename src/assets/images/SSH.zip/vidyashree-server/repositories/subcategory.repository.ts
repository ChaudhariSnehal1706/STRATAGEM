import mongoose from 'mongoose';
import { ISubcategory, SubcategoryModel } from '../models/subcategory.model';

export default class SubcategoryRepository {
  async createSubcategory(
    SubcategoryData: ISubcategory
  ): Promise<ISubcategory> {
    const createdSubcategory = await SubcategoryModel.create(SubcategoryData);
    return createdSubcategory.toObject();
  }
  async getSubcategory(query: any): Promise<ISubcategory[]> {
    console.log(`find subcategory base on category`, query)
    return await SubcategoryModel.find(query).populate({
      path: 'category',
      options: { sort: { name: 1 } } // Sort by author's name in ascending order
    })
      .populate({
        path: 'board',
        options: { sort: { board: 1 } } // Sort by author's name in ascending order
      });
  }
  async updateSubcategory(
    id: string,
    subcategory: ISubcategory
  ): Promise<ISubcategory | null> {
    const subcategoryData: ISubcategory | null =
      await SubcategoryModel.findById(id);
    if (!subcategoryData) {
      throw new Error(`Category not found for this id : ${id}`);
    }
    //update name when only name is passed from the request
    if (subcategory.name) {
      subcategoryData.name = subcategory.name;
    }

    if (subcategory.status != null) {
      subcategoryData.status = subcategory.status;
    }

    if (subcategory.category != null) {
      subcategoryData.category = subcategory.category;
    }
    if (subcategory.board != null) {
      subcategoryData.board = subcategory.board
    }

    return await SubcategoryModel.findOneAndReplace(
      { _id: new mongoose.Types.ObjectId(id) },
      subcategoryData
    );
  }
  async deleteSubcategory(id: string): Promise<ISubcategory[] | null> {
    const subcategoryData: ISubcategory | null =
      await SubcategoryModel.findById(id);
    if (!subcategoryData) {
      throw new Error(`Subcategory not found for this id : ${id}`);
    }
    return await SubcategoryModel.findByIdAndDelete(id);
  }

  async getSubCategoryById(id: string): Promise<ISubcategory | null> {
    return await SubcategoryModel.findById(id);
  }

  async getSubCategoriesByCategoryId(
    categoryId: string
  ): Promise<ISubcategory[]> {
    return await SubcategoryModel.find({ category: categoryId });
  }
  // Add more methods as needed
}
