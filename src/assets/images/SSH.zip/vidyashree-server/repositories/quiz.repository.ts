import mongoose from 'mongoose';

import { IQuiz, QuizModel } from '../models/quiz.model';

export default class QuizRepository {
  async createQuizs(partnerData: IQuiz): Promise<IQuiz> {
    const createdQuiz = await QuizModel.create(partnerData);
    return createdQuiz.toObject();
  }
  async getQuizs(): Promise<IQuiz[]> {
    return await QuizModel.find();
  }
  async deleteQuizs(id: string): Promise<IQuiz[] | null> {
    const partnerData: IQuiz | null = await QuizModel.findById(id);
    if (!partnerData) {
      throw new Error(`Quiz not found for this id : ${id}`);
    }
    return await QuizModel.findByIdAndDelete(id);
  }
  async updateQuizs(id: string, quiz: IQuiz): Promise<IQuiz | null> {
    const quizData: IQuiz | null = await QuizModel.findById(id);
    if (!quizData) {
      throw new Error(`Quiz not found for this id : ${id}`);
    }
    //update name when only name is passed from the request
    if (quiz.correctOption) {
      quizData.correctOption = quiz.correctOption;
    }

    if (quiz.question != null) {
      quizData.question = quiz.question;
    }
    if (quiz.options !== null) {
      quizData.options = quiz.options;
    }

    return await QuizModel.findOneAndReplace(
      { _id: new mongoose.Types.ObjectId(id) },
      quizData
    );
  }

  // Add more methods as needed
}
