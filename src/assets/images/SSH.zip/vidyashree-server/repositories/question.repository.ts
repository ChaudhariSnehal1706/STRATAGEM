import mongoose from "mongoose";
import { IQuestion, QuestionModel } from "../models/question.model";

export default class QuestionRepository {
    async createQuestion(questionData: IQuestion): Promise<IQuestion> {
        const createdQuestion = await QuestionModel.create(questionData);
        return createdQuestion.toObject();
    }
    async getQuestions(query:any): Promise<IQuestion[]> {
        return await QuestionModel.find(query).populate({
            path: 'category',            
        }).populate({
            path: 'board',            
        }).populate({
            path:'subcategory',            
        }).populate({
            path:'subject',            
        }).populate({
            path: 'chapter',            
        }).populate({
            path: 'topic',            
        }).populate({
            path:'subTopic',            
        }).populate({
            path:'questionLevel',
        }).populate({
            path:'questionType'
        })
    }
    async getQuestionById(id:string): Promise<any>{}
    async updateQuestion(id: string, question: IQuestion): Promise<IQuestion | null> {
        const questionData: IQuestion | null = await QuestionModel.findById(id);
        if (!questionData) {
            throw new Error(`Question not found for this id : ${id}`);
        }
        if(question.category){
            questionData.category=question.category;
        }
        if(question.board){
            questionData.board=question.board;
        }
        if(question.subcategory){
            questionData.subcategory=question.subcategory;
        }
        if(question.subject){
            questionData.subject=question.subject;
        }
        if(question.chapter){
            questionData.chapter=question.chapter;
        }
        if(question.topic){
            questionData.topic=question.topic;
        }
        if(question.status){
            questionData.status=question.status;
        }
        if(question.subTopic){
            questionData.subTopic=question.subTopic;
        }
        if(question.question){
            questionData.question=question.question;
        }
        if(question.correctOption){
            questionData.correctOption=question.correctOption;
        }
        if(question.questionImage){
            questionData.questionImage=question.questionImage;
        }
        if(question.questionLevel){
            questionData.questionLevel=question.questionLevel;
        }
        if(question.questionMarks){
            questionData.questionMarks=question.questionMarks;
        }
        if(question.referenceTags){
            questionData.referenceTags=question.referenceTags;
        }
        if(question.questionType){
            questionData.questionType=question.questionType;
        }
        if(question.option1){
            questionData.option1=question.option1;
        }
        if(question.option2){
            questionData.option2=question.option2;
        }
        if(question.option3){
            questionData.option3=question.option3;
        }
        if(question.option4){
            questionData.option4=question.option4;
        }
        if(question.correctOption){
            questionData.correctOption=question.correctOption;
        }
        return await QuestionModel.findByIdAndUpdate({_id: new mongoose.Types.ObjectId(id)},questionData);
    }
    async deleteQuestion(id: string): Promise<any> {
        const questionData: IQuestion | null = await QuestionModel.findById(id);
        if (!questionData) {
            throw new Error(`Question not found for this id : ${id}`);
        }
        return await QuestionModel.findByIdAndDelete(id);
    }
}