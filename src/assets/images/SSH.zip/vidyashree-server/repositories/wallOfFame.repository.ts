import mongoose from 'mongoose';
import { IWallOfFame, WallOfFameModel } from '../models/wallOfFame.model';
export default class WallOfFameRespository {
  async createWallOfFame(wallOfFameData: IWallOfFame): Promise<IWallOfFame> {
    const createdWallOfFame = await WallOfFameModel.create(wallOfFameData);
    return createdWallOfFame.toObject();
  }
  async getWallOfFame(): Promise<IWallOfFame[]> {
    return await WallOfFameModel.find().populate({
      path: 'category',
      options: { sort: { name: 1 } }, // Sort by author's name in ascending order
    });
  }
  async deleteWallOfFame(id: string): Promise<IWallOfFame[] | null> {
    const wallOfFameData: IWallOfFame | null =
      await WallOfFameModel.findById(id);
    if (!wallOfFameData) {
      throw new Error(`Wall of fame not found for this id : ${id}`);
    }
    return await WallOfFameModel.findByIdAndDelete(id);
  }
  async updateWallOfFame(
    id: string,
    wallOfFame: IWallOfFame
  ): Promise<IWallOfFame | null> {
    const wallOfFameData: IWallOfFame | null =
      await WallOfFameModel.findById(id);
    if (!wallOfFameData) {
      throw new Error(`Wall of fame not found for this id : ${id}`);
    }
    //update name when only name is passed from the request
    if (wallOfFame.name) {
      wallOfFameData.name = wallOfFame.name;
    }

    if (wallOfFame.imageUrl != null) {
      wallOfFameData.imageUrl = wallOfFame.imageUrl;
    }
    if (wallOfFame.rank) {
      wallOfFameData.rank = wallOfFame.rank;
    }
    if (wallOfFame.category) {
      wallOfFameData.category = wallOfFame.category;
    }

    return await WallOfFameModel.findOneAndReplace(
      { _id: new mongoose.Types.ObjectId(id) },
      wallOfFameData
    );
  }

  // Add more methods as needed
}
