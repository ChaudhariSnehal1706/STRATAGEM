import mongoose from 'mongoose';

import { ITestimonial, TestimonialModel } from '../models/testimonial.model';

export default class TestimonialRepository {
  async createTestimonials(
    testimonialData: ITestimonial
  ): Promise<ITestimonial> {
    const createdTestimonial = await TestimonialModel.create(testimonialData);
    return createdTestimonial.toObject();
  }
  async getTestimonials(): Promise<ITestimonial[]> {
    return await TestimonialModel.find();
  }
  async updateTestimonials(
    id: string,
    testimonial: ITestimonial
  ): Promise<ITestimonial | null> {
    const testimonialData: ITestimonial | null =
      await TestimonialModel.findById(id);
    if (!testimonialData) {
      throw new Error(`Testimonial not found for this id : ${id}`);
    }
    //update name when only name is passed from the request
    if (testimonial.name) {
      testimonialData.name = testimonial.name;
    }
    if (testimonial.position) {
      testimonialData.position = testimonial.position;
    }
    if (testimonial.status != null) {
      testimonialData.status = testimonial.status;
    }
    if (testimonial.textContent) {
      testimonialData.textContent = testimonial.textContent;
    }
    if (testimonial.mediaType) {
      testimonialData.mediaType = testimonial.mediaType;
    }
    if (testimonial.mediaUrl) {
      testimonialData.mediaUrl = testimonial.mediaUrl;
    }
    return await TestimonialModel.findOneAndReplace(
      { _id: new mongoose.Types.ObjectId(id) },
      testimonialData
    );
  }
  async deleteTestimonial(id: string): Promise<ITestimonial[] | null> {
    const testimonialData: ITestimonial | null =
      await TestimonialModel.findById(id);
    if (!testimonialData) {
      throw new Error(`Testimonial not found for this id : ${id}`);
    }
    return await TestimonialModel.findByIdAndDelete(id);
  }
  // Add more methods as needed
}
