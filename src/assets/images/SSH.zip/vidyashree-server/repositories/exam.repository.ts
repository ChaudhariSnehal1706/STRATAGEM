import mongoose from 'mongoose';
import { ExamModel, IExam } from '../models/exam.model';

export default class ExamRepository {
  async createExam(ExamData: IExam): Promise<IExam> {
    const createdExam = await ExamModel.create(ExamData);
    return createdExam.toObject();
  }
  async getExam(): Promise<IExam[]> {
    return await ExamModel.find();
  }
  async updateExam(id: string, exam: IExam): Promise<IExam | null> {
    const examData: IExam | null = await ExamModel.findById(id);
    if (!examData) {
      throw new Error(`Exam not found for this id : ${id}`);
    }
    //update name when only name is passed from the request
    if (exam.name) {
      examData.name = exam.name;
    }
    return await ExamModel.findOneAndReplace(
      { _id: new mongoose.Types.ObjectId(id) },
      examData
    );
  }
  // Add more methods as needed
}
