import mongoose from 'mongoose';

import { IQuestionType, QuestionTypeModel } from '../models/questionType.model';

export default class QuestionTypeRespository {
  async createQuestionType(
    questionTypeData: IQuestionType
  ): Promise<IQuestionType> {
    const createdQuestionType =
      await QuestionTypeModel.create(questionTypeData);
    return createdQuestionType.toObject();
  }
  async getQuestionType(query: any): Promise<IQuestionType[]> {
    return await QuestionTypeModel.find(query);
  }
  async deleteQuestionType(id: string): Promise<IQuestionType[] | null> {
    const questionTypeData: IQuestionType | null =
      await QuestionTypeModel.findById(id);
    if (!questionTypeData) {
      throw new Error(`Question Type not found for this id : ${id}`);
    }
    return await QuestionTypeModel.findByIdAndDelete(id);
  }
  async updateQuestionType(
    id: string,
    questionType: IQuestionType
  ): Promise<IQuestionType | null> {
    const questionTypeData: IQuestionType | null =
      await QuestionTypeModel.findById(id);
    if (!questionTypeData) {
      throw new Error(`Question Type not found for this id : ${id}`);
    }
    //update name when only name is passed from the request
    if (questionType.type) {
      questionTypeData.type = questionType.type;
    }

    if (questionType.status) {
      questionTypeData.status = questionType.status;
    }

    return await QuestionTypeModel.findOneAndReplace(
      { _id: new mongoose.Types.ObjectId(id) },
      questionTypeData
    );
  }
}
