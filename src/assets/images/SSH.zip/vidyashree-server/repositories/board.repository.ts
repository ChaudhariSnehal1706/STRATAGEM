import mongoose from "mongoose";
import { BoardModel, IBoard } from "../models/board.model";

export default class BoardRepository {
    async createBoard(boardData: IBoard): Promise<IBoard> {
        const createdBoard = await BoardModel.create(boardData);
        return createdBoard.toObject();
    }
    async getBoard(query:any): Promise<IBoard[]> {
        return await BoardModel.find(query).populate({
            path: 'category',            
          });
    }
    async updateBoard(id: string, board: IBoard): Promise<IBoard | null> {
        const boardData: IBoard | null = await BoardModel.findById(id);
        if (!boardData) {
            throw new Error(`Board not found for this id : ${id}`);
        }
        if(board.board){
            boardData.board = board.board;
        }
        if(board.status){
            boardData.status = board.status;
        }
        if(board.category){
            boardData.category = board.category
        }
        return await BoardModel.findByIdAndUpdate({ _id: new mongoose.Types.ObjectId(id) },
        boardData);
    }
    async deleteBoard(id: string): Promise<IBoard[] | null> {
        const boardData: IBoard | null = await BoardModel.findById(id);
        if (!boardData) {
            throw new Error(`Board not found for this id : ${id}`);
        }
        return await BoardModel.findByIdAndDelete(id);
    }
}