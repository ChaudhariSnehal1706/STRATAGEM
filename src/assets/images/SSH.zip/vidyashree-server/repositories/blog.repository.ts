import mongoose, { Model } from 'mongoose';

import { BlogModel, IBlog } from '../models/blog.model';
import { BlogsAddDTO } from '../dto/blogs/blogs.add.dto';

export default class BlogRepository {
  async createBlog(blogData: IBlog): Promise<IBlog> {
    const createdBlog = await BlogModel.create(blogData);
    return createdBlog.toObject();
  }
  async getBlogById(id: string): Promise<any> {
    try {
      // Assuming you have some logic to fetch the blog from the database
      const blog = await BlogModel.findById(id);
      if (!blog) {
        throw new Error('Blog not found');
      }
      return blog;
    } catch (error) {
      throw new Error(`Error fetching blog`);
    }
  }
  async getBlog(query: any): Promise<any> {
    let limit = 1000,
      skip = 0;
    if (query.limit) {
      limit = query.limit;
    }
    if (query.skip) {
      skip = query.skip;
    }

    // define search filter
    delete query.limit;
    delete query.skip;

    const total_records = await BlogModel.countDocuments(query, {
      maxTimeMS: 30000,
    });
    const blogs_data = await BlogModel.find(query)
      .skip(skip)
      .limit(limit)
      .populate({
        path: 'category',
        options: { sort: { name: 1 } },
      });
    return { total_records, blogs_data };
  }
  async getRecentBlog(): Promise<IBlog[]> {
    try {
      const recentBlogs = await BlogModel.find()
        .sort({ createdAt: -1 })
        .limit(4);

      return recentBlogs;
    } catch (error) {
      throw new Error(`Error fetching recent blogs`);
    }
  }
  async deleteBlog(id: string): Promise<IBlog[] | null> {
    const blogData: IBlog | null = await BlogModel.findById(id);
    if (!blogData) {
      throw new Error(`Blog not found for this id : ${id}`);
    }
    return await BlogModel.findByIdAndDelete(id);
  }
  async updateBlog(id: string, blog: IBlog): Promise<IBlog | null> {
    const blogData: IBlog | null = await BlogModel.findById(id);
    if (!blogData) {
      throw new Error(`Blog not found for this id : ${id}`);
    }
    if (blog.author) {
      blogData.author = blog.author;
    }
    if (blog.category) {
      blogData.category = blog.category;
    }
    if (blog.content) {
      blogData.content = blog.content;
    }

    if (blog.blogDate) {
      blogData.blogDate = blog.blogDate;
    }

    if (blog.likes) {
      blogData.likes = blog.likes;
    }
    if (blog.tags) {
      blogData.tags = blog.tags;
    }
    if (blog.title) {
      blogData.title = blog.title;
    }
    if (blog.imageUrl) {
      blogData.imageUrl = blog.imageUrl;
    }
    return await BlogModel.findOneAndReplace(
      { _id: new mongoose.Types.ObjectId(id) },
      blogData
    );
  }
  // Add more methods as needed
}
