import { DepartmentModel, IDepartment } from './../models/department.model';

export default class DepartmentRepository {
  async createDepartment(departmentData: IDepartment): Promise<IDepartment> {
    const createdDepartment = await DepartmentModel.create(departmentData);
    return createdDepartment.toObject();
  }

  async getDepartments(): Promise<IDepartment[]> {
    return await DepartmentModel.find();
  }

  // Add more methods as needed
}
