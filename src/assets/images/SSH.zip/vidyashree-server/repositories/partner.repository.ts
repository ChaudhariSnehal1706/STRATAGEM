import mongoose from 'mongoose';
import { IPartner, PartnerModel } from '../models/partner.model';

export default class PartnerRepository {
  async createPartners(partnerData: IPartner): Promise<IPartner> {
    const createdPartner = await PartnerModel.create(partnerData);
    return createdPartner.toObject();
  }
  async getPartners(): Promise<IPartner[]> {
    return await PartnerModel.find();
  }
  async deletePartners(id: string): Promise<IPartner[] | null> {
    const partnerData: IPartner | null = await PartnerModel.findById(id);
    if (!partnerData) {
      throw new Error(`Partner not found for this id : ${id}`);
    }
    return await PartnerModel.findByIdAndDelete(id);
  }
  async updatePartners(
    id: string,
    partner: IPartner
  ): Promise<IPartner | null> {
    const partnerData: IPartner | null = await PartnerModel.findById(id);
    if (!partnerData) {
      throw new Error(`Partner not found for this id : ${id}`);
    }
    //update name when only name is passed from the request
    if (partner.name) {
      partnerData.name = partner.name;
    }

    if (partner.status != null) {
      partnerData.status = partner.status;
    }
    if (partner.logoURL) {
      partnerData.logoURL = partner.logoURL;
    }

    return await PartnerModel.findOneAndReplace(
      { _id: new mongoose.Types.ObjectId(id) },
      partnerData
    );
  }

  // Add more methods as needed
}
