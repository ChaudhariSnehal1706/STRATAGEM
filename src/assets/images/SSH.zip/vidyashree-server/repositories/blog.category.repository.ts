import mongoose, { Model } from 'mongoose';

import { BlogsAddDTO } from '../dto/blogs/blogs.add.dto';
import {
  BlogCategoryModel,
  IBlogCategory,
} from '../models/blog.category.model';

export default class BlogCategoryRepository {
  async createBlogCategory(blogData: IBlogCategory): Promise<IBlogCategory> {
    const createdBlog = await BlogCategoryModel.create(blogData);
    return createdBlog.toObject();
  }
  async getBlogCategoryById(id: string): Promise<any> {
    try {
      // Assuming you have some logic to fetch the blog from the database
      const blog = await BlogCategoryModel.findById(id);
      if (!blog) {
        throw new Error('Blog not found');
      }
      return blog;
    } catch (error) {
      throw new Error(`Error fetching blog`);
    }
  }
  async getBlogCategory(query: any): Promise<any> {
    console.log(query);
    const data = await BlogCategoryModel.find(query);
    return data;
  }

  async deleteBlogCategory(id: string): Promise<IBlogCategory[] | null> {
    const blogData: IBlogCategory | null = await BlogCategoryModel.findById(id);
    if (!blogData) {
      throw new Error(`Blog not found for this id : ${id}`);
    }
    return await BlogCategoryModel.findByIdAndDelete(id);
  }
  async updateBlogCategory(
    id: string,
    blog: IBlogCategory
  ): Promise<IBlogCategory | null> {
    const blogData: IBlogCategory | null = await BlogCategoryModel.findById(id);
    if (!blogData) {
      throw new Error(`Blog not found for this id : ${id}`);
    }
    if (blog.name) {
      blogData.name = blog.name;
    }
    if (blog.status) {
      blogData.status = blog.status;
    }

    return await BlogCategoryModel.findOneAndReplace(
      { _id: new mongoose.Types.ObjectId(id) },
      blogData
    );
  }
  // Add more methods as needed
}
