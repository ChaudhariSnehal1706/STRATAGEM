import mongoose from "mongoose";
import ChapterAddDto from "../dto/chapters/chapters.add.dto";
import { ChapterModel, IChapter } from "../models/chapter.model";

export default class ChapterRepository {

    async createChapter(chapterData: IChapter): Promise<IChapter> {
        const createdChapter = await ChapterModel.create(chapterData);
        return createdChapter.toObject();
    }
    async getChapter(): Promise<IChapter[]> {
        return await ChapterModel.find().populate({
            path: 'category',            
          }).populate({
            path: 'subcategory',            
          }).populate({
            path: 'board',            
          }).populate({
            path: 'subject',            
          });
    }
    async getChapterById(id:string): Promise<any>{
        try{
            const chapter = await ChapterModel.findById(id)
            if(!chapter){
                throw new Error(`Chapter not found`);
            }
            return chapter;
        }catch(error){
            throw new Error(`Error fetching chapter`);
        }
    }
    async updateChapter(id: string, chapter: IChapter): Promise<IChapter | null> {
        const chapterData: IChapter | null = await ChapterModel.findById(id);
        if (!chapterData) {
            throw new Error(`Chapter not found for this id : ${id}`);
        }
        if(chapter.board){
            chapterData.board = chapter.board;
        }
        if(chapter.category){
            chapterData.category = chapter.category;
        }
        if(chapter.subcategory){
            chapterData.subcategory = chapter.subcategory;
        }
        if(chapter.subject){
            chapterData.subject = chapter.subject;
        }
        if(chapter.chapter){
            chapterData.chapter = chapter.chapter;
        }
        if(chapter.status){
            chapterData.status = chapter.status;
        }
        
        return await ChapterModel.findByIdAndUpdate({ _id: new mongoose.Types.ObjectId(id) },chapterData );
    }
    async deleteChapter(id: string): Promise<IChapter[] | null> {
        const chapterData: IChapter | null = await ChapterModel.findById(id);
        if (!chapterData) {
            throw new Error(`Chapter not found for this id : ${id}`);
        }
        return await ChapterModel.findByIdAndDelete(id);
    }
}