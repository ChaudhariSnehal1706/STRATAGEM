import { StudentModel } from '../models/student.model';

export default class AuthRepository {
  async createStudent(data: any) {
    try {
      // Create a new student document using the provided data
      const newStudent = await StudentModel.create(data);
      return newStudent;
    } catch (error) {
      throw new Error('Failed to create student');
    }
  }

  async findStudentByEmail(email: string) {
    try {
      // Find a student document by email
      const student = await StudentModel.findOne({ email });
      return student;
    } catch (error) {
      throw new Error('Failed to find student by email');
    }
  }

  async findStudentByEmailAndStudentId(email: string, id: string) {
    try {
      const student = await StudentModel.findById(id);
      if (student && student.email === email) return student;
      throw new Error();
    } catch (error) {
      throw new Error('Failed to find student');
    }
  }

  async findStudentById(id: string) {
    try {
      const student = await StudentModel.findById(id);
      return student?.getPrimaryFields();
    } catch (error) {
      throw new Error('Failed to find student');
    }
  }

  async findStudentByMobileNumber(mobileNumber: string) {
    try {
      // Find a student document by mobile number
      const student = await StudentModel.findOne({ mobileNumber });
      return student;
    } catch (error) {
      throw new Error('Failed to find student by mobile number');
    }
  }

  async updateStudentFields(studentId: string, fieldsToUpdate: any) {
    try {
      const updatedStudent = await StudentModel.findByIdAndUpdate(
        studentId,
        fieldsToUpdate,
        { new: true } // Return the updated document
      );

      if (!updatedStudent) {
        throw new Error('Student not found');
      }

      return updatedStudent;
    } catch (error) {
      throw new Error('Failed to update student fields');
    }
  }

  async findStudentByEmailOrMobileNumber(emailOrMobileNumber: string) {
    try {
      const student = await StudentModel.findOne({
        $or: [
          { email: emailOrMobileNumber },
          { mobileNumber: emailOrMobileNumber },
        ],
      });
      return student;
    } catch (error) {
      throw new Error('Failed to find student by email or mobile number');
    }
  }
}
