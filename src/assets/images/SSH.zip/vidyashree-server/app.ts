import compression from 'compression';
import cookieParser from 'cookie-parser';
import cors from 'cors';
import dotenv from 'dotenv';
import express, { NextFunction, Request, Response } from 'express';
import createHttpError from 'http-errors';
import logger from 'morgan';
import * as path from 'path';
import swaggerJsdoc from 'swagger-jsdoc';
import swaggerUi from 'swagger-ui-express';
import ResponseFormatter from './middlewares/response.formatter.middleware';
import routes from './routes';
import { connectDB } from './util/db';
import HttpStatusCode from './util/http-status-code';

//setting up the configuration environment for application

const environment = process.env.NODE_ENV || 'development';

const envPath = path.join(__dirname, `.env.${environment || 'development'}`);
dotenv.config({ path: envPath });

// Initialize express application
const app = express();

app.use(cors());

// Connect to MongoDB
connectDB();
app.listen(process.env.PORT || 3005, () => {
  console.log(
    `[server]: Server is running at http://localhost:${process.env.PORT}`
  );
});

// Swagger setup
const swaggerOptions = {
  definition: {
    openapi: '3.0.0',
    info: {
      title: 'Express API with Swagger',
      version: '1.0.0',
      description: 'Documentation for Express API',
    },
  },
  apis: ['**/*.ts'], // Array of TypeScript files to use for Swagger documentation
};

const swaggerSpec = swaggerJsdoc(swaggerOptions);
app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(swaggerSpec));

console.log(`Server is running on ${process.env.PORT}`);

app.use(compression());

// view engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');
app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));
//Added middleware to format each response in standard format
app.use(ResponseFormatter);

//setup routers using the routes defined in routes.js
app.use('/api/v1', routes);
// catch 404 and forward to error handler
app.use(function (_req, _res, next) {
  next(createHttpError(404));

});

// error handler other than 404 error  :All other error will be handle in this middleware
app.use(function (err: any, req: Request, res: Response, next: NextFunction) {
  if (err.status === HttpStatusCode.VALIDATION_ERROR) {
    res.status(HttpStatusCode.VALIDATION_ERROR);
    return res.json(err['errors']);
  }

  // set locals, only providing error in development
  res.locals.message = err.message;
  res.locals.error = req.app.get('env') === 'development' ? err : {};
  res.status(err.status || 500);
  res.render('error');
});

export default app;
