import { TopicsAddDTO } from "../dto/topics/topic.add.dto";
import { TopicsUpdateDTO } from "../dto/topics/topic.update.dto";
import { ITopic } from "../models/topic.model";
import TopicRepository from "../repositories/topic.repository";

export default class TopicService {
    readonly topicRepository = new TopicRepository();
    async createTopic(
        topicDataDTO: TopicsAddDTO
    ): Promise<ITopic> {
        const topicData: ITopic = {
            status: true,
            category: topicDataDTO.category,
            board: topicDataDTO.board,
            subcategory: topicDataDTO.subcategory,
            subject: topicDataDTO.subject,
            chapter: topicDataDTO.chapter,
            topic: topicDataDTO.topic
        };
        return this.topicRepository.createTopic(topicData);
    }
    async getTopics(query:any): Promise<ITopic[]> {
        return this.topicRepository.getTopics();
    }
    async deleteTopic(id: string){
        return this.topicRepository.deleteTopic(id);
    }
    async updateTopic(
        id: string,
        topicDataDTO: TopicsUpdateDTO
    ): Promise<ITopic | null> {
        const topicData: ITopic = {
            status: topicDataDTO.status,
            category: topicDataDTO.category,
            board: topicDataDTO.board,
            subcategory: topicDataDTO.subcategory,
            subject: topicDataDTO.subject,
            chapter: topicDataDTO.chapter,
            topic: topicDataDTO.topic
        };
        return this.topicRepository.updateTopic(id, topicData);
    }
   

}