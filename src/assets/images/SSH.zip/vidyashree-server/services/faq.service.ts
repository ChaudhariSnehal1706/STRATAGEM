import mongoose from 'mongoose';
import { faqAddDTO } from '../dto/faq/faq.add.dto';
import { FaqUpdateDTO } from '../dto/faq/faq.update.dto';
import { PartnersUpdateDTO } from '../dto/partners/partner.update.dto';
import { PartnersAddDTO } from '../dto/partners/partner.add.dto';
import { IFaq } from '../models/faq.model';
import { IPartner } from '../models/partner.model';
import FaqRepository from '../repositories/faq.repository';
import PartnerRepository from '../repositories/partner.repository';

export default class FaqService {
  readonly faqRespository = new FaqRepository();

  async createFaq(faqDataDTO: faqAddDTO): Promise<IFaq> {
    const partnerData: IFaq = {
      title: faqDataDTO.title,
      description: faqDataDTO.description,
      category: new mongoose.Types.ObjectId(faqDataDTO.category),
    };
    return this.faqRespository.createFaq(partnerData);
  }

  async getFaq(): Promise<IFaq[]> {
    return this.faqRespository.getFaq();
  }
  async updateFaq(id: string, faqDataDTO: FaqUpdateDTO): Promise<IFaq | null> {
    const faqData: IFaq = {
      title: faqDataDTO.title,
      description: faqDataDTO.description,
      category: new mongoose.Types.ObjectId(faqDataDTO.category),
    };
    return this.faqRespository.updateFaq(id, faqData);
  }
  async deleteFaq(id: string) {
    return this.faqRespository.deleteFaq(id);
  }
}
