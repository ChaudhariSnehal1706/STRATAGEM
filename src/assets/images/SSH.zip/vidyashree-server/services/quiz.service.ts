import { QuizAddDTO } from '../dto/quiz/quiz.add.dto';
import { QuizUpdateDTO } from '../dto/quiz/quiz.update.dto';
import { IQuiz } from '../models/quiz.model';
import QuizRepository from '../repositories/quiz.repository';

export default class QuizService {
  readonly quizRepository = new QuizRepository();
  async createQuiz(quizDataDTO: QuizAddDTO): Promise<IQuiz> {
    const quizData: IQuiz = {
      correctOption: quizDataDTO.correctOption,
      question: quizDataDTO.question,
      options: quizDataDTO.options,
    };
    return this.quizRepository.createQuizs(quizData);
  }

  async getQuiz(): Promise<IQuiz[]> {
    return this.quizRepository.getQuizs();
  }
  async updateQuiz(
    id: string,
    quizDataDTO: QuizUpdateDTO
  ): Promise<IQuiz | null> {
    const quizData: IQuiz = {
      question: quizDataDTO.question,
      correctOption: quizDataDTO.correctOption,
      options: quizDataDTO.options,
    };
    return this.quizRepository.updateQuizs(id, quizData);
  }
  async deleteQuiz(id: string) {
    return this.quizRepository.deleteQuizs(id);
  }
}
