import mongoose from 'mongoose';
import { WallOfFameAddDTO } from '../dto/wallOfFame/wallOfFame.add.dto';
import { WallOfFameUpdateDTO } from '../dto/wallOfFame/wallOfFame.update.dto';
import { IWallOfFame } from '../models/wallOfFame.model';
import WallOfFameRespository from '../repositories/wallOfFame.repository';

export default class WallOfFameService {
  readonly wallOfFameRespository = new WallOfFameRespository();

  async createWallOfFame(
    wallOfFameDTOData: WallOfFameAddDTO
  ): Promise<IWallOfFame> {
    const wallOfFameData: IWallOfFame = {
      name: wallOfFameDTOData.name,
      imageUrl: wallOfFameDTOData.imageUrl,
      rank: wallOfFameDTOData.rank,
      category: new mongoose.Types.ObjectId(wallOfFameDTOData.category),
    };
    return this.wallOfFameRespository.createWallOfFame(wallOfFameData);
  }

  async getWallOfFame(): Promise<IWallOfFame[]> {
    return this.wallOfFameRespository.getWallOfFame();
  }
  async updateWallOfFame(
    id: string,
    wallOfFameDTOData: WallOfFameUpdateDTO
  ): Promise<IWallOfFame | null> {
    const wallOfFameData: IWallOfFame = {
      name: wallOfFameDTOData.name,
      imageUrl: wallOfFameDTOData.imageUrl,
      rank: wallOfFameDTOData.rank,
      category: new mongoose.Types.ObjectId(wallOfFameDTOData.category),
    };
    return this.wallOfFameRespository.updateWallOfFame(id, wallOfFameData);
  }
  async deleteWallOfFame(id: string) {
    return this.wallOfFameRespository.deleteWallOfFame(id);
  }
}
