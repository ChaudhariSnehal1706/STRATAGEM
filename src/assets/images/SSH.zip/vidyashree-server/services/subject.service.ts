import mongoose from 'mongoose';
import { SubjectsAddDTO } from '../dto/subjects/subjects.add.dto';
import { ISubject } from '../models/subjects.model';
import SubjectRepository from '../repositories/subject.repository';
import { SubCategoriesUpdateDTO } from '../dto/subcategories/subcategories.update.dto';
import { SubjectsUpdateDTO } from '../dto/subjects/subjects.update.dto';

export default class SubjectService {
  readonly subjectRepository = new SubjectRepository();

  async createSubject(subjectsDataDTO: SubjectsAddDTO): Promise<ISubject> {
    const subjectData: ISubject = {
      name: subjectsDataDTO.name,
      status: true,
      iconurl: subjectsDataDTO.iconurl,
      subcategory: new mongoose.Types.ObjectId(subjectsDataDTO.subcategory),
      category: new mongoose.Types.ObjectId(subjectsDataDTO.category),
      board: new mongoose.Types.ObjectId(subjectsDataDTO.board)
    };
    return this.subjectRepository.createSubject(subjectData);
  }

  async getSubject(query: any): Promise<ISubject[]> {
    return this.subjectRepository.getSubject(query);
  }
  async updateSubject(
    id: string,
    subjectDto: SubjectsUpdateDTO
  ): Promise<ISubject | null> {
    const subjectData: ISubject = {
      name: subjectDto.name,
      status: subjectDto.status,
      iconurl: subjectDto.iconurl,
      subcategory: new mongoose.Types.ObjectId(subjectDto.subcategory),
      category: new mongoose.Types.ObjectId(subjectDto.category),
      board: new mongoose.Types.ObjectId(subjectDto.board)
    };

    console.log(subjectData);
    return this.subjectRepository.updateSubject(id, subjectData);
  }
  async deleteSubject(id: string) {
    return this.subjectRepository.deleteSubject(id);
  }

  async getSubjectsBySubcategoryId(subcategoryId: string): Promise<ISubject[]> {
    return this.subjectRepository.getSubjectsBySubcategoryId(subcategoryId);
  }
}
