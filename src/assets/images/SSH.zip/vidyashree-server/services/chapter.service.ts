import ChapterAddDto from '../dto/chapters/chapters.add.dto';
import ChapterUpdateDto from '../dto/chapters/chapters.update.dto';
import { IChapter } from '../models/chapter.model';
import ChapterRepository from '../repositories/chapter.repository';

export default class ChapterService {
  readonly chapterRespository = new ChapterRepository();
  async createChapter(chapterDataDTO: ChapterAddDto): Promise<IChapter> {
    const chapterData: IChapter = {
      chapter: chapterDataDTO.chapter,
      status: true,
      category: chapterDataDTO.category,
      board: chapterDataDTO.board,
      subcategory: chapterDataDTO.subcategory,
      subject: chapterDataDTO.subject,
    };
    return this.chapterRespository.createChapter(chapterData);
  }
  async getChapterById(id: string): Promise<IChapter[]> {
    return this.chapterRespository.getChapterById(id);
  }
  async getChapter(query: any): Promise<IChapter[]> {
    return this.chapterRespository.getChapter();
  }
  async updateChapter(
    id: string,
    chapterDataDTO: ChapterUpdateDto
  ): Promise<IChapter | null> {
    const chapter: IChapter = {
      chapter: chapterDataDTO.chapter,
      status: chapterDataDTO.status,
      category: chapterDataDTO.category,
      board: chapterDataDTO.board,
      subcategory: chapterDataDTO.subcategory,
      subject: chapterDataDTO.subject,
    };
    return this.chapterRespository.updateChapter(id, chapter);
  }
  async deleteChapter(id: string): Promise<IChapter[] | null> {
    return this.chapterRespository.deleteChapter(id);
  }
}
