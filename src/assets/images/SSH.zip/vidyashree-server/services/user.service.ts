import { UserAddDTO } from '../dto/users/user.add.dto';
import { UserUpdateDTO } from '../dto/users/user.update.dto';
import { IUser } from '../models/user.model';
import UserRepository from '../repositories/user.repository';

export default class UserService {
  readonly userRepository = new UserRepository();

  async createUser(userDTO: UserAddDTO): Promise<IUser> {
    const userData: IUser = {
      name: userDTO.name,
      email: userDTO.email,
      password: userDTO.password,
      mobile_number: userDTO.mobile_number,
      referral_code: await this.generateUniqueReferralCode(),
    };
    return this.userRepository.createUser(userData);
  }

  async getUser(): Promise<IUser[]> {
    return this.userRepository.getUser();
  }
  async updateUser(id: string, userDto: UserUpdateDTO): Promise<IUser | null> {
    const userData: IUser = {
      name: userDto.name,
      email: userDto.email,
      password: userDto.password,
      mobile_number: userDto.mobile_number,
    };
    return this.userRepository.updateUser(id, userData);
  }

  async generateUniqueReferralCode(): Promise<string> {
    let isUnique: boolean = false;

    while (!isUnique) {
      const referralCode =
        'VS-' + Math.random().toString(36).substr(2, 6).toUpperCase();
      const user =
        await this.userRepository.getUserByReferralCode(referralCode);
      if (!user) {
        isUnique = true;
        return referralCode;
      }
    }

    return '';
  }

  // add findUserById method from repository
  async findById(userId: string): Promise<IUser | null> {
    return await this.userRepository.getUserById(userId);
  }
}
