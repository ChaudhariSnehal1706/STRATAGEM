import { SubTopicsAddDTO } from '../dto/subTopics/subTopics.add.dto';
import { SubTopicsUpdateDTO } from '../dto/subTopics/subTopics.update.dto';
import { SubCategoriesAddDTO } from '../dto/subcategories/subcategories.add.dto';
import { ISubTopic } from '../models/subTopic.model';
import SubTopicRespository from '../repositories/subTopic.repository';

export default class SubTopicService {
  readonly subTopicRespository = new SubTopicRespository();
  async createSubTopic(SubTopicDataDTO: SubTopicsAddDTO): Promise<ISubTopic> {
    const SubTopicData: ISubTopic = {
      status: true,
      category: SubTopicDataDTO.category,
      board: SubTopicDataDTO.board,
      subcategory: SubTopicDataDTO.subcategory,
      subject: SubTopicDataDTO.subject,
      chapter: SubTopicDataDTO.chapter,
      topic: SubTopicDataDTO.topic,
      subTopic: SubTopicDataDTO.subTopic,
    };
    return this.subTopicRespository.createSubTopic(SubTopicData);
  }
  async getSubTopic(query: any): Promise<ISubTopic[]> {
    return this.subTopicRespository.getSubTopic(query);
  }
  // async getTopicById(id: string): Promise<ISubTopic[]> {
  //     return this.subTopicRespository.getTopicById(id);
  // }
  async updateSubTopic(
    id: string,
    SubTopicDataDTO: SubTopicsUpdateDTO
  ): Promise<ISubTopic | null> {
    const SubTopicData: ISubTopic = {
      status: SubTopicDataDTO.status,
      category: SubTopicDataDTO.category,
      board: SubTopicDataDTO.board,
      subcategory: SubTopicDataDTO.subcategory,
      subject: SubTopicDataDTO.subject,
      chapter: SubTopicDataDTO.chapter,
      topic: SubTopicDataDTO.topic,
      subTopic: SubTopicDataDTO.subTopic,
    };
    return this.subTopicRespository.updateSubTopic(id, SubTopicData);
  }
  async deleteSubTopic(id: string): Promise<ISubTopic | null> {
    return this.subTopicRespository.deleteSubTopic(id);
  }
}
