import { QuestionsTypeAddDTO } from '../dto/questionType/questionTypes.add.dto';
import { QuestionsTypeUpdateDTO } from '../dto/questionType/questionTypes.update.dto';

import { IQuestionType } from '../models/questionType.model';
import QuestionTypeRespository from '../repositories/questionType.respository';

export default class QuestionTypeService {
  readonly questionTypeRespository = new QuestionTypeRespository();
  async createQuestionType(
    questionTypeDataDTO: QuestionsTypeAddDTO
  ): Promise<IQuestionType> {
    const questionTypeData: IQuestionType = {
      type: questionTypeDataDTO.type,
      status: true,
    };
    return this.questionTypeRespository.createQuestionType(questionTypeData);
  }
  async getQuestionType(query: any): Promise<IQuestionType[]> {
    return this.questionTypeRespository.getQuestionType(query);
  }
  async updateQuestionType(
    id: string,
    questionTypeDataDTO: QuestionsTypeUpdateDTO
  ): Promise<IQuestionType | null> {
    const questionTypeData: IQuestionType = {
      type: questionTypeDataDTO.type,
      status: questionTypeDataDTO.status,
    };
    return this.questionTypeRespository.updateQuestionType(
      id,
      questionTypeData
    );
  }
  async deleteQuestionType(id: string) {
    return this.questionTypeRespository.deleteQuestionType(id);
  }
}
