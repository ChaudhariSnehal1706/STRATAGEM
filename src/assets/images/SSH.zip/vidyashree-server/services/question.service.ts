import mongoose from "mongoose";
import QuestionsAddDto from "../dto/questions/questions.add.dto";
import QuestionsUpdateDto from "../dto/questions/questions.update.dto";
import { IQuestion } from "../models/question.model";
import QuestionRepository from "../repositories/question.repository";

export default class QuestionService {
    readonly questionRepository = new QuestionRepository();
    createQuestion(questionDataDto: QuestionsAddDto): Promise<IQuestion>{
        const questionData: IQuestion = {
            category: questionDataDto.category,
            board: questionDataDto.board,
            subcategory: questionDataDto.subcategory,
            subject: questionDataDto.subject,
            chapter: questionDataDto.chapter,
            topic: questionDataDto.topic,
            status: true,
            subTopic: questionDataDto.subTopic,
            question: questionDataDto.question,
            questionType: new mongoose.Types.ObjectId(questionDataDto.questionType),
            questionLevel: new mongoose.Types.ObjectId(questionDataDto.questionLevel),
            markingScheme: questionDataDto.markingScheme,
            questionMarks: questionDataDto.questionMarks,
            questionImage: questionDataDto.questionImage,
            referenceTags: questionDataDto.referenceTags,
            favQuestion: questionDataDto.favQuestion,
            option1: questionDataDto.option1,
            option2: questionDataDto.option2,
            option3: questionDataDto.option3,
            option4: questionDataDto.option4,
            correctOption: questionDataDto.correctOption,
        };
        return this.questionRepository.createQuestion(questionData);
    }
    getQuestions(query:any): Promise<IQuestion[]>{
        return this.questionRepository.getQuestions(query);
    }
    // getQuestionById(id:string): Promise<IQuestion>{
    //     return this.questionRepository.getQuestionById(id);
    // }
    updateQuestion(id: string, questionDataDto:QuestionsUpdateDto ): Promise<IQuestion | null>{
        const questionData: IQuestion = {
            category: questionDataDto.category,
            board: questionDataDto.board,
            subcategory: questionDataDto.subcategory,
            subject: questionDataDto.subject,
            chapter: questionDataDto.chapter,
            topic: questionDataDto.topic,
            status: questionDataDto.status,
            subTopic: questionDataDto.subTopic,
            question: questionDataDto.question,
            questionType: new mongoose.Types.ObjectId(questionDataDto.questionType),
            questionLevel: new mongoose.Types.ObjectId(questionDataDto.questionLevel),
            markingScheme: questionDataDto.markingScheme,
            questionMarks: questionDataDto.questionMarks,
            questionImage: questionDataDto.questionImage,
            referenceTags: questionDataDto.referenceTags,
            favQuestion: questionDataDto.favQuestion,
            option1: questionDataDto.option1,
            option2: questionDataDto.option2,
            option3: questionDataDto.option3,
            option4: questionDataDto.option4,
            correctOption: questionDataDto.correctOption,
        };
        return this.questionRepository.updateQuestion(id, questionData);
    }
    deleteQuestion(id: string): Promise<IQuestion | null>{
        return this.questionRepository.deleteQuestion(id);
    }
}