import mongoose from 'mongoose';
import { BlogsAddDTO } from '../dto/blogs/blogs.add.dto';
import { BlogsUpdateDTO } from '../dto/blogs/blogs.update.dto';
import { IBlog } from '../models/blog.model';
import BlogRepository from '../repositories/blog.repository';

export default class BlogService {
  readonly blogRepository = new BlogRepository();

  async createBlog(blogDataDTO: BlogsAddDTO): Promise<IBlog> {
    const blogData: IBlog = {
      author: blogDataDTO.author,
      title: blogDataDTO.title,
      content: blogDataDTO.content,
      category: new mongoose.Types.ObjectId(blogDataDTO.category),
      likes: blogDataDTO.likes,
      tags: blogDataDTO.tags,
      blogDate: blogDataDTO.blogDate,
      imageUrl: blogDataDTO.imageUrl,
    };
    return this.blogRepository.createBlog(blogData);
  }

  async getBlog(query: any): Promise<IBlog[]> {
    return this.blogRepository.getBlog(query);
  }
  async getBlogById(id: string): Promise<IBlog[]> {
    return this.blogRepository.getBlogById(id);
  }
  async getRecentBlog() {
    return this.blogRepository.getRecentBlog();
  }
  async updateBlog(
    id: string,
    blogDataDTO: BlogsUpdateDTO
  ): Promise<IBlog | null> {
    const blogData: IBlog = {
      author: blogDataDTO.author,
      title: blogDataDTO.title,
      content: blogDataDTO.content,
      category: new mongoose.Types.ObjectId(blogDataDTO.category),
      likes: blogDataDTO.likes,
      tags: blogDataDTO.tags,
      blogDate: blogDataDTO.blogDate,
      imageUrl: blogDataDTO.imageUrl,
    };
    return this.blogRepository.updateBlog(id, blogData);
  }
  async deleteBlog(id: string) {
    return this.blogRepository.deleteBlog(id);
  }
}
