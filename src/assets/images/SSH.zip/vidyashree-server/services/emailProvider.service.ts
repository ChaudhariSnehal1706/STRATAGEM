import axios from 'axios';

export interface EmailTo {
  email: string;
  name: string;
}
export default class EmailProviderService {
  sendEmailUsingBrevo = async (emailData: {
    to: Array<{ email: string; name: string }>;
    subject: string;
    htmlContent: string;
  }) => {
    try {
      const API_KEY = process.env.BREVO_API_KEY;
      const API_URL: string =
        process.env.BERVO_API_URL || 'https://api.brevo.com/v3/smtp/email';

      const response = await axios.post(
        API_URL,
        {
          sender: {
            name: 'Milan',
            email: 'milan.r@gortnm.in',
          },
          to: emailData.to,
          subject: emailData.subject,
          htmlContent: emailData.htmlContent,
          // templateId: templateId,
          // params: params,
          headers: {
            //'X-Mailin-custom': 'custom_header_1:custom_value_1|custom_header_2:custom_value_2|custom_header_3:custom_value_3',
            charset: 'iso-8859-1',
          },
        },
        {
          headers: {
            accept: 'application/json',
            'api-key': API_KEY,
            'content-type': 'application/json',
          },
        }
      );

      return response.data;
    } catch (error) {
      console.log(error);
    }
  };

  sendEmailUsingSendgrid = async (emailData: {
    to: Array<string>;
    subject: string;
    htmlContent: string;
  }) => {
    const API_KEY = process.env.SENDGRID_API_KEY;
    const API_URL: string =
      process.env.SENDGRID_API_URL || 'https://api.sendgrid.com/v3/mail/send';

    const response = await axios.post(
      API_URL,
      {
        personalizations: [
          {
            to: emailData.to,
          },
        ],
        from: {
          email: process.env.SENDGRID_FROM_EMAIL || 'example@gmail.com',
        },
        subject: emailData.subject,
        content: [
          {
            type: 'text/html',
            value: emailData.htmlContent,
          },
        ],
      },
      {
        headers: {
          Authorization: `Bearer ${API_KEY}`,
          'Content-Type': 'application/json',
        },
      }
    );

    return response.data;
  };
}
