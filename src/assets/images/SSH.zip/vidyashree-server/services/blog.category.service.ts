import mongoose from 'mongoose';
import { BlogsAddDTO } from '../dto/blogs/blogs.add.dto';
import { BlogsUpdateDTO } from '../dto/blogs/blogs.update.dto';

import BlogCategoryRepository from '../repositories/blog.category.repository';
import { BlogsCategoryAddDTO } from '../dto/blogs-category/blogs.catergory.add.dto';
import { BlogsCategoryUpdateDTO } from '../dto/blogs-category/blogs.catergory.update.dto';
import { IBlogCategory } from '../models/blog.category.model';

export default class BlogCategoryService {
  readonly blogCategoryRepository = new BlogCategoryRepository();

  async createBlogCategory(
    blogDataDTO: BlogsCategoryAddDTO
  ): Promise<IBlogCategory> {
    const blogData: IBlogCategory = {
      name: blogDataDTO.categoryName,
      status: true,
    };
    return this.blogCategoryRepository.createBlogCategory(blogData);
  }

  async getBlogCategory(query: any): Promise<IBlogCategory[]> {
    return this.blogCategoryRepository.getBlogCategory(query);
  }
  async getBlogCategoryById(id: string): Promise<IBlogCategory[]> {
    return this.blogCategoryRepository.getBlogCategoryById(id);
  }

  async updateBlogCategory(
    id: string,
    blogDataDTO: BlogsCategoryUpdateDTO
  ): Promise<IBlogCategory | null> {
    const blogData: IBlogCategory = {
      name: blogDataDTO.categoryName,
      status: blogDataDTO.status,
    };
    return this.blogCategoryRepository.updateBlogCategory(id, blogData);
  }
  async deleteBlogCategory(id: string) {
    return this.blogCategoryRepository.deleteBlogCategory(id);
  }
}
