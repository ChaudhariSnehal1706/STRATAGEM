import mongoose from 'mongoose';
import { TestSeriesAddDTO } from '../dto/testSeries/testSeries.add.dto';
import { TestSeriesUpdateDTO } from '../dto/testSeries/testSeries.update.dto';
import { ITestSeries } from '../models/testSeries.model';
import TestSeriesRepository from '../repositories/testSeries.repository';

export default class TestSeriesService {
  readonly testSeriesRepository = new TestSeriesRepository();

  async createTestSeries(
    testSeriesDataDTO: TestSeriesAddDTO
  ): Promise<ITestSeries> {
    const testSeriesData: ITestSeries = {
      name: testSeriesDataDTO.name,
      banner_url: testSeriesDataDTO.banner_url,
      description: testSeriesDataDTO.description,
      category: new mongoose.Types.ObjectId(testSeriesDataDTO.category),
      noOfQuestions: testSeriesDataDTO.noOfQuestions,
      durationMinutes: testSeriesDataDTO.durationMinutes,
      maxMarks: testSeriesDataDTO.maxMarks,
      scheduleEndTime: testSeriesDataDTO.scheduleEndTime,
      scheduleStartTime: testSeriesDataDTO.scheduleStartTime,
      status: true,
      subcategory: new mongoose.Types.ObjectId(testSeriesDataDTO.subcategory),
      featured_flag: true,
    };
    return this.testSeriesRepository.createTestSeries(testSeriesData);
  }
  getFeaturedTestSeries(query: any): Promise<ITestSeries[]> {
    return this.testSeriesRepository.getFeaturedTestSeries(query);
  }
  getRecommendedTestSeries(query: any): Promise<ITestSeries[]> {
    return this.testSeriesRepository.getRecommendedTestSeries(query);
  }
  getUpcomingTestSeries(query: any): Promise<ITestSeries[]> {
    return this.testSeriesRepository.getUpcomingTestSeries(query);
  }
  async getTestSeries(query: any): Promise<ITestSeries[]> {
    return this.testSeriesRepository.getTestSeries(query);
  }
  async getTestSeriesById(id: string): Promise<ITestSeries[]> {
    return this.testSeriesRepository.getTestSeriesById(id);
  }
  async updateTestSeries(
    id: string,
    testSeriesDataDTO: TestSeriesUpdateDTO
  ): Promise<ITestSeries | null> {
    const testSeriesData: ITestSeries = {
      name: testSeriesDataDTO.name,
      banner_url: testSeriesDataDTO.banner_url,
      description: testSeriesDataDTO.description,
      category: new mongoose.Types.ObjectId(testSeriesDataDTO.category),
      noOfQuestions: testSeriesDataDTO.noOfQuestions,
      durationMinutes: testSeriesDataDTO.durationMinutes,
      maxMarks: testSeriesDataDTO.maxMarks,
      scheduleEndTime: testSeriesDataDTO.scheduleEndTime,
      scheduleStartTime: testSeriesDataDTO.scheduleStartTime,
      status: testSeriesDataDTO.status,
      featured_flag: testSeriesDataDTO.featured_flag,
      subcategory: new mongoose.Types.ObjectId(testSeriesDataDTO.subcategory),
    };
    return this.testSeriesRepository.updateTestSeries(id, testSeriesData);
  }
  async deleteTestSeries(id: string) {
    return this.testSeriesRepository.deleteTestSeries(id);
  }
}
