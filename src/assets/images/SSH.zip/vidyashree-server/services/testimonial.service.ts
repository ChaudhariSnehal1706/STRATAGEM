import { PartnersUpdateDTO } from '../dto/partners/partner.update.dto';
import { PartnersAddDTO } from '../dto/partners/partner.add.dto';
import { TestimonialsAddDTO } from '../dto/testimonials/testimonials.add.dto';
import { TestimonialsUpdateDTO } from '../dto/testimonials/testimonials.update.dto';
import { IPartner } from '../models/partner.model';
import { ITestimonial } from '../models/testimonial.model';
import PartnerRepository from '../repositories/partner.repository';
import TestimonialRepository from '../repositories/testimonial.repository';

export default class TestimonialsService {
  readonly testimonialRepository = new TestimonialRepository();

  async createTestimonials(
    testimonialDataDTO: TestimonialsAddDTO
  ): Promise<ITestimonial> {
    const testimonialData: ITestimonial = {
      name: testimonialDataDTO.name,
      status: true,
      position: testimonialDataDTO.position,
      textContent: testimonialDataDTO.textContent,
      mediaType: testimonialDataDTO.mediaType,
      mediaUrl: testimonialDataDTO.mediaUrl,
    };
    return this.testimonialRepository.createTestimonials(testimonialData);
  }

  async getTestimonials(): Promise<ITestimonial[]> {
    return this.testimonialRepository.getTestimonials();
  }
  async updateTestimonials(
    id: string,
    testimonialDataDTO: TestimonialsUpdateDTO
  ): Promise<ITestimonial | null> {
    const testimonialData: ITestimonial = {
      name: testimonialDataDTO.name,
      status: testimonialDataDTO.status,
      textContent: testimonialDataDTO.textContent,
      position: testimonialDataDTO.position,
      mediaType: testimonialDataDTO.mediaType,
      mediaUrl: testimonialDataDTO.mediaUrl,
    };
    return this.testimonialRepository.updateTestimonials(id, testimonialData);
  }
  async deleteTestimonial(id: string) {
    return this.testimonialRepository.deleteTestimonial(id);
  }
}
