import { QuestionsLevelAddDTO } from '../dto/questionsLevel/questionLevel.add.dto';
import { QuestionsLevelUpdateDTO } from '../dto/questionsLevel/questionLevel.update.dto';
import { IQuestionLevel } from '../models/questionLevel.model';
import QuestionLevelRespository from '../repositories/questionLevel.repository';

export default class QuestionLevelService {
  readonly questionLevelRespository = new QuestionLevelRespository();
  async createQuestionLevel(
    questionLevelDataDTO: QuestionsLevelAddDTO
  ): Promise<IQuestionLevel> {
    const questionLevelData: IQuestionLevel = {
      level: questionLevelDataDTO.level,
      status: true,
    };
    return this.questionLevelRespository.createQuestionLevel(questionLevelData);
  }
  async getQuestionLevel(query: any): Promise<IQuestionLevel[]> {
    return this.questionLevelRespository.getQuestionLevel(query);
  }
  async updateQuestionLevel(
    id: string,
    questionLevelDataDTO: QuestionsLevelUpdateDTO
  ): Promise<IQuestionLevel | null> {
    console.log(questionLevelDataDTO);
    const questionLevelData: IQuestionLevel = {
      level: questionLevelDataDTO.level,
      status: questionLevelDataDTO.status,
    };
    return this.questionLevelRespository.updateQuestionLevel(
      id,
      questionLevelData
    );
  }
  async deleteQuestionLevel(id: string) {
    return this.questionLevelRespository.deleteQuestionLevel(id);
  }
}
