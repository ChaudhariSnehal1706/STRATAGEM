import mongoose from 'mongoose';
import { SubCategoriesAddDTO } from '../dto/subcategories/subcategories.add.dto';
import { ISubcategory } from '../models/subcategory.model';
import SubcategoryRepository from '../repositories/subcategory.repository';
import { SubCategoriesUpdateDTO } from '../dto/subcategories/subcategories.update.dto';

export default class SubcategoryService {
  readonly subcategoryRepository = new SubcategoryRepository();

  async createSubcategory(
    subcategoryDataDTO: SubCategoriesAddDTO
  ): Promise<ISubcategory> {
    const subcategoryData: ISubcategory = {
      name: subcategoryDataDTO.name,
      category: new mongoose.Types.ObjectId(subcategoryDataDTO.category),
      status: true,
      board: new mongoose.Types.ObjectId(subcategoryDataDTO.board)
    };
    return this.subcategoryRepository.createSubcategory(subcategoryData);
  }

  async getSubcategory(query: any): Promise<ISubcategory[]> {
    return this.subcategoryRepository.getSubcategory(query);
  }
  async updateSubcategory(
    id: string,
    subcategoryDataDTO: SubCategoriesUpdateDTO
  ): Promise<ISubcategory | null> {
    const categoryData: ISubcategory = {
      name: subcategoryDataDTO.name,
      status: subcategoryDataDTO.status,
      category: new mongoose.Types.ObjectId(subcategoryDataDTO.category),
      board: new mongoose.Types.ObjectId(subcategoryDataDTO.board)
    };
    return this.subcategoryRepository.updateSubcategory(id, categoryData);
  }
  async deleteSubcategory(id: string) {
    return this.subcategoryRepository.deleteSubcategory(id);
  }

  async getSubCategoriesByCategoryId(
    categoryId: string
  ): Promise<ISubcategory[]> {
    return this.subcategoryRepository.getSubCategoriesByCategoryId(categoryId);
  }
}
