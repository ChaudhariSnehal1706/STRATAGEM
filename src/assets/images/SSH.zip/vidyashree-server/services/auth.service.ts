import {
  ForgetPasswordRequestOtpDTO,
  ForgetPasswordVerifyOtpDTO,
  ResetPasswordDTO,
  StudentLoginDTO,
  StudentLoginMobileDTO,
  StudentLoginOtpDTO,
  StudentRegisterDTO,
  StudentRegisterOtpVerifyDTO,
} from '../dto/auth/student.register.dto';
import { OtpType } from '../models/student.model';
import AuthRepository from '../repositories/auth.repository';
import CategoryRepository from '../repositories/category.repository';
import SubcategoryRepository from '../repositories/subcategory.repository';
import { FormValidationError } from '../validators/FormValidationError';
import EmailService from './email.service';

export default class AuthService {
  readonly authRepo = new AuthRepository();
  readonly categoryRepo = new CategoryRepository();
  readonly subcategoryRepo = new SubcategoryRepository();
  readonly emailService = new EmailService();

  async registerStudent(dto: StudentRegisterDTO) {
    const { name, email, mobileNumber, password, category, subcategory } = dto;

    // Check if email already exists
    const existingStudentByEmail =
      await this.authRepo.findStudentByEmail(email);
    if (existingStudentByEmail) {
      throw new FormValidationError({ email: 'Email already exists' });
    }

    // Check if mobile number already exists
    const existingStudentByMobile =
      await this.authRepo.findStudentByMobileNumber(mobileNumber);
    if (existingStudentByMobile) {
      throw new FormValidationError({
        mobileNumber: 'Mobile number already exists',
      });
    }

    // Check if category exists
    if (category) {
      const categoryData = await this.categoryRepo.getCategoryById(category);
      if (!categoryData) {
        throw new FormValidationError({ category: 'Invalid category' });
      }
    }

    // Check if subcategory exists
    if (subcategory) {
      const subcategoryData =
        await this.subcategoryRepo.getSubCategoryById(subcategory);
      if (!subcategoryData) {
        throw new FormValidationError({ subcategory: 'Invalid subcategory' });
      }
    }

    const savedStudent = await this.authRepo.createStudent({
      name,
      email,
      mobileNumber,
      password,
      category,
      subcategory,
    });

    const otp = await savedStudent.generateOtp(OtpType.REGISTER_EMAIL);

    // Send OTP in email
    await this.emailService.sendStudentVerificationOTPEmail(email, otp);

    return savedStudent.getPrimaryFields();
  }

  async studentRegisterOtpVerify(dto: StudentRegisterOtpVerifyDTO) {
    const { email, otp, studentId } = dto;

    // Check if email already exists
    const existingStudent = await this.authRepo.findStudentByEmailAndStudentId(
      email,
      studentId
    );

    if (!existingStudent) {
      throw new FormValidationError({ general: 'Student not Exists' });
    }

    // Verify the OTP
    const isOtpValid = await existingStudent.verifyOtp(
      otp,
      OtpType.REGISTER_EMAIL
    );
    if (!isOtpValid) {
      throw new FormValidationError({ otp: 'Invalid OTP' });
    }

    // Update student registration status
    existingStudent.isEmailVerified = true;
    await existingStudent.save();

    return { message: 'OTP verified successfully' };
  }

  async studentLogin(dto: StudentLoginDTO) {
    const { email, password, otp } = dto;

    // Check if student exists
    let existingStudent = await this.authRepo.findStudentByEmail(email);
    if (!existingStudent) {
      throw new FormValidationError({ email: 'Student not found' });
    }

    // Check if password matches
    const isPasswordValid = await existingStudent.comparePassword(password);
    if (!isPasswordValid) {
      throw new FormValidationError({ password: 'Invalid password' });
    }

    if (otp) {
      const isVerified = await existingStudent.verifyOtp(
        otp,
        OtpType.LOGIN_EMAIL_VERIFY
      );
      if (!isVerified) {
        throw new FormValidationError({ otp: 'Invalid OTP' });
      }

      existingStudent = await this.authRepo.updateStudentFields(
        existingStudent._id,
        {
          isEmailVerified: true,
        }
      );
    }

    // check if email is verified
    if (!existingStudent.isEmailVerified) {
      // Generate OTP
      const otp = await existingStudent.generateOtp(OtpType.LOGIN_EMAIL_VERIFY);

      // send otp in email
      await this.emailService.sendStudentLoginOTPEmail(email, otp);

      return {
        message:
          'Please enter the OTP sent to your email to proceed with login.',
        data: {
          action: 'USER_NOT_VERIFIED',
        },
      };
    }

    const tokenDetail = await existingStudent.generateAuthToken();
    const { token } = tokenDetail;

    return {
      message: 'Login successful',
      data: {
        student: existingStudent.getPrimaryFields(),
        token,
      },
    };
  }

  async studentLoginOtpSend(dto: StudentLoginOtpDTO) {
    const { mobileNumber } = dto;

    // Check if mobile number already exists
    const existingStudent =
      await this.authRepo.findStudentByMobileNumber(mobileNumber);
    if (!existingStudent) {
      throw new FormValidationError({
        mobileNumber: 'Mobile number does not exists',
      });
    }

    if (!existingStudent.email) {
      throw new FormValidationError({ mobileNumber: 'Email does not exists' });
    }

    // if (!existingStudent.isEmailVerified) {
    //   throw new FormValidationError({ mobileNumber: 'User does not exists' });
    // }

    // Generate OTP
    const otp = await existingStudent.generateOtp(OtpType.LOGIN_MOBILE);

    // send otp in email
    await this.emailService.sendStudentLoginOTPEmail(
      existingStudent.email,
      otp
    );

    return;
  }

  async studentLoginMobile(dto: StudentLoginMobileDTO) {
    const { mobileNumber, otp } = dto;

    // Check if mobile number already exists
    const existingStudent =
      await this.authRepo.findStudentByMobileNumber(mobileNumber);
    if (!existingStudent) {
      throw new FormValidationError({
        otp: 'Mobile number does not exist',
      });
    }

    if (!existingStudent.email) {
      throw new FormValidationError({ otp: 'User does not exist' });
    }

    const isVerified = await existingStudent.verifyOtp(
      otp,
      OtpType.LOGIN_MOBILE
    );
    if (!isVerified) {
      throw new FormValidationError({ otp: 'Invalid OTP' });
    }

    const tokenDetail = await existingStudent.generateAuthToken();

    await this.authRepo.updateStudentFields(existingStudent._id, {
      isEmailVerified: true,
    });

    return {
      student: existingStudent.getPrimaryFields(),
      tokenDetail,
    };
  }

  async initialUserDetail(studentId: string) {
    const student = await this.authRepo.findStudentById(studentId);
    return student;
  }

  async forgetPasswordRequestOtp(dto: ForgetPasswordRequestOtpDTO) {
    const { emailOrMobileNumber } = dto;

    // Check if user exists with the provided email or mobile number
    const existingUser =
      await this.authRepo.findStudentByEmailOrMobileNumber(emailOrMobileNumber);
    if (!existingUser) {
      throw new FormValidationError({ emailOrMobileNumber: 'User not found' });
    }

    // Generate OTP
    const otp = await existingUser.generateOtp(OtpType.FORGET_PASSWORD);

    await this.emailService.sendStudentResetPasswordOTPEmail(
      existingUser.email!,
      otp
    );

    return { message: 'OTP sent successfully' };
  }

  async forgetPasswordVerifyOtp(dto: ForgetPasswordVerifyOtpDTO) {
    const { emailOrMobileNumber, otp } = dto;

    // Check if user exists with the provided email or mobile number
    const existingUser =
      await this.authRepo.findStudentByEmailOrMobileNumber(emailOrMobileNumber);
    if (!existingUser) {
      throw new FormValidationError({ emailOrMobileNumber: 'User not found' });
    }

    // Verify if OTP matches
    const isOtpValid = await existingUser.verifyOtp(
      otp,
      OtpType.FORGET_PASSWORD,
      true
    );
    if (!isOtpValid) {
      throw new FormValidationError({ otp: 'Invalid OTP' });
    }

    return { message: 'OTP verified successfully' };
  }

  async resetPassword(dto: ResetPasswordDTO) {
    const { emailOrMobileNumber, otp, newPassword } = dto;

    // Check if user exists with the provided email or mobile number
    const existingUser =
      await this.authRepo.findStudentByEmailOrMobileNumber(emailOrMobileNumber);
    if (!existingUser) {
      throw new FormValidationError({ emailOrMobileNumber: 'User not found' });
    }

    // Verify if OTP matches
    const isOtpValid = await existingUser.verifyOtp(
      otp,
      OtpType.FORGET_PASSWORD
    );
    if (!isOtpValid) {
      throw new FormValidationError({ otp: 'Invalid OTP' });
    }

    // Reset password
    await this.authRepo.updateStudentFields(existingUser._id, {
      password: newPassword,
    });

    return { message: 'Password reset successfully' };
  }
}
