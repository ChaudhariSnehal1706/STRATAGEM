import { CategoriesAddDTO } from '../dto/categories/categories.add.dto';
import { CategoriesUpdateDTO } from '../dto/categories/categories.update.dto';
import { ICategory } from '../models/category.model';
import CategoryRepository from '../repositories/category.repository';

export default class CategoryService {
  readonly categoryRepository = new CategoryRepository();

  async getCategories(): Promise<ICategory[]> {
    return this.categoryRepository.getCategories();
  }

  async getCategoryById(id: string): Promise<ICategory | null> {
    return this.categoryRepository.getCategoryById(id);
  }

  async createCategory(categoryDataDTO: CategoriesAddDTO): Promise<ICategory> {
    const categoryData: ICategory = {
      name: categoryDataDTO.name,
      status: true,
      iconUrl: categoryDataDTO.iconUrl,
      totalTestSeries: categoryDataDTO.totalTestSeries,
    };
    return this.categoryRepository.createCategory(categoryData);
  }
  async updateCategory(
    id: string,
    categoryDataDTO: CategoriesUpdateDTO
  ): Promise<ICategory | null> {
    const categoryData: ICategory = {
      name: categoryDataDTO.name,
      status: categoryDataDTO.status,
      iconUrl: categoryDataDTO.iconUrl,
      totalTestSeries: categoryDataDTO.totalTestSeries,
    };
    return this.categoryRepository.updateCategory(id, categoryData);
  }

  async deleteCategory(id: string) {
    return this.categoryRepository.deleteCategory(id);
  }
}
