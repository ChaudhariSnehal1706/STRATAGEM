import { ExamsAddDTO } from '../dto/exams/exams.add.dto';
import { ExamsUpdateDTO } from '../dto/exams/exams.update.dto';
import { PartnersUpdateDTO } from '../dto/partners/partner.update.dto';
import { PartnersAddDTO } from '../dto/partners/partner.add.dto';
import { IExam } from '../models/exam.model';
import { IPartner } from '../models/partner.model';
import ExamRepository from '../repositories/exam.repository';

export default class ExamService {
  readonly examRepository = new ExamRepository();

  async createExam(examDataDTO: ExamsAddDTO): Promise<IExam> {
    const partnerData: IExam = {
      name: examDataDTO.name,
    };
    return this.examRepository.createExam(partnerData);
  }

  async getExam(): Promise<IExam[]> {
    return this.examRepository.getExam();
  }
  async updateExam(
    id: string,
    partnerDataDTO: ExamsUpdateDTO
  ): Promise<IExam | null> {
    const partnerData: IExam = {
      name: partnerDataDTO.name,
    };
    return this.examRepository.updateExam(id, partnerData);
  }
}
