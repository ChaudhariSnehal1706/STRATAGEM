import { PartnersUpdateDTO } from '../dto/partners/partner.update.dto';
import { PartnersAddDTO } from '../dto/partners/partner.add.dto';
import { IPartner } from '../models/partner.model';
import PartnerRepository from '../repositories/partner.repository';

export default class PartnerService {
  readonly partnerRepository = new PartnerRepository();

  async createPartner(partnerDataDTO: PartnersAddDTO): Promise<IPartner> {
    const partnerData: IPartner = {
      name: partnerDataDTO.name,
      status: true,
      logoURL: partnerDataDTO.logoURL,
    };
    return this.partnerRepository.createPartners(partnerData);
  }

  async getPartner(): Promise<IPartner[]> {
    return this.partnerRepository.getPartners();
  }
  async updatePartner(
    id: string,
    partnerDataDTO: PartnersUpdateDTO
  ): Promise<IPartner | null> {
    const partnerData: IPartner = {
      name: partnerDataDTO.name,
      status: partnerDataDTO.status,
      logoURL: partnerDataDTO.logoURL,
    };
    return this.partnerRepository.updatePartners(id, partnerData);
  }
  async deletePartner(id: string) {
    return this.partnerRepository.deletePartners(id);
  }
}
