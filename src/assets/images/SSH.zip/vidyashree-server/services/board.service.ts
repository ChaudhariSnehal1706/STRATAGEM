import { BoardsAddDto } from "../dto/boards/boards.add.dto";
import { BoardsUpdateDto } from "../dto/boards/boards.update.dto";
import { IBoard } from "../models/board.model";
import BoardRepository from "../repositories/board.repository";

export default class BoardService {
    readonly boardRepository = new BoardRepository();
    async createBoard(boardDataDTO: BoardsAddDto): Promise<IBoard> {
        const boardData: IBoard = {
            board: boardDataDTO.board,
            category:boardDataDTO.category,
            status:true
        };
        return this.boardRepository.createBoard(boardData);
    }
    async updateBoard(id: string, boardDataDTO: BoardsUpdateDto): Promise<IBoard | null> {
        const boardData: IBoard = {
            board: boardDataDTO.board,
            status:boardDataDTO.status,
            category:boardDataDTO.category,
        }
        return this.boardRepository.updateBoard(id, boardData);
    }
    async getBoard(query:any): Promise<IBoard[]> {
        return await this.boardRepository.getBoard(query);
    }
    async deleteBoard(id: string){
        return await this.boardRepository.deleteBoard(id);
    }
    
}