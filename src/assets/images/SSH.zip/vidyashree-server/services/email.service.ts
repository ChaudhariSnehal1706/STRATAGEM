import EmailProviderService from './emailProvider.service';

export default class EmailService {
  emailProviderService = new EmailProviderService();

  sendStudentVerificationOTPEmail = async (
    to: string,
    otp: string | number
  ): Promise<void> => {
    await this.emailProviderService.sendEmailUsingBrevo({
      to: [{ email: to, name: to }],
      subject: 'Your OTP for Verification',
      htmlContent: `<p>Your OTP is <strong>${otp}</strong>. Please use it to verify your account.</p>`,
    });
  };

  sendStudentLoginOTPEmail = async (
    to: string,
    otp: string | number
  ): Promise<void> => {
    await this.emailProviderService.sendEmailUsingBrevo({
      to: [{ email: to, name: to }],
      subject: 'Your OTP for Verification',
      htmlContent: `<p>Your OTP is <strong>${otp}</strong>. Please use it to login your account.</p>`,
    });
  };

  sendStudentResetPasswordOTPEmail = async (
    to: string,
    otp: string | number
  ): Promise<void> => {
    await this.emailProviderService.sendEmailUsingBrevo({
      to: [{ email: to, name: to }],
      subject: 'Your OTP for Verification',
      htmlContent: `<p>Your OTP is <strong>${otp}</strong>. Please use it to reset password your account.</p>`,
    });
  };
}
