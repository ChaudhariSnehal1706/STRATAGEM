import jwt from 'jsonwebtoken';

const TokenExpiration = {
  ONE_MINUTE: '1m',
  FIFTEEN_MINUTES: '15m',
  ONE_HOUR: '1h',
  ONE_DAY: '1d',
} as const;

type TokenExpirationType =
  (typeof TokenExpiration)[keyof typeof TokenExpiration];

export default class JwtHelper {
  readonly expiresIn: TokenExpirationType = TokenExpiration.ONE_DAY;

  generateToken(payload: any): string {
    const secretKey = process.env.JWT_TOKEN_SECRET || '';
    const options = { expiresIn: this.expiresIn };

    console.log('secretKey', secretKey);
    return jwt.sign(payload, secretKey, options);
  }

  verifyToken(token: string): any {
    try {
      const secretKey = process.env.JWT_TOKEN_SECRET || '';
      token = token.replace('Bearer ', '');
      const decoded = jwt.verify(token, secretKey);
      return decoded;
    } catch (error) {
      console.log(error);
      return null;
    }
  }

  expiresInToMilliseconds(): number {
    switch (this.expiresIn) {
      case TokenExpiration.ONE_MINUTE:
        return 60 * 1000;
      case TokenExpiration.FIFTEEN_MINUTES:
        return 15 * 60 * 1000;
      case TokenExpiration.ONE_HOUR:
        return 60 * 60 * 1000;
      case TokenExpiration.ONE_DAY:
        return 24 * 60 * 60 * 1000;
      default:
        throw new Error('Invalid expiration value');
    }
  }
}
