import mongoose from 'mongoose';
const slug = require('mongoose-slug-generator');

mongoose.plugin(slug);

const connectDB = async () => {
  try {
    await mongoose.connect(
      'mongodb+srv://patmanasvi03:IsxML50hT2aW4lNC@cluster0.kkybayr.mongodb.net/vds'
    );
    console.log('Connected to MongoDB');
  } catch (error) {
    console.error('MongoDB connection error:', error);
  }
};

export { connectDB };
