// Adjust this import according to your project structure

import { UserModel } from '../models/user.model';
const otpGenerator = require('otp-generator-random');

class OtpHelper {
  async generateOtp(userId: string): Promise<string> {
    const otp = otpGenerator.generate(6, {
      upperCase: false,
      specialChars: false,
    });
    const user = await UserModel.findById(userId);
    if (!user) throw new Error('User not found');

    user.latest_otp = otp;
    user.otp_expiration = new Date(new Date().getTime() + 15 * 60 * 1000); // OTP expires after 15 minutes
    await user.save();

    return otp;
  }

  async validateOtp(userId: string, otp: string): Promise<boolean> {
    const user = await UserModel.findById(userId);
    if (!user) throw new Error('User not found');

    if (user.latest_otp !== otp) return false;
    if (user.otp_expiration == null || new Date() > user.otp_expiration)
      return false;

    user.latest_otp = '';
    user.otp_expiration = null;
    await user.save();

    return true;
  }
}

export default new OtpHelper();
