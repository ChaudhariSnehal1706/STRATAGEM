import { useAppSelector } from "@/store";
import { cookies } from "@/store/api/apiSlice";

const useSession = () => {
  const userDetail = useAppSelector((state) => state.auth.user);
  const token = cookies.get("authToken");

  return {
    isAuthenticated: token,
    token,
    userDetail,
  };
};

export default useSession;
