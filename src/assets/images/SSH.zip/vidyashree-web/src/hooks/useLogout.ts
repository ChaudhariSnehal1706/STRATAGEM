import { routes } from "@/constants/routes";
import { useAppDispatch } from "@/store";
import { cookies } from "@/store/api/apiSlice";
import { resetAuth } from "@/store/slice/authSlice";
import { useRouter } from "next/navigation";

export const useLogout = () => {
  const dispatch = useAppDispatch();
  const router = useRouter();

  const handleLogout = () => {
    cookies.remove("authToken");
    dispatch(resetAuth());
    router.push(routes.login);
  };

  return handleLogout;
};
