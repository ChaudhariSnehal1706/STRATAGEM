import { routes } from "@/constants/routes";
import { useAppDispatch } from "@/store";
import { cookies } from "@/store/api/apiSlice";
import { UserType, setUserDetail } from "@/store/slice/authSlice";
import { useRouter } from "next/navigation";

const useHandleAfterLogin = () => {
  const router = useRouter();
  const dispatch = useAppDispatch();

  return (token: string, userDetail: UserType) => {
    cookies.set("authToken", token, { maxAge: 24 * 60 * 60 * 1000 });
    router.push(routes.dashboard);
    dispatch(setUserDetail(userDetail));
  };
};

export default useHandleAfterLogin;
