"use client";
import "./page.css";
import Footer from "../components/footer/footer";
import Header from "../components/header/header";
import SectionHeading from "../components/util/section-heading";
import List from "../components/util/list";

export default function PrivacyPolicy() {
  return (
    <>
      <Header
        title="Privacy Policy"
        subTitle="Last Modification 20 January 2023"
      />

      <SectionHeading>
        We welcome you at VidyaShree! We have designed our Privacy Policy to
        help you understand how we collect and use your personal information
        when you use our platform. Using our products and services means, you
        have read, understood, and agreed to the Privacy Policy of VidyaShree.
      </SectionHeading>

      <SectionHeading title="How We Collect Information From You" />
      <List>
        User Information: When you register yourself at VidyaShree, we may
        collect your personal information from you such as your name, email
        address, contact no, etc
      </List>
      <List>
        Usage Information: We automatically collect information about how you
        are using our platform or services, including your IP address, device
        information, browser type, and pages visited.
      </List>
      <List>
        Student Data: If you are a student, we may collect educational
        information such as performance data, grades, and progress within the
        platform
      </List>
      <List>
        Payment Information: If you make purchases on our platform, we will
        collect payment information such as credit card details.
      </List>

      <SectionHeading title="How We Use Your Information" />
      <List>
        We may use your information for sending your information regarding our
        new services, offers, important updates, newsletters, etc
      </List>
      <List>
        We use analytics tools to understand how users interact with our
        Service, analyze trends, and improve user experience.
      </List>
      <List>
        We use several effective measures to protect your personal information
        from unauthorized measures.
      </List>
      <List>
        We may share your information with your partners, who help us to
        operate, analyse and improve our services.
      </List>
      <List>
        We may disclose your information in response to legal requests, court
        orders, or to comply with applicable laws and regulations.
      </List>
      <List>
        You can opt out of receiving promotional emails by following the
        instructions in the email.
      </List>

      <SectionHeading title="Change in Policy">
        We can modify our policy anytime we want
        <br />
        <br />
        We will immediately inform you through email if we change our policy at
        any time.
      </SectionHeading>
      <br />
      <Footer />
    </>
  );
}
