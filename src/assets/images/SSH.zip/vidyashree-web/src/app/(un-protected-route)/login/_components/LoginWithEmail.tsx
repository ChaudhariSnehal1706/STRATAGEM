"use client";

import { Input } from "@/app/components/formFields";
import { OTPField } from "@/app/components/otp";
import { CustomDarkButton } from "@/app/components/ui/button";
import { routes } from "@/constants/routes";
import rhfSetError from "@/functions/rhfSetError";
import useHandleAfterLogin from "@/hooks/useHandleAfterLogin";
import { useLoginStudentMutation } from "@/store/api/authSlice";
import { yupResolver } from "@hookform/resolvers/yup";
import { Box } from "@mui/material";
import Link from "next/link";
import { useState } from "react";
import { FormProvider, useForm } from "react-hook-form";
import { toast } from "react-toastify";
import * as yup from "yup";

interface FormData {
  email: string;
  password: string;
  otp?: string;
}

const schema = yup.object().shape({
  email: yup
    .string()
    .email("Invalid email format.")
    .required("Email is required."),

  password: yup
    .string()
    .min(8, "Password must be at least 8 characters long.")
    .required("Password is required."),

  otp: yup.string().optional(),
});

const LoginWithEmail = ({
  handleLoginViaOTPClick,
}: {
  handleLoginViaOTPClick: () => void;
}) => {
  const [loginStudent, { isLoading }] = useLoginStudentMutation();
  const handleAfterLogin = useHandleAfterLogin();

  const [showOtp, setShowOtp] = useState(false);

  const methods = useForm<FormData>({
    resolver: yupResolver(schema),
    defaultValues: {
      email: "",
      password: "",
      otp: "",
    },
  });
  const { handleSubmit, setError, control } = methods;

  const onSubmit = async (data: FormData) => {
    try {
      const res: any = await loginStudent(data);

      if (res?.error?.status === 422) {
        rhfSetError(res.error.data, setError);
      } else {
        const action = res?.data?.data?.action;
        if (action === "USER_NOT_VERIFIED") {
          toast.info(res?.data?.message);
          setShowOtp(true);
        } else {
          const token = res?.data?.data?.token;
          const student = res?.data?.data?.student;
          toast.success(res?.data?.message);
          handleAfterLogin(token, student);
        }
      }
    } catch (error: any) {
      console.error(error.message);
    }
  };

  return (
    <FormProvider {...methods}>
      <form onSubmit={handleSubmit(onSubmit)}>
        <Box display="flex" flexDirection="column" rowGap={2}>
          <Input name="email" placeholder="Enter Email" label="Email" />
          <Input
            type="password"
            name="password"
            placeholder="Enter password"
            label="Password"
          />

          {showOtp && <OTPField name="otp" control={control} />}

          <Box display="flex" justifyContent="space-between">
            <Link href={routes.forgotPassword.student}>
              <p className="cursor-pointer font-semibold text-[#8B75F3]">
                Forgot Password?
              </p>
            </Link>
            <p
              className="cursor-pointer font-semibold text-[#778590]"
              onClick={handleLoginViaOTPClick}
            >
              Login via OTP
            </p>
          </Box>

          <CustomDarkButton type="submit" disabled={isLoading}>
            Login
          </CustomDarkButton>
        </Box>
      </form>
    </FormProvider>
  );
};

export default LoginWithEmail;
