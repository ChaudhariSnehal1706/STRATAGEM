"use client";

import Sidebar from "@/app/components/sidebar/sidebar";
import { useState } from "react";
export default function TeacherRegister() {
  const [position, setPosition] = useState(0);
  const steps = ["Step 1", "Step 2", "Step 3", "Step 4", "Step 5", "Step 6"];

  return (
    <>
      <Sidebar steps={steps} active={position} />

      <div className="px-10 py-10 flex  font-medium">
        <p> Full Name</p>
        <p className="px-[338px]"> Email ID</p>
      </div>

      <div
        className=" px-10 text-grey font-normal flex gap-8"
        style={{ marginTop: "-25px" }}
      >
        <input
          type="text "
          placeholder="Select your Category"
          style={{
            border: "1px solid #C7C7C2",
            borderRadius: "8px",
            width: "376px",
            height: "54px",
            paddingLeft: "14px",
          }}
        />

        <input
          type="text "
          placeholder="Select multiple subject"
          style={{
            border: "1px solid #C7C7C2",
            borderRadius: "8px",
            width: "376px",
            height: "54px",
            paddingLeft: "14px",
          }}
        />
      </div>
      <div className="px-10 py-10 flex font-medium ">
        <p> Mobile Number</p>
        <p className="px-[288px]"> Password</p>
      </div>
      <div
        className=" px-10 text-grey font-normal flex gap-8"
        style={{ marginTop: "-25px" }}
      >
        <input
          type="text "
          placeholder="Select your Category"
          style={{
            border: "1px solid #C7C7C2",
            borderRadius: "8px",
            width: "376px",
            height: "54px",
            paddingLeft: "14px",
          }}
        />

        <input
          type="text "
          placeholder="Select multiple subject"
          style={{
            border: "1px solid #C7C7C2",
            borderRadius: "8px",
            width: "376px",
            height: "54px",
            paddingLeft: "14px",
          }}
        />
      </div>
      <div className="px-10 py-10 flex font-medium ">
        <p> Work Experience</p>
        <p className="px-[275px]"> Area of Expertise</p>
      </div>
      <div
        className=" px-10 text-grey font-normal flex gap-8"
        style={{ marginTop: "-25px" }}
      >
        <input
          type="text "
          placeholder="Select your Category"
          style={{
            border: "1px solid #C7C7C2",
            borderRadius: "8px",
            width: "376px",
            height: "54px",
            paddingLeft: "14px",
          }}
        />

        <input
          type="text "
          placeholder="Select multiple subject"
          style={{
            border: "1px solid #C7C7C2",
            borderRadius: "8px",
            width: "376px",
            height: "54px",
            paddingLeft: "14px",
          }}
        />
      </div>
      <p
        className="text-[#778590] py-10 px-10 flex"
        style={{ marginTop: "-25px" }}
      >
        By clicking Register, you agree to the{" "}
        <span className="text-[#8B75F3] ml-1 mr-1"> Terms and Condition </span>{" "}
        & <span className="text-[#8B75F3] ml-1 mr-1"> Privacy Policy</span> of
        VidhyaShree
      </p>

      <div className="flex justify-end mr-72 gap-3">
        <button
          className="bg-[#8B75F3] text-white w-[80px] h-[46px]  rounded-xl"
          onClick={() => {
            if (steps.length <= position) return;
            setPosition((e) => {
              if (e === 0) return 0;
              return e - 1;
            });
          }}
        >
          Back
        </button>

        <button
          className="bg-[#8B75F3] text-white w-[167px] h-[46px] rounded-xl"
          onClick={() => {
            if (steps.length <= position) return;
            setPosition((e) => {
              return e + 1;
            });
          }}
        >
          Register Now
        </button>
      </div>
    </>
  );
}
0;
