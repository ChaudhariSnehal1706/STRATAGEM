"use client";

import { Input } from "@/app/components/formFields/input/Input";
import { CustomPrimaryButton } from "@/app/components/ui/button";
import { routes } from "@/constants/routes";
import rhfSetError from "@/functions/rhfSetError";
import {
  useRegisterStudentVerifyOtpMutation,
  useRegisterUserMutation,
} from "@/store/api/authSlice";
import { yupResolver } from "@hookform/resolvers/yup";
import { Box, Divider, InputLabel } from "@mui/material";
import { MuiOtpInput } from "mui-one-time-password-input";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { FormProvider, useForm } from "react-hook-form";
import { toast } from "react-toastify";
import styled from "styled-components";
import * as yup from "yup";
import CategorySelection from "./_component/CategorySelection";

const MuiOtpInputStyled = styled(MuiOtpInput)`
  .MuiOutlinedInput-root {
    background-color: #fbfbfb;
    height: 54px;
    width: 54px;
  }
`;

interface FormData {
  name: string;
  email: string;
  mobileNumber: string;
  password: string;
  category: string;
  subcategory: string;
}

const schema = yup.object().shape({
  name: yup.string().required("Name is required."),
  email: yup
    .string()
    .email("Invalid email format.")
    .required("Email is required."),
  mobileNumber: yup
    .string()
    .matches(/^[0-9]+$/, "Mobile number must contain only digits.")
    .min(10, "Mobile number must be at least 10 digits long.")
    .required("Mobile number is required."),
  password: yup
    .string()
    .min(8, "Password must be at least 8 characters long.")
    .required("Password is required."),
  category: yup.string().required("Category is required."),
  subcategory: yup.string().required("Subcategory is required."),
});

export default function StudentRegister() {
  const router = useRouter();
  const [registerUser, { isLoading }] = useRegisterUserMutation();
  const [
    registerStudentVerifyOtp,
    { isLoading: registerStudentVerifyOtpIsLoading },
  ] = useRegisterStudentVerifyOtpMutation();

  const [showOtp, setShowOtp] = useState(false);
  const [otp, setOtp] = useState("");
  const [studentId, setStudentId] = useState(null);

  const methods = useForm<FormData>({
    resolver: yupResolver(schema),
    defaultValues: {
      name: "",
      email: "",
      mobileNumber: "",
      password: "",
      category: "",
      subcategory: "",
    },
  });
  const { handleSubmit, setError, getValues } = methods;

  const onSubmit = async (data: FormData) => {
    try {
      const res: any = await registerUser(data);

      if (res?.error?.status === 422) {
        rhfSetError(res.error.data, setError);
      } else {
        toast.success(res?.data?.message);
        setShowOtp(true);
        setStudentId(res?.data?.data?._id);
      }
    } catch (error: any) {
      console.error(error.message);
    }
  };

  const handleChange = (newValue: string) => {
    setOtp(newValue);
  };

  const verifyOtp = async () => {
    const otpValue = `${otp}`;

    if (otpValue.length !== 6) return;

    const email = getValues("email");
    const res: any = await registerStudentVerifyOtp({
      otp: otpValue,
      email,
      studentId,
    });
    if (res?.error?.status === 422) {
      Object.values(res?.error?.data || {}).forEach((error) => {
        toast.error(error as string);
      });
    } else {
      toast.success(res?.data?.message);
      router.push(routes.login);
    }
  };

  return (
    <>
      <FormProvider {...methods}>
        <form onSubmit={handleSubmit(onSubmit)}>
          <Box display="flex" flexDirection="column" gap={3}>
            <Input
              name="name"
              placeholder="What is your name?"
              label="Full Name"
            />
            <Input
              name="email"
              placeholder="Tell us your email ID"
              label="Email ID"
            />
            <Input
              name="mobileNumber"
              placeholder="+91 Mobile Number"
              label="Mobile Number"
            />
            <Input
              type="password"
              name="password"
              placeholder="Create a password for your account"
              label="Password"
              helperText="Minimum 8 character Required"
            />

            <CategorySelection />

            <p className="flex">
              By clicking Register, you agree to the
              <span className="text-[#8B75F3] ml-1 mr-1">
                Terms and Condition
              </span>
              &<span className="text-[#8B75F3] ml-1 mr-1"> Privacy Policy</span>
              of VidhyaShree
            </p>
            {!showOtp && (
              <CustomPrimaryButton
                type="submit"
                className="w-[167px]"
                disabled={isLoading}
              >
                Register Now
              </CustomPrimaryButton>
            )}
          </Box>
        </form>
      </FormProvider>

      {showOtp && (
        <>
          <Divider />
          <Box display="flex" flexDirection="column" gap={2}>
            <InputLabel>Enter Otp to verify Email address</InputLabel>

            <MuiOtpInputStyled
              length={6}
              autoFocus
              value={otp}
              onChange={handleChange}
            />

            <CustomPrimaryButton
              type="button"
              className="w-[167px]"
              onClick={verifyOtp}
              disabled={registerStudentVerifyOtpIsLoading}
            >
              Verify
            </CustomPrimaryButton>
          </Box>
        </>
      )}
    </>
  );
}
