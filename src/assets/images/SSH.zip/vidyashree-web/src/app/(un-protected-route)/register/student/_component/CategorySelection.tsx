"use client";

import { Select } from "@/app/components/formFields";
import {
  useCategoriesQuery,
  useSubCategoriesByCategoryIdQuery,
} from "@/store/api/commonSlice";
import { useEffect } from "react";
import { useFormContext } from "react-hook-form";

function CategorySelection() {
  const { setValue, watch } = useFormContext();
  const selectedCategory = watch("category");

  const {
    data: categoriesData,
    isLoading: categoriesIsLoading,
    isError: categoriesIsError,
  } = useCategoriesQuery(null);

  const {
    data: subCategoriesData,
    isLoading: subCategoriesIsLoading,
    isError: subCategoriesIsError,
  } = useSubCategoriesByCategoryIdQuery(
    { categoryId: selectedCategory! },
    { skip: !selectedCategory }
  );

  useEffect(() => {
    setValue("subcategory", "");
  }, [selectedCategory, setValue]);

  return (
    <div className="flex gap-8">
      <Select
        name="category"
        label="Add Category"
        labelPath="name"
        valuePath="_id"
        options={categoriesData?.data || []}
        addEmptyOption
        emptyOptionLabel="Please Select Category"
        isLoading={categoriesIsLoading}
        isError={categoriesIsError}
      />

      <Select
        name="subcategory"
        label="Add Sub Category"
        labelPath="name"
        valuePath="_id"
        options={subCategoriesData?.data || []}
        addEmptyOption
        emptyOptionLabel="Please Select Subcategory"
        isLoading={subCategoriesIsLoading}
        isError={subCategoriesIsError}
      />
    </div>
  );
}

export default CategorySelection;
