import { OTPField } from "@/app/components/otp";
import { CustomDarkButton } from "@/app/components/ui/button";
import rhfSetError from "@/functions/rhfSetError";
import useHandleAfterLogin from "@/hooks/useHandleAfterLogin";
import { useVerifyStudentLoginAndLogInMutation } from "@/store/api/authSlice";
import { yupResolver } from "@hookform/resolvers/yup";
import { Box } from "@mui/material";
import { FormProvider, useForm } from "react-hook-form";
import { toast } from "react-toastify";
import { OtpFormData, otpSchema } from "./LoginWithMobileNumber";

export const OtpForm = ({
  mobileNumber,
  handleLoginViaPasswordClick,
}: {
  mobileNumber: string;
  handleLoginViaPasswordClick: () => void;
}) => {
  const handleAfterLogin = useHandleAfterLogin();

  const [verifyStudentLoginAndLogIn, { isLoading }] =
    useVerifyStudentLoginAndLogInMutation();

  const otpForm = useForm<OtpFormData>({
    resolver: yupResolver(otpSchema),
    defaultValues: {
      otp: "",
    },
  });

  const handleVerifyOTP = async (data: OtpFormData) => {
    try {
      const res: any = await verifyStudentLoginAndLogIn({
        ...data,
        mobileNumber,
      });

      if (res?.error?.status === 422) {
        rhfSetError(res.error.data, otpForm.setError);
      } else {
        const token = res?.data?.data?.token;
        const student = res?.data?.data?.student;
        toast.success(res?.data?.message);
        handleAfterLogin(token, student);
      }
    } catch (error: any) {
      console.error(error.message);
    }
  };

  return (
    <FormProvider {...otpForm}>
      <form onSubmit={otpForm.handleSubmit(handleVerifyOTP)}>
        <Box display="flex" flexDirection="column" rowGap={2}>
          <OTPField<OtpFormData> name="otp" control={otpForm.control} />

          <p
            className="ml-auto cursor-pointer text-base font-semibold text-[#778590]"
            onClick={handleLoginViaPasswordClick}
          >
            Login via password
          </p>

          <CustomDarkButton type="submit" disabled={isLoading}>
            Verify
          </CustomDarkButton>
        </Box>
      </form>
    </FormProvider>
  );
};
