import { CustomDarkButton } from "@/app/components/ui/button";
import { routes } from "@/constants/routes";
import { Box } from "@mui/material";
import Image from "next/image";
import Link from "next/link";

const SuccessPage = () => {
  return (
    <div className="flex h-screen w-full justify-center overflow-hidden">
      <div className="flex w-full justify-center bg-[#F8F6FF] py-20 shadow-2xl">
        <Image
          loading="lazy"
          src="/images/forget_password_success.png"
          alt=""
          style={{ width: "494px", height: "494px", marginTop: "10opx" }}
          width={494}
          height={494}
        />
      </div>
      <div className="h-full bg-[#ffffff] w-[552px] min-w-[552px] p-[80px] overflow-y-auto">
        <Box display="flex" flexDirection="column" rowGap={5}>
          <Image
            loading="lazy"
            src="/images/Logo1.png"
            alt=""
            width={70}
            height={71}
          />
          <p className="text-2xl font-semibold">
            &quot;Congratulations! Your Password Reset is Complete
            &#127881;&quot;
          </p>

          <Link href={routes.login}>
            <CustomDarkButton className="w-full">Login</CustomDarkButton>
          </Link>
        </Box>
      </div>
    </div>
  );
};

export default SuccessPage;
