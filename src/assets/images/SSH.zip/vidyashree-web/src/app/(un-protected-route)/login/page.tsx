"use client";

import { routes } from "@/constants/routes";
import useSession from "@/hooks/useSession";
import Image from "next/image";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import LoginWithEmail from "./_components/LoginWithEmail";
import LoginWithMobileNumber from "./_components/LoginWithMobileNumber";
import StudentTeacherSelection, {
  userTypes,
} from "./_components/StudentTeacherSelection";
// import { AppRouterInstance } from "next/dist/shared/lib/app-router-context.shared-runtime";
// import { useRouter } from "next/navigation";
// import { GoogleLogin } from "react-google-login";

const authScreens = {
  EMAIL: "EMAIL",
  MOBILE: "MOBILE",
};

export default function LoginPage() {
  const router = useRouter();
  const { isAuthenticated } = useSession();

  const [currentScreen, setCurrentScreen] = useState(authScreens.MOBILE);
  const [selectedUserType, setSelectedUserType] = useState(userTypes.STUDENT);

  const handleLoginViaPasswordClick = () => {
    setCurrentScreen(authScreens.EMAIL);
  };

  const handleLoginViaOTPClick = () => {
    setCurrentScreen(authScreens.MOBILE);
  };

  useEffect(() => {
    if (isAuthenticated) {
      router.push(routes.dashboard);
    }
  }, [isAuthenticated, router]);
  // const responseGoogle = async (response: any) => {
  //   console.log("Google Response", response);

  //   const { tokenId, profileObj } = response;

  //   try {
  //     // Send tokenId to backend for verification
  //     const res = await fetch("/api/google-login", {
  //       method: "POST",
  //       headers: {
  //         "Content-Type": "application/json",
  //       },
  //       body: JSON.stringify({ tokenId }),
  //     });

  //     if (!res.ok) {
  //       throw new Error("Failed to authenticate with Google");
  //     }

  //     // Assuming backend responds with user data upon successful verification
  //     const userData = await res.json();

  //     // Store user data in local storage or session storage
  //     localStorage.setItem("user", JSON.stringify(userData));

  //     // Redirect to dashboard or appropriate page
  //     router.push("/dashboard");
  //   } catch (error: any) {
  //     console.error("Failed to authenticate:", error.message);
  //     // Handle error (e.g., display error message to user)
  //   }
  // };

  return (
    <div className="flex h-screen w-full justify-center overflow-hidden">
      <div className="flex w-full justify-center bg-[#F8F6FF] py-20 shadow-2xl">
        <Image
          loading="lazy"
          src="/images/student.png"
          alt=""
          style={{ width: "494px", height: "494px", marginTop: "10opx" }}
          width={494}
          height={494}
        />
      </div>

      <div className="h-full bg-[#ffffff] w-[552px] min-w-[552px] p-[80px] overflow-y-auto">
        <Image
          loading="lazy"
          src="/images/Logo1.png"
          alt=""
          width={70}
          height={71}
        />
        <p className="py-10 text-[28px] font-semibold">Login</p>

        <StudentTeacherSelection
          value={selectedUserType}
          onChange={setSelectedUserType}
          containerClass="mb-6"
        />

        {currentScreen === authScreens.EMAIL && (
          <LoginWithEmail handleLoginViaOTPClick={handleLoginViaOTPClick} />
        )}

        {currentScreen === authScreens.MOBILE && (
          <LoginWithMobileNumber
            handleLoginViaPasswordClick={handleLoginViaPasswordClick}
          />
        )}

        {/* <p className="mb-3 px-48 text-[16px] text-[#3C4852]">or</p> */}

        {/* <GoogleLogin
              clientId="1089475968055-d4qskot7h49vj9656j9g8lm44l8unhut.apps.googleusercontent.com"
              buttonText="Login with Google"
              onSuccess={responseGoogle}
              onFailure={responseGoogle}
              cookiePolicy={"single_host_origin"}
              className="ml-[95px] "
            /> */}

        <p className="flex justify-center py-5 text-[16px] text-[#3C4852]">
          Don&apos;t have an account?
          <span className="text-[#8B75F3] px-1">
            <Link href={routes.register.student}>Register</Link>
          </span>
        </p>
      </div>
    </div>
  );
}
