import clsx from "clsx";
import Image from "next/image";
import { Dispatch, SetStateAction } from "react";

export const userTypes = {
  STUDENT: "STUDENT",
  TEACHER: "TEACHER",
};

const activeClass = "bg-[#3C4852] text-[white]";

const StudentTeacherSelection = ({
  value,
  containerClass,
  onChange,
}: {
  value: string;
  onChange: Dispatch<SetStateAction<string>>;
  containerClass?: string;
}) => {
  return (
    <div className={clsx("flex justify-between", containerClass)}>
      <button
        className={clsx(
          "h-[53px] w-[100%] max-w-[186px] rounded-xl border border-[#778590] font-normal text-[#778590]",
          { [activeClass]: value === userTypes.STUDENT }
        )}
        onClick={() => {
          onChange(userTypes.STUDENT);
        }}
      >
        <span className="flex justify-center gap-3">
          <Image
            loading="lazy"
            src="/images/Group.png"
            width={25}
            height={25}
            alt=""
            className={value === userTypes.STUDENT ? "brightness-0 invert" : ""}
          />
          Student
        </span>
      </button>

      <button
        className={clsx(
          "h-[53px] w-[100%] max-w-[186px] font-normal text-[#778590] border border-[#778590] rounded-xl",
          { [activeClass]: value === userTypes.TEACHER }
        )}
        onClick={() => {
          onChange(userTypes.TEACHER);
        }}
      >
        <span className="flex justify-center gap-4">
          <Image
            loading="lazy"
            src="/images/Group1.png"
            width={25}
            height={25}
            alt=""
            className={value === userTypes.TEACHER ? "brightness-0 invert" : ""}
          />
          Teacher
        </span>
      </button>
    </div>
  );
};

export default StudentTeacherSelection;
