import Image from "next/image";

const RegisterWithGoogle = () => {
  return (
    <div className="flex-col">
      <div className="flex">
        <p className="ml-5" style={{ marginTop: "-10px" }}>
          or
        </p>
        <p
          className="ml-16 font-semibold"
          style={{ marginTop: "-30px", color: "black" }}
        >
          continue with
        </p>
      </div>
      <div className="flex-col">
        <button
          type="button"
          className="ml-20 mt-3 bg-[#F7F5FE] w-[149px] h-[48px] text-[#101010]  "
          style={{
            border: "1px solid #8B75F3",
            borderRadius: "8px",
            paddingTop: 4,
            paddingLeft: 20,
            marginTop: "-40px",
          }}
        >
          continue
          <Image
            loading="lazy"
            src="/images/Google.png"
            alt=""
            width={25}
            height={25}
            style={{ marginTop: -23, display: "flex" }}
          />
        </button>
      </div>
    </div>
  );
};

export default RegisterWithGoogle;
