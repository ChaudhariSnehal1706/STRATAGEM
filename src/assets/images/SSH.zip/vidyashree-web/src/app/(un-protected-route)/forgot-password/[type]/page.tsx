"use client";

import { Input } from "@/app/components/formFields";
import { OTPField } from "@/app/components/otp";
import { CustomDarkButton } from "@/app/components/ui/button";
import { routes } from "@/constants/routes";
import rhfSetError from "@/functions/rhfSetError";
import useSession from "@/hooks/useSession";
import {
  useForgetPasswordRequestOtpMutation,
  useForgetPasswordVerifyOtpMutation,
  useResetPasswordMutation,
} from "@/store/api/authSlice";
import { yupResolver } from "@hookform/resolvers/yup";
import CancelOutlinedIcon from "@mui/icons-material/CancelOutlined";
import { Box } from "@mui/material";
import Image from "next/image";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { FormProvider, useForm } from "react-hook-form";
import { toast } from "react-toastify";
import * as yup from "yup";

const screens = {
  EMAIL: 0,
  OTP: 1,
  NEW_PASSWORD: 2,
};

const texts = [
  ["Send OTP", "Forgot password"],
  ["Verify", "Forgot password"],
  ["Continue", "Create a New Password"],
];

interface FormData {
  emailOrMobileNumber?: string;
  otp?: string;
  newPassword?: string;
  confirmNewPassword?: string;
}

const schema = yup.object().shape({
  emailOrMobileNumber: yup
    .string()
    .test("emailOrMobileNumber", "Invalid email or mobile format.", (value) => {
      if (!value) return false;
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      const mobileRegex = /^\d{10}$/;
      return emailRegex.test(value) || mobileRegex.test(value);
    }),
  otp: yup.string().optional(),
  newPassword: yup
    .string()
    .min(6, "New password must be at least 6 characters")
    .optional(),
  confirmNewPassword: yup
    .string()
    .oneOf([yup.ref("newPassword")], "Passwords must match")
    .optional(),
});

export default function LoginPage() {
  const router = useRouter();
  const { isAuthenticated } = useSession();

  const [forgetPasswordRequestOtp] = useForgetPasswordRequestOtpMutation();
  const [forgetPasswordVerifyOtp] = useForgetPasswordVerifyOtpMutation();
  const [resetPassword] = useResetPasswordMutation();

  const [currentScreen, setCurrentScreen] = useState(screens.EMAIL);

  const methods = useForm<FormData>({
    resolver: yupResolver(schema),
    defaultValues: {
      emailOrMobileNumber: "",
      otp: "",
    },
    mode: "onSubmit",
  });
  const { handleSubmit, control, setError } = methods;

  const onSubmit = async (data: FormData) => {
    const { emailOrMobileNumber, otp } = data;
    try {
      if (currentScreen === screens.EMAIL) {
        const res: any = await forgetPasswordRequestOtp({
          emailOrMobileNumber,
        });
        if (res?.error?.status === 422) {
          rhfSetError(res.error.data, setError);
        } else {
          toast.success(res?.data?.message);
          setCurrentScreen((preVal) => preVal + 1);
        }
      } else if (currentScreen === screens.OTP) {
        const res: any = await forgetPasswordVerifyOtp({
          emailOrMobileNumber,
          otp,
        });
        if (res?.error?.status === 422) {
          rhfSetError(res.error.data, setError);
        } else {
          toast.success(res?.data?.message);
          setCurrentScreen((preVal) => preVal + 1);
        }
      } else if (currentScreen === screens.NEW_PASSWORD) {
        const res: any = await resetPassword(data);
        if (res?.error?.status === 422) {
          rhfSetError(res.error.data, setError);
        } else {
          toast.success(res?.data?.message);
          router.push(routes.forgotPassword.success);
        }
      }
    } catch (error: any) {
      console.error(error.message);
    }
  };

  useEffect(() => {
    if (isAuthenticated) {
      router.push(routes.dashboard);
    }
  }, [isAuthenticated, router]);

  return (
    <div className="flex h-screen w-full justify-center overflow-hidden ">
      <div className="flex w-full justify-center bg-[#F8F6FF] py-20 shadow-2xl">
        <Image
          loading="lazy"
          src="/images/forget.png"
          alt=""
          style={{ width: "494px", height: "494px", marginTop: "10opx" }}
          width={494}
          height={494}
        />
      </div>
      <div className="relative h-full w-[552px] min-w-[552px] overflow-y-auto bg-[#ffffff] p-[80px]">
        <Link href={routes.login}>
          <CancelOutlinedIcon
            className="absolute right-2.5 top-2.5"
            fontSize="large"
          />
        </Link>

        <Image
          loading="lazy"
          src="/images/Logo1.png"
          alt=""
          width={70}
          height={71}
        />

        <p className="py-10 text-[28px] font-semibold">
          {texts[currentScreen][1]}
        </p>
        <FormProvider {...methods}>
          <form onSubmit={handleSubmit(onSubmit)}>
            <Box display="flex" flexDirection="column" rowGap={5}>
              {currentScreen === screens.EMAIL && (
                <Input
                  name="emailOrMobileNumber"
                  placeholder="Enter here"
                  label="Email or Mobile Number"
                />
              )}

              {currentScreen === screens.OTP && (
                <OTPField<FormData> name="otp" control={control} />
              )}

              {currentScreen === screens.NEW_PASSWORD && (
                <Box display="flex" flexDirection="column" gap="20px">
                  <Input
                    type="password"
                    name="newPassword"
                    placeholder="Enter new password"
                    label="Password"
                    helperText="Minimum 8 character Required"
                  />
                  <Input
                    type="password"
                    name="confirmNewPassword"
                    placeholder="Enter confirm password"
                    label="Confirm New Password"
                  />
                </Box>
              )}

              <CustomDarkButton type="submit">
                {texts[currentScreen][0]}
              </CustomDarkButton>
            </Box>
          </form>
        </FormProvider>
      </div>
    </div>
  );
}
