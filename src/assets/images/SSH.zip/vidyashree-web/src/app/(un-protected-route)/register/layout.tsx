"use client";

import Footer from "@/app/components/footer/footer";
import Header from "@/app/components/header/header";
import { routes } from "@/constants/routes";
import useSession from "@/hooks/useSession";
import clsx from "clsx";
import Image from "next/image";
import { usePathname, useRouter } from "next/navigation";
import React, { ReactNode, useEffect } from "react";

const activeClass = "bg-[#3C4852] text-[white]";

interface RegisterLayoutProps {
  children: ReactNode;
}

const RegisterLayout: React.FC<RegisterLayoutProps> = ({ children }) => {
  const router = useRouter();
  const pathname = usePathname();
  const { isAuthenticated } = useSession();

  const handleStudentClick = () => {
    router.push(routes.register.student);
  };

  const handleTeacherClick = () => {
    router.push(routes.register.teacher);
  };

  const titleText =
    pathname === routes.register.student ? "Student" : "Teacher";

  useEffect(() => {
    if (isAuthenticated) {
      router.push(routes.dashboard);
    }
  }, [isAuthenticated, router]);

  return (
    <div>
      <Header title=" " />

      <div className="mx-auto mb-[50px] mt-[-150px] w-[1125px] rounded-2xl bg-white px-[55px] py-[44px] shadow-2xl">
        <div className="flex w-[787px] flex-col gap-[25px]">
          <p className="flex text-[24px] font-bold text-[#3C4852]">
            Register as
            <span className="ml-2 mr-2 text-[#8B75F3]">{titleText}</span> to
            create an account
          </p>

          <div className="flex gap-4">
            <button
              className={clsx(
                "h-[53px] w-[100%] max-w-[186px] font-normal text-[#778590] border border-[#778590] rounded-xl",
                { [activeClass]: pathname === routes.register.student }
              )}
              onClick={handleStudentClick}
            >
              <span className="flex justify-center gap-4">
                <Image
                  loading="lazy"
                  src="/images/Group.png"
                  alt=""
                  width={25}
                  height={25}
                  className={
                    pathname === routes.register.student
                      ? " brightness-0 invert"
                      : ""
                  }
                />
                Student
              </span>
            </button>

            <button
              className={clsx(
                "h-[53px] w-[100%] max-w-[186px] font-normal text-[#778590] border border-[#778590] rounded-xl",
                { [activeClass]: pathname === routes.register.teacher }
              )}
              onClick={handleTeacherClick}
            >
              <span className="flex justify-center gap-4">
                <Image
                  loading="lazy"
                  src="/images/Group1.png"
                  alt=""
                  width={25}
                  height={25}
                  className={
                    pathname === routes.register.teacher
                      ? " brightness-0 invert"
                      : ""
                  }
                />
                Teacher
              </span>
            </button>
          </div>

          {children}
        </div>
      </div>
      <Footer />
    </div>
  );
};

export default RegisterLayout;
