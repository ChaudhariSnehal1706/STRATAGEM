import { Input } from "@/app/components/formFields";
import { CustomDarkButton } from "@/app/components/ui/button";
import rhfSetError from "@/functions/rhfSetError";
import { useLoginStudentOtpMutation } from "@/store/api/authSlice";
import { yupResolver } from "@hookform/resolvers/yup";
import { Box } from "@mui/material";
import { MuiOtpInput } from "mui-one-time-password-input";
import { useState } from "react";
import { FormProvider, useForm } from "react-hook-form";
import { toast } from "react-toastify";
import styled from "styled-components";
import * as yup from "yup";
import { OtpForm } from "./OtpForm";

const authScreens = {
  MOBILE: "MOBILE",
  OTP: "OTP",
};

interface MobileFormData {
  mobileNumber: string;
}

export interface OtpFormData {
  otp: string;
}

const mobileSchema = yup.object().shape({
  mobileNumber: yup.string().required("Mobile Number is required."),
});

export const otpSchema = yup.object().shape({
  otp: yup.string().required("OTP is required."),
});

const LoginWithMobileNumber = ({
  handleLoginViaPasswordClick,
}: {
  handleLoginViaPasswordClick: () => void;
}) => {
  const [loginStudentOtp, { isLoading }] = useLoginStudentOtpMutation();

  const [currentScreen, setCurrentScreen] = useState(authScreens.MOBILE);

  const mobileForm = useForm<MobileFormData>({
    resolver: yupResolver(mobileSchema),
    defaultValues: {
      mobileNumber: "",
    },
  });

  const handleSendOTP = async (data: MobileFormData) => {
    try {
      const res: any = await loginStudentOtp(data);

      if (res?.error?.status === 422) {
        rhfSetError(res.error.data, mobileForm.setError);
      } else {
        toast.success(res?.data?.message);
        setCurrentScreen(authScreens.OTP);
      }
    } catch (error: any) {
      console.error(error.message);
    }
  };

  const mobileNumber = mobileForm.watch("mobileNumber");

  return (
    <div>
      {currentScreen === authScreens.MOBILE && (
        <FormProvider {...mobileForm}>
          <form onSubmit={mobileForm.handleSubmit(handleSendOTP)}>
            <Box display="flex" flexDirection="column" rowGap={2}>
              <Input
                name="mobileNumber"
                placeholder="Enter here"
                label="Mobile Number"
                fullWidth
              />

              <p
                className="ml-auto cursor-pointer text-base font-semibold text-[#778590]"
                onClick={handleLoginViaPasswordClick}
              >
                Login via password
              </p>
              <CustomDarkButton type="submit" disabled={isLoading}>
                Send OTP
              </CustomDarkButton>
            </Box>
          </form>
        </FormProvider>
      )}

      {currentScreen === authScreens.OTP && (
        <OtpForm
          mobileNumber={mobileNumber}
          handleLoginViaPasswordClick={handleLoginViaPasswordClick}
        />
      )}
    </div>
  );
};

export default LoginWithMobileNumber;
