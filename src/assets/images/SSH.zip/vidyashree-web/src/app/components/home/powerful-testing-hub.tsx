import Image from "next/image";

const testingHubImg =
  "https://res.cloudinary.com/dgivdchdh/image/upload/v1707315971/testing-img_hgphoj.png";

export default function PowerfulTestingHub() {
  return (
    <>
      <div className="series">
        <div>
          <Image
            loading="lazy"
            src={"/icons/class-img.png"}
            className="class-img"
            alt=""
            width={570}
            height={540}
          />
        </div>

        <div className="ser-exam">
          <div className="ser-titel">
            Join Our Versatile Test Series to Excel in Multiple Exams without
            limits.
          </div>
          <div className="ser-text">
            Gain unlimited access to India premier structured online test series
            platform, featuring the most pertinent all India test series.
          </div>
          <div className="ser-premium">
            What you get with Vidhyashree Premium
          </div>
          <div className="ser-type">
            <div className="types">
              <Image
                loading="lazy"
                src={"/icons/medal.png"}
                className="medal-icon"
                alt=""
                width={68}
                height={68}
              />
              <div className="types-text">All India Rank</div>
            </div>
            <div className="types series-type">
              <Image
                loading="lazy"
                src={"/icons/exam-list.png"}
                className="medal-icon"
                width={5}
                height={5}
                alt="exam list"
              />
              <div className="types-text">Latest Exam Patterns</div>
            </div>
          </div>
          <div className="ser-type">
            <div className="types">
              <Image
                loading="lazy"
                src={"/icons/mark.png"}
                className="medal-icon"
                alt=""
                width={68}
                height={68}
              />
              <div className="types-text">In Depth Performance Analysis</div>
            </div>
            <div className="types series-type">
              <Image
                loading="lazy"
                src={"/icons/time.png"}
                className="medal-icon"
                alt=""
                width={68}
                height={68}
              />
              <div className="types-text">Anytime Access</div>
            </div>
          </div>
        </div>
      </div>
      <div className="testing">
        <div className="testing-titel">A Powerful Testing Hub</div>

        <div className="testing-exams">
          <div>
            <Image
              loading="lazy"
              width={600}
              height={600}
              src={testingHubImg}
              className="testing-img"
              alt=""
            />
          </div>
          <div>
            <div className="testing-list">
              <div>
                <Image
                  loading="lazy"
                  src={"/icons/exam-list.png"}
                  className="medal-icon"
                  alt=""
                  width={57}
                  height={57}
                />
                <Image
                  loading="lazy"
                  src={"/icons/state-line.png"}
                  className="state-line"
                  alt=""
                  width={2}
                  height={2}
                />
              </div>
              <div className="test-hub">
                <div className="test-titel">Weekly and monthly tests</div>
                <div className="test-text">
                  Ensure focused revision with weekly tests & worksheets,
                  followed by detailed performance discussion with the mentors
                </div>
              </div>
            </div>
            <div className="testing-list test-list">
              <div>
                <Image
                  loading="lazy"
                  src={"/icons/medal.png"}
                  className="medal-icon"
                  alt=""
                  width={57}
                  height={57}
                />
                <Image
                  loading="lazy"
                  src={"/icons/state-line.png"}
                  className="state-line"
                  alt=""
                  width={2}
                  height={2}
                />
              </div>
              <div className="test-hub">
                <div className="test-titel">All India Rank</div>
                <div className="test-text">
                  Measure where you stand with All India Mock Test & All India
                  Test Series for national level performance benchmarking.
                </div>
              </div>
            </div>
            <div className="testing-list test-list">
              <div>
                <Image
                  loading="lazy"
                  src={"/icons/pepar-icon.png"}
                  className="medal-icon"
                  alt=""
                  width={42}
                  height={43}
                />
              </div>
              <div className="test-hub">
                <div className="test-titel">Previous year Question Paper</div>
                <div className="test-text">
                  Familiarize yourself with exam pattern & measure where you
                  stand by practicing previous year papers and matching your
                  answer with our solutions.
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
