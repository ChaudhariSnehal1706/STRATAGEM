import Image from "next/image";
import "./drawer.css";
export default function Drawer() {
  return (
    <div>
      <input type="checkbox" id="drawer-toggle" name="drawer-toggle" />
      <label htmlFor="drawer-toggle" id="drawer-toggle-label"></label>
      <header className="flex gap-2 text-[34px]">
        {" "}
        <span className="font-bold text">Hello, </span>Lorenzo
        <Image
          loading="lazy"
          src="/images/hello1.png"
          alt=""
          width={39}
          height={38}
        />
      </header>

      <div className="flex justify-end items-center mt-2 mr-6 gap-3 ">
        <div>
          <Image
            loading="lazy"
            src="/images/message.png"
            alt=""
            width={24}
            height={17}
          />
        </div>

        <div>
          <Image
            loading="lazy"
            src="/images/Notification.png"
            alt=""
            width={27}
            height={26}
          />
        </div>

        <div>
          <Image
            loading="lazy"
            src="/images/Ellipse 230.png"
            alt=""
            width={40}
            height={40}
          />
        </div>
      </div>

      <nav id="drawer">
        <div className="ishan">
          <Image
            loading="lazy"
            src="/images/logo.png"
            alt=""
            width={56}
            height={56}
          />
          <p>VidyaShree </p>
        </div>

        <ul>
          <div className="ishan1">
            <Image
              loading="lazy"
              src="/images/home2.png"
              alt=""
              width={20}
              height={24}
            />
            <li>
              <a href="#">Home</a>
            </li>
          </div>

          <div className="ishan1">
            <Image
              loading="lazy"
              src="/images/practice.png"
              alt=""
              width={24}
              height={28}
            />
            <li>
              <a href="#">Practice</a>
            </li>
          </div>

          <div className="ishan1">
            <Image
              loading="lazy"
              src="/images/test1.png"
              alt=""
              width={20}
              height={24}
            />
            <li>
              <a href="#">Live Test</a>
            </li>
          </div>
          <div className="ishan1">
            <Image
              loading="lazy"
              src="/images/wallet1.png"
              alt=""
              width={20}
              height={24}
            />
            <li>
              <a href="/wallet">Wallet</a>
            </li>
          </div>
          <div className="ishan1">
            <Image
              loading="lazy"
              src="/images/earn1.png"
              alt=""
              width={20}
              height={24}
            />
            <li>
              <a href="/Referandearn">Refer and Earn</a>
            </li>
          </div>
          <div className="ishan1">
            <Image
              loading="lazy"
              src="/images/order2.png"
              alt=""
              width={20}
              height={24}
            />
            <li>
              <a href="/order">Order</a>
            </li>
          </div>
          <div className="ishan1">
            <Image
              loading="lazy"
              src="/images/heart.png"
              alt=""
              width={20}
              height={24}
            />
            <li>
              <a href="/wishlist">Wishlist</a>
            </li>
          </div>
          <div className="ishan1">
            <Image
              loading="lazy"
              src="/images/help1.png"
              alt=""
              width={20}
              height={24}
            />
            <li>
              <a href="/help-support">Help Support</a>
            </li>
          </div>
        </ul>
      </nav>
      <div id="page-content">
        {/* <!-- <input type="text" placeholder="Enter your name">
      <input type="text" placeholder="Enter your name"> --> */}
      </div>
    </div>
  );
}
