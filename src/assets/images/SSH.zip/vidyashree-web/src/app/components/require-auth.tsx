import { routes } from "@/constants/routes";
import useSession from "@/hooks/useSession";
import { AppRouterInstance } from "next/dist/shared/lib/app-router-context.shared-runtime";
import { useRouter } from "next/navigation";
import { useEffect } from "react";

const RequireAuth = (WrappedComponent: any) => {
  const AuthComponent = (props: any) => {
    const router: AppRouterInstance = useRouter();
    const { isAuthenticated } = useSession();

    useEffect(() => {
      if (!isAuthenticated) {
        // User is not logged in, redirect to login page
        router.push(routes.login);
      }
    }, [isAuthenticated, router]);

    return <WrappedComponent {...props} />;
  };

  return AuthComponent;
};

export default RequireAuth;
