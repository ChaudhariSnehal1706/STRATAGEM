"use client";
import Image from "next/image";
const logo = require("../../../../public/images/logo.png");
import "./success.css";
import Header from "../header/header";

export default function Success({ buttonText, content, ...props }: any) {
  return (
    <>
      <Header title={""} />
      <div className="success">
        <div className="div">
          <div className="overlap">
            <Image
              loading="lazy"
              className="element"
              alt="Element"
              width="400"
              height="400"
              src="https://res.cloudinary.com/dgivdchdh/image/upload/v1708595256/success_jqihki.png"
            />
          </div>
          <Image
            loading="lazy"
            alt="logo"
            className="logo-instance"
            src="https://res.cloudinary.com/dgivdchdh/image/upload/v1708603228/Logo1_l1jl2o.png"
            width="100"
            height="100"
          />
          <div className="group">
            <div className="overlap-group">
              <p className="text-wrapper">{buttonText}</p>
            </div>
          </div>
          <p className="congratulations-your">&#34;{content} 🎉&#34;</p>
        </div>
      </div>
    </>
  );
}
