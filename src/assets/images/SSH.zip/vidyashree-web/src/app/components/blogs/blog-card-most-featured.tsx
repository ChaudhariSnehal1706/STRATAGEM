import Link from "next/link";
import * as cheerio from "cheerio";
import Image from "next/image";
export default function BlogCardMostFeatured({
  author,
  date,
  labels,
  title,
  description,
  firstButtonLabel,
  secondButtonLabel,
  thirdButtonLabel,
  imgSrc,
  href,
}: any) {
  const $ = cheerio.load(description, { xmlMode: true });
  return (
    <div className="w-[592px] h-[240px] mt-12">
      <Link href={href}>
        <div>
          <Image loading="lazy" src={imgSrc} alt="" width={592} height={240} />
          <p className="text-[#6941C6] mt-4">
            {author} • {date}
          </p>
          <p className="font-semibold">{title}</p>
          <p
            className="text-[#667085] text-[16px]"
            style={{
              maxHeight: 45,
              minHeight: 45,
              overflow: "hidden",
              textOverflow: "ellipsis",
            }}
          >
            {$.text()}
          </p>
          <div className="flex mt-5 gap-4">
            {labels.map((label: any) => {
              return (
                <span
                  key={`label-${Math.random() * 1000}`}
                  className="capitalize inline-block bg-red-200 rounded-full px-3 py-1 text-sm font-semibold text-gray-700 mr-2"
                >
                  {label}
                </span>
              );
            })}
          </div>
        </div>
      </Link>
    </div>
  );
}
