import Link from "next/link";
import Classes from "../classes/classes";
import Exams from "../exams/exams";

export default function HomeExamsSection(props: any) {
  const { subCategories, subjects, selectedSubCategory, onSelectSubcategory } =
    props;
  // console.log(onChange)
  return (
    <>
      <div className="exam-titel">Select your Exams to Get Started</div>
      {selectedSubCategory ? (
        <Classes
          data={subCategories}
          selectedSubCategory={selectedSubCategory}
          onSelectSubcategory={onSelectSubcategory}
        />
      ) : null}
      <Exams data={subjects} />
      <div className="all-exam">
        <Link href="/exams" style={{ border: 1, textAlign: "center" }}>
          See all exams
        </Link>
      </div>
    </>
  );
}
