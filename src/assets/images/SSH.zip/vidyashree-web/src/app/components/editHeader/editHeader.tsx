import Image from "next/image";
import React, { useState } from "react";
export default function EditHeader() {
  return (
    // <div className="flex gap-2 items-center px-28 justify-end py-10" style={{borderBottom:"1px solid #EEF1F4"}} >
    //     <p className="text-[32px] font-semibold text-[#3C4852]"  >Edit Profile</p>
    //    <div className='flex items-center fixed '>
    //     <Image loading='lazy' src='/images/message.png'width={31} height={26}></Image>
    //      <Image loading='lazy' src='/images/Notification.png'width={27} height={26}></Image>
    //      <Image loading='lazy' src='/images/Ellipse 230.png'width={40} height={40}></Image>
    //      </div>
    //      </div>

    <div
      className="flex justify-between items-center fixed py-3.5"
      style={{ borderBottom: "1px solid #EEF1F4" }}
    >
      <Image
        loading="lazy"
        src="/images/Justify.png"
        width={31}
        alt=""
        height={26}
        style={{ marginLeft: 50 }}
      ></Image>

      <p
        className="text-[32px] font-semibold text-[#3C4852]"
        style={{ marginRight: 720 }}
      >
        Edit Profile
      </p>

      <div className="flex gap-2 items-center px-28">
        <Image
          alt=""
          loading="lazy"
          src="/images/message.png"
          width={31}
          height={26}
        ></Image>
        <Image
          loading="lazy"
          src="/images/Notification.png"
          width={27}
          height={26}
          alt=""
        ></Image>
        <Image
          loading="lazy"
          src="/images/Ellipse 230.png"
          width={40}
          height={40}
          alt=""
        ></Image>
      </div>
    </div>
  );
}
