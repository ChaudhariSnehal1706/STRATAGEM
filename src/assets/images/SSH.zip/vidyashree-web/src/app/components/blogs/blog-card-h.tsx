import * as cheerio from "cheerio";
import Image from "next/image";
import Link from "next/link";
export default function BlogCardH({
  labels,
  author,
  date,
  title,
  description,
  firstButtonLabel,
  secondButtonLabel,
  imgsrc,
  href,
}: any) {
  const $ = cheerio.load(description, { xmlMode: true });
  return (
    <Link href={href}>
      <div className="mt-20 flex justify-center ">
        <div className="mt-56 w-[1212px] h-[246px] flex gap-5 ">
          <Image loading="lazy" src={imgsrc} alt="" width={100} height={100} />
          <div>
            <p className="text-[#6941C6] ">
              {author} • {date}
            </p>
            <p className="font-semibold">{title}</p>
            <p className="mt-4 text-[16px]">{$.text()}</p>
            <div className="gap-7 flex mt-3">
              {labels.map((label: any) => {
                return (
                  <span
                    key={`label-${Math.random() * 1000}`}
                    className="capitalize inline-block bg-red-200 rounded-full px-3 py-1 text-sm font-semibold text-gray-700 mr-2"
                  >
                    {label}
                  </span>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </Link>
  );
}
