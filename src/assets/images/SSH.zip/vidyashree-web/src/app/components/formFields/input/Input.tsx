import {
  Box,
  FormHelperText,
  InputLabel,
  OutlinedInput,
  OutlinedInputProps,
} from "@mui/material";
import { useState } from "react";
import { useFormContext } from "react-hook-form";

export interface InputProps extends OutlinedInputProps {
  name: string;
  label?: string;
  type?: string;
  placeholder?: string;
  helperText?: string;
  autoPlaceholder?: boolean;
}

export const Input = ({
  name,
  label,
  type,
  placeholder,
  autoPlaceholder,
  helperText,
  ...rest
}: InputProps) => {
  const { register, getFieldState } = useFormContext();
  const [placeholder_, setPlaceholder] = useState<string>(placeholder || "");

  const { error } = getFieldState(name);

  if (autoPlaceholder && label && !placeholder) {
    setPlaceholder(`Enter ${label}`);
  }

  return (
    <Box display="flex" flexDirection="column" rowGap={1}>
      {!!label && <InputLabel htmlFor={name}>{label}</InputLabel>}

      <div className="w-full">
        <OutlinedInput
          {...register(name)}
          id={name}
          type={type || "text"}
          size="medium"
          error={!!error}
          placeholder={placeholder_}
          style={{ width: "100%" }}
          {...rest}
        />
        {helperText ? <FormHelperText>{helperText}</FormHelperText> : null}
        {error ? <FormHelperText error>{error?.message}</FormHelperText> : null}
      </div>
    </Box>
  );
};
