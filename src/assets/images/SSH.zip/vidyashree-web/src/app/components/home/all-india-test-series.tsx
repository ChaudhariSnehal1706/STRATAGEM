import Image from "next/image";
import Classes from "../classes/classes";
import Testes from "../tests/testes";
import { useState } from "react";

export default function AllIndiaTestSeries(props: any) {
  const {
    subCategories,
    testseries,
    selectedSubCategory,
    onSelectSubcategory,
  } = props;

  return (
    <>
      <div>
        <div className="main-titel">
          <Image
            loading="lazy"
            src={"/images/all_india_live.png"}
            alt="All India Live Test Series"
            width={519}
            height={82}
          />
        </div>
      </div>

      {selectedSubCategory ? (
        <Classes
          data={subCategories}
          selectedSubCategory={selectedSubCategory}
          onSelectSubcategory={onSelectSubcategory}
        />
      ) : null}
      <Testes title="Featured Test" testseries={testseries} />
    </>
  );
}
