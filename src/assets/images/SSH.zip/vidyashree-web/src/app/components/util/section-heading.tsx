"use client";

import styled from "styled-components";

function SectionHeading(props: any) {
  const { title, children } = props;
  return (
    <Div>
      {title}
      <P>{children}</P>
    </Div>
  );
}

const Div = styled.div`
  box-sizing: border-box;
  margin: 70px 120px 20px 120px;
  color: var(--darkbluegrey, #3c4852);
  text-align: left;

  font-size: 36px;
  line-height: 24px;
  font-weight: 600;
  position: relative;
`;

const P = styled.p`
  color: var(--grey-text, #778590);
  text-align: left;
  font-size: 18px;
  line-height: 30px;
  margin-top: 30px;
  font-weight: 400;
  position: relative;
  width: 100%;
  height: 100%;
`;
export default SectionHeading;
