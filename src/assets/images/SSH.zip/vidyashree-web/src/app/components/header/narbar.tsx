import Image from "next/image";
import Link from "next/link";
import { useState } from "react";

const Navbar = () => {
  const [isSubMenuOpen, setIsSubMenuOpen] = useState(false);

  const toggleSubMenu = () => {
    setIsSubMenuOpen(!isSubMenuOpen);
  };

  return (
    <nav className="py-4">
      <div className="container mx-auto flex flex-col md:flex-row items-center justify-between">
        <div className="flex items-center">
          <Link href="/" className="text-white text-lg font-semibold mr-4">
            <Image
              loading="lazy"
              src={"/icons/logo.png"}
              className="logo-icon"
              alt=""
              width={168}
              height={168}
            />
          </Link>
          <ul className="flex space-x-4">
            <li className="font-bold min-w-[10vw]">
              <Link href="/" className="text-white hover:text-gray-300 m-5">
                Home
              </Link>
            </li>
            <li className="font-bold min-w-[10vw]">
              <div
                className="relative min-w-[10vw]"
                onMouseEnter={() => setIsSubMenuOpen(true)}
                onMouseLeave={() => setIsSubMenuOpen(false)}
              >
                <a
                  className="text-white hover:text-gray-300 cursor-pointer "
                  onClick={toggleSubMenu}
                >
                  Exams
                </a>
                {isSubMenuOpen && (
                  <ul className="absolute top-full left-0 bg-gray-800 mt-1 p-2">
                    <li>
                      <Link
                        href="/exam1"
                        className="text-white hover:text-gray-300"
                      >
                        Exam 1
                      </Link>
                    </li>
                    <li>
                      <Link
                        href="/exam2"
                        className="text-white hover:text-gray-300"
                      >
                        Exam 2
                      </Link>
                    </li>
                  </ul>
                )}
              </div>
            </li>
            <li className="font-bold min-w-[10vw]">
              <Link href="/about" className="text-white hover:text-gray-300">
                About
              </Link>
            </li>
            <li className="font-bold min-w-[10vw]">
              <Link href="/services" className="text-white hover:text-gray-300">
                Services
              </Link>
            </li>
            <li className="font-bold min-w-[10vw]">
              <Link href="/contact" className="text-white hover:text-gray-300">
                Contact
              </Link>
            </li>
          </ul>
        </div>
        <div className="flex  justify-end md:mt-0 mt-4  min-w-[20vw]">
          <Link
            className="hover:text-gray-300 md:mx-4 login-btn"
            href={"/login"}
          >
            Login/ Signup
          </Link>
          <div className="lang con-img">
            <Image
              loading="lazy"
              src={"/icons/ind.png"}
              className="ind-icon"
              alt="India Flag"
              width={68}
              height={68}
            />
            <span>ENG</span>
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
