"use client";
import "./sidebar.css";

export default function Sidebar({ steps = [], active = 0 }: any) {
  return (
    <div className="relative p-10">
      <div className="progress">
        {steps?.map((step: any, index: any) => {
          console.log();
          const done = index <= active ? "done" : "notdone";

          return (
            <div key={index} className={"step " + done}>
              {steps?.length === index + 1 ? null : (
                <div className="step-progress"></div>
              )}

              <div className="icon-wrapper">
                <svg className="icon icon-checkmark" viewBox="0 0 32 32">
                  <path
                    className="path1"
                    d="M27 4l-15 15-7-7-5 5 12 12 20-20z"
                  ></path>{" "}
                </svg>
                <div className="step-text">{step} </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
