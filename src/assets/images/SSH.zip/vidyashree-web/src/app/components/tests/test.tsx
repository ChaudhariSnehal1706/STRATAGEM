import Image from "next/image";

import "./innerTest/page";
import Link from "next/link";
import util from "@/functions/util";

const Test = ({ containerClassName, test }: any) => {
  return (
    <div className={"test " + containerClassName}>
      <Image
        loading="lazy"
        src={`${"http://3.109.118.195:3000"}/uploads/${test.banner_url}`}
        className="test-img"
        alt=""
        width={200}
        height={200}
      />
      <div className="students">
        <Image
          loading="lazy"
          src={"/icons/student.png"}
          className="student-img"
          alt=""
          width={100}
          height={100}
        />
        <div className="connect-student">
          {Math.ceil(Math.random() * 10000)} Students
        </div>
      </div>
      <div className="class-live">{test.name}</div>
      <div className="pepar-time">
        {test.noOfQuestions} questions l {test.durationMinutes} Minutes l{" "}
        {test.maxMarks} Marks
      </div>
      <div className="pepar-time">
        {util.formatDate(test.scheduleStartTime)} to{" "}
        {util.formatDate(test.scheduleEndTime)}
      </div>
      <Link href="/components/tests/innerTest">
        <button className="test-btn">View Test Series</button>
      </Link>
    </div>
  );
};

export default Test;
