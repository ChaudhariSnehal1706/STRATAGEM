import React, { FC } from "react";
interface ReusableCardProps {
  title: string;
  width?: string;
  height?: string;
  marginLeft?: string;
  shadow?: string;
  borderBottomColor?: string;
  contentColor?: string;
  fontSize?: string;
  fontWeight?: string;
  padding?: string;
}

const ReusableCard: FC<ReusableCardProps> = ({
  title,
  width = "213px",
  height = "82px",
  marginLeft = "",
  shadow = "2xl",
  borderBottomColor = "#8B75F3",
  contentColor = "#3C4852",
  fontSize = "18px",
  fontWeight = "medium",
}) => {
  const cardStyle = {
    width,
    height,
    marginLeft,
    boxShadow: shadow,
    borderRadius: "rounded-2xl",
    borderBottom: `2px solid ${borderBottomColor}`,
    paddingLeft: "70px",
    paddingTop: "30px",
  };

  const contentStyle = {
    padding: "20px",
    marginTop: "3px",
    color: contentColor,
    fontSize,
    fontWeight,
  };

  return (
    <div
      className={`w-${cardStyle.width} h-${cardStyle.height} shadow-${cardStyle.boxShadow} ml-${cardStyle.marginLeft} ${cardStyle.borderRadius}`}
      style={cardStyle}
    >
      <p
        className={`px-${contentStyle.padding} py-${contentStyle.padding} mt-${contentStyle.marginTop} text-${contentStyle.color} text-${contentStyle.fontSize} font-${contentStyle.fontWeight}`}
      >
        {title}
      </p>
    </div>
  );
};

export default ReusableCard;
