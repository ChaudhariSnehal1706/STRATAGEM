import Exam from "./exam";

const Exams = ({ data = [] }) => {
  return (
    <div className="exams">
      <div className="exam-list">
        {data?.map((item: any) => <Exam key={`E-${item._id}`} data={item} />)}
      </div>
    </div>
  );
};
export default Exams;
