import Image from "next/image";
import { useState } from "react";
import Carousel from "react-multi-carousel";
import "./testimonial.css";
import "react-multi-carousel/lib/styles.css";
export default function Testimonials(props: any) {
  const { testimonals } = props;
  const [selectedTestimonal, setSeletedTestimonal] = useState(0);
  const responsive = {
    superLargeDesktop: {
      breakpoint: { max: 4000, min: 3000 },
      items: 5,
      slidesToSlide: 3,
    },
    desktop: {
      breakpoint: { max: 3000, min: 1024 },
      items: 4,
      slidesToSlide: 2,
    },
    tablet: {
      breakpoint: { max: 1024, min: 464 },
      items: 2,
      slidesToSlide: 2,
    },
    mobile: {
      breakpoint: { max: 464, min: 0 },
      items: 1,
      slidesToSlide: 1,
    },
  };
  const handleTestimonialClick = (index: number) => {
    setSeletedTestimonal(index);
  };
  return (
    <>
      <div>
        <div
          style={{ backgroundImage: `url('/images/test-bgImg.png')` }}
          className="test-bg-img"
        >
          <div className="test-heding">Testimonial</div>

          <div className="testimonial-list">
            <div className="testimonial">
              <div className="videos">
                <Image
                  alt=""
                  loading="lazy"
                  src={testimonals[selectedTestimonal]?.mediaUrl}
                  className="testimg"
                  width={300}
                  height={300}
                />
                {testimonals[selectedTestimonal]?.mediaType === "Video" && (
                  <Image
                    loading="lazy"
                    src={"/icons/play.png"}
                    className="play-icon"
                    alt="Video Play"
                    width={68}
                    height={68}
                  />
                )}
              </div>
              <div className="testimonial-text">
                <h4>{testimonals[selectedTestimonal]?.name}</h4>
                <h5>{testimonals[selectedTestimonal]?.position}</h5>
                <h6>{testimonals[selectedTestimonal]?.textContent}</h6>
              </div>
            </div>
          </div>

          <div className="test-series">
            <div className="user-video">
              <Carousel
                swipeable={false}
                draggable={false}
                showDots={false}
                responsive={responsive}
                ssr={false} // means to render carousel on server-side.
                infinite={true}
                autoPlay={false}
                autoPlaySpeed={1000}
                keyBoardControl={true}
                customTransition="all .5"
                transitionDuration={500}
                containerClass="carousel-container-1"
                removeArrowOnDeviceType={["tablet", "mobile"]}
                renderArrowsWhenDisabled={true}
                dotListClass="custom-dot-list-style"
                itemClass="carousel-item-padding-5-px"
              >
                {testimonals.map((item: any, index: number) => (
                  <div
                    className="test-video"
                    key={item._id}
                    onClick={() => handleTestimonialClick(index)}
                  >
                    <Image
                      alt=""
                      loading="lazy"
                      src={item.mediaUrl}
                      className="video-img"
                      width={68}
                      height={68}
                    />
                    {item.mediaType === "Video" && (
                      <Image
                        loading="lazy"
                        src={"/icons/play.png"}
                        className="play-icon"
                        alt="Video Player Icon"
                        width={68}
                        height={68}
                      />
                    )}
                  </div>
                ))}
              </Carousel>
            </div>
          </div>
        </div>
      </div>

      <div className="heding">
        <Image
          loading="lazy"
          src={`/icons/text.png`}
          className="text-icon"
          alt=""
          width={518}
          height={140}
        />
      </div>
    </>
  );
}
