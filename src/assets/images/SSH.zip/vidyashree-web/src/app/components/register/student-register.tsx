import Image from "next/image";
import Sidebar from "./../sidebar/sidebar";
import { useState } from "react";
import axios from "axios";
import Link from "next/link";
import TeacherRegisterComponent from "./teacher-register";
export default function StudentRegisterComponent() {
  const [showTeacherForm, setShowTeacherForm] = useState(false);

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [mobile_number, setMobileNumber] = useState("");
  const [name, setName] = useState("");

  const handleSignup = async () => {
    try {
      const response = await axios.post("http://localhost:3000/api/v1/users", {
        email,
        password,
        name,
        mobile_number,
      });
      console.log(response.data);
    } catch (error: any) {
      console.error(error.message);
    }
  };
  return (
    <div
      style={{
        display: "flex",
        justifyContent: "center",
        marginTop: "-150px",
      }}
    >
      <div
        className="w-[1125px] h-[979px] bg-white flex-3 font-bold  shadow-2xl "
        style={{ borderRadius: 20 }}
      >
        {showTeacherForm ? ( // Conditional rendering based on showTeacherForm state
          <TeacherRegisterComponent />
        ) : (
          <>
            <p className="text-[#3C4852] text-[24px] ml-10 mt-10 flex ">
              {" "}
              Register as{" "}
              <span className="text-[#8B75F3] ml-2 mr-2">Student</span> to
              create an account{" "}
            </p>
            <div className=" flex gap-4">
              <button
                className="mt-5 ml-10 bg-[#3C4852] w-[100%] max-w-[186px] h-[53px] text-[white] font-normal  "
                style={{ borderRadius: "12px", paddingTop: 4, paddingLeft: 20 }}
              >
                Student{" "}
                <Image
                  loading="lazy"
                  src="/images/Group.png"
                  alt=""
                  width={25}
                  height={25}
                  style={{ marginTop: -25, marginLeft: 18, display: "flex" }}
                />
              </button>
              <button
                className="mt-5   w-[186px] h-[53px] text-[#778590] font-normal  "
                style={{
                  border: "1px solid #778590",
                  borderRadius: "12px",
                  paddingTop: 4,
                  paddingLeft: 20,
                }}
                onClick={() => setShowTeacherForm(true)}
              >
                Teacher{" "}
                <Image
                  loading="lazy"
                  src="/images/Group1.png"
                  alt=""
                  width={25}
                  height={25}
                  style={{ marginTop: -25, marginLeft: 18, display: "flex" }}
                />
              </button>
            </div>
            <div>
              <p className="ml-10 , mt-10 text-[#3C4852] font-medium">
                {" "}
                Full Name
              </p>
            </div>

            <div className="ml-10 mt-5 text-grey font-normal">
              <input
                type="text "
                placeholder="What is your name?"
                style={{
                  border: "1px solid #C7C7C2",
                  borderRadius: "8px",
                  width: "100%",
                  height: "48px",
                  paddingLeft: "14px",
                  marginLeft: "20",
                  maxWidth: "787px",
                }}
                onChange={(event) => {
                  setName(event.target.value);
                }}
              />
            </div>
            <div>
              <p className="text-[#3C4852] font-medium ml-10 mt-5 flex">
                {" "}
                Email ID
              </p>
              <div className="ml-10 mt-5 text-grey font-normal flex">
                <input
                  type="text "
                  placeholder="Tell us your email ID"
                  onChange={(event) => {
                    setEmail(event.target.value);
                  }}
                  style={{
                    border: "1px solid #C7C7C2",
                    borderRadius: "8px",
                    width: "787px",
                    height: "48px",
                    paddingLeft: "14px",
                    marginLeft: "20",
                  }}
                />

                <div className="flex-col">
                  {/* <div style={{border:'2px solid black', marginLeft:10}}>vl</div> */}
                  {/* <vl style={{border:'2px solid black', marginLeft:'20px', marginTop:'-30px'}} ></vl> */}
                  <div className="flex">
                    <p className="ml-5" style={{ marginTop: "-10px" }}>
                      or
                    </p>
                    <p
                      className="ml-16 font-semibold"
                      style={{ marginTop: "-30px", color: "black" }}
                    >
                      {" "}
                      continue with
                    </p>
                  </div>
                  <div className="flex-col">
                    <button
                      className="ml-20 mt-3 bg-[#F7F5FE] w-[149px] h-[48px] text-[#101010]  "
                      style={{
                        border: "1px solid #8B75F3",
                        borderRadius: "8px",
                        paddingTop: 4,
                        paddingLeft: 20,
                        marginTop: "-40px",
                      }}
                    >
                      continue{" "}
                      <Image
                        loading="lazy"
                        src="/images/Google.png"
                        alt=""
                        width={25}
                        height={25}
                        style={{ marginTop: -23, display: "flex" }}
                      />
                    </button>
                  </div>
                </div>
              </div>
              <div>
                <p className="text-[#3C4852] font-medium ml-10 mt-5 flex">
                  {" "}
                  Mobile Number{" "}
                  <span className="text-[#778590] text-[14px] ">
                    {" "}
                    (Required)
                  </span>
                </p>
                <div className="ml-10 mt-5 text-grey font-normal">
                  <input
                    type="text "
                    placeholder="+91 Mobile Number"
                    style={{
                      border: "1px solid #C7C7C2",
                      borderRadius: "8px",
                      width: "787px",
                      height: "48px",
                      paddingLeft: "14px",
                      marginLeft: "20",
                    }}
                    onChange={(event) => {
                      setMobileNumber(event.target.value);
                    }}
                  />
                </div>
              </div>
              <div>
                <p className="text-[#3C4852] font-medium ml-10 mt-5">
                  {" "}
                  Password
                </p>
                <div className="ml-10 mt-5 text-grey font-normal">
                  <input
                    type="text "
                    placeholder="Create a password for your account"
                    onChange={(event) => {
                      setPassword(event.target.value);
                    }}
                    style={{
                      border: "1px solid #C7C7C2",
                      borderRadius: "8px",
                      width: "787px",
                      height: "48px",
                      paddingLeft: "14px",
                      marginLeft: "20",
                    }}
                  />
                  <p className="text-[#778590] text-[13px] ml-1">
                    Minimum 8 characater Required
                  </p>
                </div>
              </div>
            </div>
            <div className="ml-10 mt-5 text-grey font-normal">
              <p> Add Category</p>
              <div className="ml-1 mt-5 text-grey font-normal flex gap-8">
                <input
                  type="text "
                  placeholder="Select your Category"
                  style={{
                    border: "1px solid #C7C7C2",
                    borderRadius: "8px",
                    width: "376px",
                    height: "54px",
                    paddingLeft: "14px",
                    marginLeft: "20",
                  }}
                />
                <input
                  type="text "
                  placeholder="Select multiple subject"
                  style={{
                    border: "1px solid #C7C7C2",
                    borderRadius: "8px",
                    width: "376px",
                    height: "54px",
                    paddingLeft: "14px",
                    marginLeft: "20",
                  }}
                />
              </div>
              <p className="text-grey mt-5 ml-2 flex">
                By clicking Register, you agree to the{" "}
                <span className="text-[#8B75F3] ml-1 mr-1">
                  {" "}
                  Terms and Condition{" "}
                </span>{" "}
                &{" "}
                <span className="text-[#8B75F3] ml-1 mr-1">
                  {" "}
                  Privacy Policy
                </span>{" "}
                of VidhyaShree
              </p>
            </div>
            <div>
              <Link href="/student-register-success">
                <button
                  onClick={handleSignup}
                  className="ml-12 mt-5 bg-[#8B75F3] text-white w-[167px] h-[46px] rounded-lg font-semibold"
                >
                  Register Now
                </button>
              </Link>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
