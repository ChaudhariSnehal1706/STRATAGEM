import { FormHelperText, styled } from "@mui/material";
import { MuiOtpInput } from "mui-one-time-password-input";
import { Control, Controller, FieldValues, Path } from "react-hook-form";

const MuiOtpInputStyled = styled(MuiOtpInput)`
  .MuiOutlinedInput-root {
    background-color: #fbfbfb;
    height: 54px;
    width: 54px;
  }
`;

export const OTP = ({ error, ...rest }: { error: string }) => {
  return (
    <div>
      <p className="font-semibold mb-3">OTP</p>
      <MuiOtpInputStyled {...rest} length={6} autoFocus />
      {error ? <FormHelperText error>{String(error)}</FormHelperText> : null}
    </div>
  );
};

interface OTPFieldProps<T extends FieldValues> {
  name: string;
  control: Control<T>;
}

export const OTPField = <T extends Record<string, any>>({
  name,
  control,
}: OTPFieldProps<T>) => {
  return (
    <Controller
      name={name as Path<T>}
      control={control}
      rules={{ validate: (value) => value.length === 6 }}
      render={({ field, fieldState: { error } }) => {
        return (
          <div>
            <p className="font-semibold mb-3">OTP</p>
            <MuiOtpInputStyled {...field} length={6} autoFocus />
            {error ? (
              <FormHelperText error>{String(error?.message)}</FormHelperText>
            ) : null}
          </div>
        );
      }}
    />
  );
};
