import Image from "next/image";
import Faculties from "./faculties";
import "./facultyCarousel.css";
const FacultyCarousel = (props: any) => {
  const { title } = props;
  return (
    <div>
      <div className="faculty">
        <div className="faculty-title">{title}</div>
        <div className="faculties">
          <Image
            loading="lazy"
            src={"/icons/right-icon.png"}
            className="faculty-icon"
            alt=""
            width={84}
            height={84}
          />
          <div className="faculty-list">
            {Array(10)
              .fill("Dummy")
              .map(() => (
                <Faculties
                  imageSrc={"/images/teacher.png"}
                  facultyName="Chris"
                  key={1}
                />
              ))}
          </div>
          <Image
            loading="lazy"
            src={"/icons/left-icon.png"}
            className="faculty-icon"
            alt=""
            width={84}
            height={84}
          />
        </div>
      </div>
    </div>
  );
};

export default FacultyCarousel;
