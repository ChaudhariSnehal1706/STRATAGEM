import Image from "next/image";

export default function HowToRegister() {
  return (
    <div className="register">
      <div className="register-titel">How To Register</div>
      <div className="register-pro">
        <div className="register-ver">
          <Image
            loading="lazy"
            src={"/icons/mobile.png"}
            className="mobail-icon"
            alt="verify mobile"
            width={68}
            height={68}
          />
          <div className="reg-text">Verify Mobile/ Email</div>
          <div className="ver-text">
            Enter your number/ Email to receive OTP
          </div>
        </div>
        <Image
          loading="lazy"
          src={"/icons/line-down.png"}
          className="lineDown-icon"
          alt=""
          width={68}
          height={68}
        />
        <div className="register-ver successful-ver">
          <Image
            loading="lazy"
            src={"/icons/details.png"}
            className="mobail-icon"
            alt="mobile icon"
            width={68}
            height={68}
          />
          <div className="reg-text">Submit your Details</div>
          <div className="ver-text">Fill the required Details</div>
        </div>
        <Image
          loading="lazy"
          src={"/icons/line-up.png"}
          className="lineUp-icon"
          alt="lineup icon"
          width={68}
          height={68}
        />
        <div className="register-ver successful-ver">
          <Image
            loading="lazy"
            src={"/icons/successful.png"}
            className="mobail-icon"
            alt="registration icon"
            width={68}
            height={68}
          />
          <div className="reg-text">Registration Successful</div>
          <div className="ver-text">Get Access of Dashboard</div>
        </div>
      </div>
    </div>
  );
}
