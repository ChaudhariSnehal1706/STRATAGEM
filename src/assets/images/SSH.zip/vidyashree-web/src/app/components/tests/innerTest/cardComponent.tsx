import React from "react";
import "./page.css";
import SubHeading from "../../util/sub-heading";
import List from "../../util/list";
import Image from "next/image";
const ImageWithText = (props: any) => {
  const { text2, text, text3, text4, imageUrl, button1, button2 } = props;
  return (
    <div className="image-with-text-container">
      <div className="image-container">
        <Image
          loading="lazy"
          src={imageUrl}
          alt="Image"
          width={100}
          height={100}
        />
      </div>
      <div className="text-container">
        <SubHeading title={text} />
        <div style={{ display: "flex" }}>
          <p>{text2}</p>
          <p>{text3}</p>
        </div>
        <p className="paragraph">{text4}</p>
        <button className="card-button bg-white hover:bg-gray-100 text-gray-800 font-semibold py-2 px-4 border border-gray-400 rounded shadow">
          {button1}
        </button>
        <button className="card-button bg-white hover:bg-gray-100 text-gray-800 font-semibold py-2 px-4 border border-gray-400 rounded shadow">
          {button2}
        </button>
      </div>
    </div>
  );
};

export default ImageWithText;
