import "./verticalSidebar.css";
export default function VerticalSidebar({ activestep = 0, arr = [] }: any) {
  return (
    <div>
      <ul className="py-12 px-7" id="progress ">
        {arr?.map((step: any, index: any) => {
          const active = index <= activestep ? "green" : "grey";
          const bold = index === activestep ? "font-bold" : " ";
          return (
            <>
              <li>
                <span className="h-[30px] flex gap-4 items-center justify-end">
                  <p className={"w-[200px] " + bold}>{step}</p>
                  <div className={"node " + active}></div>
                </span>
              </li>
              {arr?.length === index + 1 ? null : (
                <li>
                  <span className="flex justify-end">
                    <div className={"divider " + active}></div>
                  </span>
                </li>
              )}
            </>
          );
        })}
      </ul>
    </div>
  );
}

// import React, { useState } from 'react';
// import './verticalSidebar.css';

// export default function VerticalSidebar({ activestep = 0, arr = [] }) {
//   const [isSidebarOpen, setIsSidebarOpen] = useState(true);

//   const handleToggleSidebar = () => {
//     setIsSidebarOpen((prevIsSidebarOpen) => !prevIsSidebarOpen);
//   };

//   return (
//     <div>
//       <button onClick={handleToggleSidebar}>
//         {isSidebarOpen ? 'Close Sidebar' : 'Open Sidebar'}
//       </button>

//       {isSidebarOpen && (
//         <ul className="py-12 px-7" id="progress">
//           {arr?.map((step, index) => {
//             const active = index <= activestep ? 'green' : 'grey';
//             const bold = index === activestep ? 'font-bold' : ' ';
//             return (
//               <>
//                 <li>
//                   <span className="h-[30px] flex gap-4 items-center justify-end">
//                     <p className={'w-[200px] ' + bold}>{step}</p>
//                     <div className={'node ' + active}></div>
//                   </span>
//                 </li>
//                 {arr?.length === index + 1 ? null : (
//                   <li>
//                     <span className="flex justify-end">
//                       <div className={'divider ' + active}></div>
//                     </span>
//                   </li>
//                 )}
//               </>
//             );
//           })}
//         </ul>
//       )}
//     </div>
//   );
// }
