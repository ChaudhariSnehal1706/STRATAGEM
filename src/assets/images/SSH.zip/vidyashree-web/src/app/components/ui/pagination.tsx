import Image from "next/image";
import Link from "next/link";

interface PaginationProps {
  currentPage: number;
  totalPages: number;
  handleClick: any;
}

const Pagination: React.FC<PaginationProps> = ({
  currentPage,
  totalPages,
  handleClick,
}) => {
  const isFirstPage = false; //currentPage === 1
  const isLastPage = false; //currentPage === totalPages

  return (
    <div className="pagination flex items-center p-4">
      {!isFirstPage && (
        <div className="flex items-center justify-center gap-3">
          <div className=" ">
            <Image
              loading="lazy"
              src="/images/arrow.png"
              alt=""
              width={25}
              height={25}
            />
          </div>
          <button
            style={{ padding: 10, border: 1, fontSize: 14 }}
            key={`previousbtn`}
            onClick={() => {
              if (currentPage < 1) {
                handleClick(1);
              } else {
                handleClick(currentPage - 1);
              }
            }}
          >
            {" "}
            Previous
          </button>
        </div>
      )}
      <div>
        {Array.from({ length: totalPages }, (_, index) => (
          <button
            style={{ padding: 10, border: 1, fontSize: 14 }}
            key={index + 1}
            onClick={() => {
              handleClick(index + 1);
            }}
          >
            {/* < className={currentPage === index + 1 ? 'active' : ''}> */}
            {index + 1}
            {/* </a> */}
          </button>
        ))}
      </div>

      {!isLastPage && (
        <div className="flex items-center justify-center gap-3">
          <button
            style={{ padding: 10, border: 1, fontSize: 14 }}
            key={`nextbtn`}
            onClick={() => {
              if (currentPage > totalPages) {
                handleClick(totalPages);
              } else {
                handleClick(currentPage + 1);
              }
            }}
          >
            {" "}
            Next
          </button>
          <div className="">
            <Image
              loading="lazy"
              src="/images/right.png"
              alt=""
              width={25}
              height={25}
            />
          </div>
        </div>
      )}

      <style jsx>{`
        .pagination {
          display: flex;
          justify-content: center;

          justify-content: space-between;
          color: #667085;
        }

        .link {
          margin: 0 5px;
          padding: 20px, 0px, 0px, 0px;
          text-decoration: none;
          color: #333;
          border: 1px solid #ccc;
          border-radius: 4px;
        }

        a.active {
          background-color: #0070f3;
          color: white;
        }
      `}</style>
    </div>
  );
};

export default Pagination;
