import Image from "next/image";

const Exam = ({ data = {} }: any) => {
  return (
    <>
      <div className="subject-exam">
        <Image
          loading="lazy"
          src={`${"http://3.109.118.195:3000"}/uploads/${data.iconurl}`}
          className="exam-icon"
          alt=""
          width={100}
          height={100}
        />
        <div className="sub">{data.name}</div>
      </div>
    </>
  );
};

export default Exam;
