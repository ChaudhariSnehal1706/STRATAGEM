import Image from "next/image";

import Carousel from "react-multi-carousel";
import "./partners.css";
import "react-multi-carousel/lib/styles.css";
export default function Partners(props: any) {
  const { data } = props;
  const responsive = {
    superLargeDesktop: {
      breakpoint: { max: 4000, min: 3000 },
      items: 3,
      slidesToSlide: 3,
    },
    desktop: {
      breakpoint: { max: 3000, min: 1024 },
      items: 5,
      slidesToSlide: 2,
    },
    tablet: {
      breakpoint: { max: 1024, min: 464 },
      items: 2,
      slidesToSlide: 2,
    },
    mobile: {
      breakpoint: { max: 464, min: 0 },
      items: 1,
      slidesToSlide: 1,
    },
  };
  return (
    <div className="cars">
      <div className="car-item">
        <div className="car">
          <Carousel
            swipeable={false}
            draggable={false}
            showDots={false}
            responsive={responsive}
            ssr={false} // means to render carousel on server-side.
            infinite={true}
            autoPlay={false}
            autoPlaySpeed={1000}
            keyBoardControl={true}
            customTransition="all .5"
            transitionDuration={500}
            containerClass="carousel-container-2"
            removeArrowOnDeviceType={["tablet", "mobile"]}
            renderArrowsWhenDisabled={true}
            dotListClass="custom-dot-list-style"
            itemClass="carousel-item-padding-5-px"
          >
            {data.map((item: any) => (
              <Image
                loading="lazy"
                src={`${"http://3.109.118.195:3000"}/uploads/${item.logoURL}`}
                className="car-logo"
                alt=""
                key={item._id}
                width={100}
                height={100}
              />
            ))}
          </Carousel>
        </div>
      </div>
    </div>
  );
}
