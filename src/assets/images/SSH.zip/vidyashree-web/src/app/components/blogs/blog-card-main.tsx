import * as cheerio from "cheerio";
import BlogCard from "./blog-card";
import api from "@/functions/api";
import { useEffect, useState } from "react";
import { useParams } from "next/navigation";
import Image from "next/image";
export default function BlogCardMain({
  author,
  date,
  title,
  subtitle,
  description,
  labels,
  imgsrc,
}: any) {
  const params: any = useParams();
  const blogId = params.id;
  const [blogs, setBlog] = useState([]);
  const [blog, setBlogById] = useState([]);
  const [recentBlogs, setRecentBlog] = useState([]);
  const [totalBlogs, setTotalBlogs] = useState(0);
  const [currentPage, setCurrentPage] = useState(1);
  const limit = 4;
  const getBlog = async () => {
    try {
      const data: any = await api.get(
        `/blogs?skip=${(currentPage - 1) * limit}&limit=${limit}`
      );
      setBlog(data.blogs_data);
      setTotalBlogs(Math.ceil(data.total_records / limit));
    } catch (err) {
      console.log("🚀 ~ getBlog ~ err1:", err);
    }
  };
  const handlePagination = (pageNumber: number) => {
    setCurrentPage(pageNumber);
    getBlog();
  };
  const getRecentBlog = async () => {
    try {
      const data: any = await api.get("/blogs/recent");
      if (data) {
        setRecentBlog(data);
      }
    } catch (err) {
      console.log("🚀 ~ getBlog ~ err2:", err);
    }
  };

  useEffect(() => {
    getBlog();
    getRecentBlog();
  }, []);
  const $ = cheerio.load(description ? description : "", { xmlMode: true });
  return (
    //     <div className='w-[1150px] h-[530px] mt-5 sm:flex-col md:flex-row flex-col'>

    //   <Image loading='lazy'
    //     src={imgsrc}
    //     alt=''
    //   />
    //     <p className='text-[#6941C6] mt-6'>{author} • {date}</p>
    //     <p className='font-semibold mt-2 text-[24px]'>
    //       {title}
    //     </p>

    //     {/* <div className=' flex mt-5 gap-4'>
    //       <button>Design </button>
    //       <button>Research </button>
    //       <button>Presentation </button>
    //     </div> */}
    //     <div className='px-6 py-4'>
    //     {labels.map((label: any) => {
    //       return (
    //         <span
    //           key={`label-${Math.random() * 1000}`}
    //           className='capitalize inline-block bg-red-200 rounded-full px-3 py-1 text-sm font-semibold text-gray-700 mr-2'
    //         >
    //           {label}
    //         </span>
    //       )
    //     })}
    //   </div>
    //     <div>
    //       <p className='text-[#667085] text-[16px] mt-4 sm:flex-col md:flex-row flex-col '>
    //       {$.text()}
    //       </p>
    //     </div>

    //     <br />
    //   </div>
    <div className="w-[1150px] h-[530px] mt-5 sm:flex-col md:flex-row flex-col">
      <div style={{ display: "flex", justifyContent: "center" }}>
        <Image loading="lazy" src={imgsrc} alt="" width={400} height={50} />
      </div>
      <p className="text-[#6941C6] mt-6">
        {author} • {date}
      </p>
      <p className="font-semibold mt-2 text-[24px]">{title}</p>

      {/* <div className=' flex mt-5 gap-4'>
      <button>Design </button>
      <button>Research </button>
      <button>Presentation </button>
    </div> */}
      {labels?.map((label: any) => {
        return (
          <span
            key={`label-${Math.random() * 1000}`}
            className="capitalize inline-block bg-red-200 rounded-full px-3 py-1 text-sm font-semibold text-gray-700 mr-2"
          >
            {label}
          </span>
        );
      })}

      <div>
        <p
          className="text-[#667085] text-[16px] mt-4 sm:flex-col md:flex-row flex-col"
          dangerouslySetInnerHTML={{ __html: description }}
        ></p>
      </div>

      <h1 className="mt-10  font-semibold text-[16px]"> Similar Blogs</h1>
      <div className="mt-15 flex md:flex-row flex-wrap flex-col items-center justify-center gap-4 w-[1250px] h-[1000px]">
        {blogs
          ? blogs.map((blog: any, index: number) => {
              return (
                <BlogCard
                  key={index}
                  author={blog.author}
                  date={new Date(blog.blogDate).toLocaleDateString(undefined, {
                    day: "numeric",
                    month: "long",
                    year: "numeric",
                  })}
                  title={blog.title}
                  subtitle={blog.subtitle}
                  description={blog.content}
                  labels={blog.tags.split(",")}
                  imgsrc={`http://3.109.118.195:3000/uploads/${blog.imageUrl}`}
                  href={`/blogs/${blog._id}`}
                />
              );
            })
          : null}
      </div>
      <br />
    </div>
  );
}
