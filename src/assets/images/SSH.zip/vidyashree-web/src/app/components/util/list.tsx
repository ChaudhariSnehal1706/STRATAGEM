"use client";

import styled from "styled-components";

function List(props: any) {
  const { title, children } = props;
  return (
    <Ul>
      <Li>{children} </Li>
    </Ul>
  );
}

const Ul = styled.ul`
  box-sizing: border-box;
  margin-left: 150px;
  color: var(--darkbluegrey, #3c4852);
  text-align: left;
  font-size: 30px;
  line-height: 24px;
  font-weight: 600;
  margin-bottom: 20px;
  position: relative;
`;
const Li = styled.li`
  color: var(--grey-text, #778590);
  text-align: left;

  font-size: 18px;
  line-height: 30px;
  list-style: circle;
  font-weight: 400;
  position: relative;
  width: 100%;
  height: 100%;
`;
export default List;
