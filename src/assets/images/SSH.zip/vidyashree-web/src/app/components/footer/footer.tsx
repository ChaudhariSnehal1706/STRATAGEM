import Link from "next/link";
import "./footer.css";
import Image from "next/image";
export default function Footer() {
  return (
    <footer style={{ backgroundColor: "#252525", color: "#FFFFFF" }}>
      <div className="container-lg mx-auto">
        <div className="flex  md:justify-around md:flex-row sm:flex-col flex-col items-center">
          <div className="content-padding m-4">
            {/* <Image loading='lazy' src="./images/logo.png"></img><p className='footer-heading'>Vidhyashree</p> */}
            <div className="flex gap-4">
              <Image
                loading="lazy"
                src={"/images/logo.png"}
                className="flex mt-6"
                width={80}
                height={80}
                alt="Logo"
              />{" "}
              <h1 className="text-white text-lg py-10 mt-0">Vidhyashree</h1>
            </div>
            {/* <p>
              {' '}
              This Platform aims to facilities seamless communication, learning
              and evaluation for students and educators. VidhyaShree offers a
              range of feature to enhance the educational experience.{' '}
            </p> */}
            <p className="text-white text-[16px] mt-0">
              This platform aims to facilities seamless
            </p>
            <p className="text-white text-[16px]">
              communication, learning and evaluation
            </p>
            <p className="text-white text-[16px]">
              for student and educators.Vidhyashree
            </p>
            <p className="text-white text-[16px]">
              offer a range of feature to enhance the{" "}
            </p>
            <p className="text-white text-[16px]">educational experience. </p>
            <div className="flex gap-4 mt-7">
              <Link
                href="https://www.facebook.com/profile.php?id=100092455821349&mibextid=ZbWKwL"
                target="_blank"
              >
                {" "}
                <Image
                  loading="lazy"
                  src="/images/Vector.png"
                  alt=""
                  width={25}
                  height={25}
                />
              </Link>
              <Link
                href="https://www.instagram.com/vidhyasri_elearning/"
                target="_blank"
              >
                <Image
                  loading="lazy"
                  src="/images/Instagram.png"
                  alt=""
                  width={25}
                  height={25}
                />
              </Link>
              <Link
                href="http://www.linkedin.com/in/vidhya-sri-332a27276"
                target="_blank"
              >
                <Image
                  loading="lazy"
                  src="/images/Linkedin.png"
                  alt=""
                  width={25}
                  height={25}
                />
              </Link>
              <Link href="">
                <Image
                  loading="lazy"
                  src="/images/Youtube.png"
                  alt=""
                  width={25}
                  height={25}
                />
              </Link>
            </div>
            <div className="mt-4 ml-6">
              <Image
                loading="lazy"
                src="/images/Ellipse 13.png"
                alt=""
                width={25}
                height={25}
              />
            </div>
          </div>
          <div className="content-padding">
            <p className="footer-heading mt-16">Popular Exams</p>
            <p className="mt-2.5">
              {" "}
              <Link href="#">CBSE Exams </Link>
            </p>
            <p>
              <Link href="#"> Pre Boards</Link>{" "}
            </p>
            <p>
              <Link href="#">Class 8th </Link>
            </p>
            <p>
              <Link href="#"> Class 5th </Link>
            </p>
          </div>
          <div className="content-padding">
            <p className="footer-heading mt-16">Quick Links</p>
            <p className="mt-2.5">
              <Link href="/about-us">About Us</Link>
            </p>
            <p>
              <Link href="/faq">FAQ</Link>
            </p>
            <p>
              <Link href="/blogs">Blogs</Link>
            </p>
            <p>
              <Link href="/terms-condition">Terms and Condition</Link>
            </p>
            <p>
              <Link href="/privacy-policy">Privacy Policy</Link>
            </p>
          </div>
          <div className="content-padding">
            <p className="footer-heading mt-16">CONTACT</p>
            <p className="mt-2.5">
              <Link href="#">info@vidhyashree.com</Link>
            </p>
            <p>+91 882-587-3025</p>
            <p>6116 Willa River Suite 610</p>
          </div>
        </div>
        <div>
          <p className="text-center">
            Copyright © {new Date().getFullYear()} |{" "}
            <Link href="#">www.vidhyashree.com</Link> | VidhyaShree | All Rights
            Reserved
          </p>
        </div>
      </div>
    </footer>
  );
}
// rgba(37, 37, 37, 1)
