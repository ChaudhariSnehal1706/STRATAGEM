"use client";

import Button from "@mui/material/Button";
import { styled } from "@mui/material/styles";

interface CustomButtonProps {
  disabled?: boolean;
}

export const CustomDarkButton = styled(Button)<CustomButtonProps>(
  ({ disabled }: CustomButtonProps) => ({
    height: "48px",
    borderRadius: "0.75rem",
    textTransform: "none",
    fontSize: "16px",
    fontWeight: 400,
    color: disabled ? "#b0b0b0" : "#ffffff",
    backgroundColor: disabled ? "#b0b0b0" : "#3c4852",
    "&:hover": {
      backgroundColor: disabled ? "#b0b0b0" : "#3c4852",
    },
    pointerEvents: disabled ? "none" : "auto",
    opacity: disabled ? 0.7 : 1,
  })
);

export const CustomPrimaryButton = styled(Button)<CustomButtonProps>(
  ({ disabled }: CustomButtonProps) => ({
    height: "46px",
    borderRadius: "8px",
    textTransform: "none",
    fontSize: "16px",
    fontWeight: 600,
    color: disabled ? "#b0b0b0" : "#ffffff",
    backgroundColor: disabled ? "#b0b0b0" : "#8B75F3",
    "&:hover": {
      backgroundColor: disabled ? "#b0b0b0" : "#8B75F3",
    },
    pointerEvents: disabled ? "none" : "auto",
    opacity: disabled ? 0.7 : 1,
  })
);
