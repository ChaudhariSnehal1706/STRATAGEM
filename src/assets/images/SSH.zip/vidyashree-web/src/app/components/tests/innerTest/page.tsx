"use client";
import Header from "../../header/header";
import ImageWithText from "./cardComponent";
import "./page.css";
import SectionHeading from "../../util/section-heading";
import List from "../../util/list";
import Footer from "../../footer/footer";
import Image from "next/image";
const InnerTest = (props: any) => {
  const { text } = props;

  return (
    <>
      <Header title="" />
      <div className="app">
        <ImageWithText
          loading="lazy"
          WithText
          imageUrl={"/images/teacher.png"}
          text="UPSC Interview All India Live Test Series"
          text2="12 Lessons"
          text3="40 hours"
          text4="Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry standard dummy text ever since the 1500s, Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry standard dummy text ever since the 1500s,"
          button1="Add to wishlist"
          button2="Buy Know"
        />
        <SectionHeading title="About the Series">
          Lorem Ipsum is simply dummy text of the printing and typesetting
          industry. Lorem Ipsum has been the industry standard dummy text ever
          since the 1500s, when an unknown printer took a galley of type and
          scrambled it to make a type specimen book. It has survived not only
          five centuries, but also the leap into electronic typesetting,
          remaining essentially unchanged. Lorem Ipsum is simply dummy text of
          the printing and typesetting industry. Lorem Ipsum has been the
          industry&npos standard dummy text ever since the 1500s, when an
          unknown printer took a galley of type and scrambled it to make a type
          specimen book. It has survived not only five centuries, but also the
          leap into electronic typesetting, remaining essentially unchanged.
          View More
        </SectionHeading>
        <SectionHeading title="What Topics you'll Cover" />
        <List>
          Lorem Ipsum is simply dummy text of the printing and typesetting
          industry
        </List>
        <List>
          Lorem Ipsum is simply dummy text of the printing and typesetting
          industry
        </List>
        <List>
          Lorem Ipsum is simply dummy text of the printing and typesetting
          industry
        </List>
        <List>
          Lorem Ipsum is simply dummy text of the printing and typesetting
          industry
        </List>
        <List>
          Lorem Ipsum is simply dummy text of the printing and typesetting
          industry
        </List>
        <List>
          Lorem Ipsum is simply dummy text of the printing and typesetting
          industry
        </List>
      </div>
      <br />
      <Footer />
    </>
  );
};
export default InnerTest;
