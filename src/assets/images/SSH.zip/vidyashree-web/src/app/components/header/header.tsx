// import Image from 'next/image'
// import Link from 'next/link'
// import Navbar from './narbar'

// const Header = ({
//   title = 'No Title',
//   msg = '',
//   containerClassName = '',
//   icon = '',
//   subTitle = '',
// }) => {
//   const {
//     dimensions: { width },
//     ref,
//   } = useDimensions()

//   return (
//     <div
//       className={'header ' + containerClassName}
//       style={{ backgroundImage: `url('/images/bg.png')` }}
//       ref={ref}
//     >
//       {width >= 600 && (
//         <div className='nav'>
//           {/* <div className='tab-bar'>
//             <div>
//               <Image
//                 loading='lazy'
//                 src={'/icons/logo.png'}
//                 className='logo-icon'
//                 alt=''
//                 width={168}
//                 height={168}
//               />
//             </div>
//             <div className='tab-bar'>
//               <Link href='/'>Home</Link>
//               <Link href='/test-series'>Test Series</Link>
//               <Link
//                 style={{
//                   display: 'flex',
//                   alignItems: 'center',
//                 }}
//                 href='/exams'
//               >
//                 <div>Exams</div>
//                 <Image
//                   loading='lazy'
//                   src={'/icons/down.png'}
//                   className='down-icon'
//                   alt='down'
//                   width={68}
//                   height={68}
//                 />
//               </Link>
//               <Link href='/blogs'>Blogs</Link>
//               <Link href='/about-us'>About Us </Link>
//             </div>
//           </div> */}
//           {/* <div className='lang'>
//             <Link className='login-btn' href={'/login'}>
//               Login/ Signup
//             </Link>
//             <div className='lang con-img'>
//               <Image
//                 loading='lazy'
//                 src={'/icons/ind.png'}
//                 className='ind-icon'
//                 alt='India Flag'
//                 width={68}
//                 height={68}
//               />
//               <span>ENG</span>
//             </div>
//           </div> */}
//           <Navbar/>
//         </div>
//       )}
//       <div className='header-content'>
//         {msg && (
//           <div className='msg'>
//             {' '}
//             {icon && (
//               <Image
//                 loading='lazy'
//                 src={icon}
//                 alt='Rocket'
//                 width={68}
//                 height={68}
//               />
//             )}{' '}
//             {msg}
//           </div>
//         )}
//         {title && <div className='title'>{title}</div>}
//         {subTitle && <div className='subTitle'>{subTitle}</div>}
//       </div>
//     </div>
//   )
// }

// export default Header
import useDimensions from "@/hooks/useDimensions";
import Image from "next/image";
import Link from "next/link";

const Header = ({
  title = "No Title",
  msg = "",
  containerClassName = "",
  icon = "",
  subTitle = "",
}) => {
  const {
    dimensions: { width },
    ref,
  } = useDimensions();

  return (
    <div
      className={"header " + containerClassName}
      style={{ backgroundImage: `url('/images/bg.png')` }}
      ref={ref}
    >
      {width >= 1000 && (
        <div className="nav">
          <div className="tab-bar">
            <div>
              <Image
                loading="lazy"
                src={"/icons/logo.png"}
                className="logo-icon"
                alt=""
                width={168}
                height={168}
              />
            </div>
            <div className="tab-bar">
              <Link href="/">Home</Link>
              <Link href="/test-series">Test Series</Link>
              <Link
                style={{
                  display: "flex",
                  alignItems: "center",
                }}
                href="/all-exams"
              >
                <div>Exams</div>
                <Image
                  loading="lazy"
                  src={"/icons/down.png"}
                  className="down-icon"
                  alt="down"
                  width={68}
                  height={68}
                />
              </Link>
              <Link href="/blogs">Blogs</Link>
              <Link href="/about-us">About Us </Link>
            </div>
          </div>
          <div className="lang">
            <Link className="login-btn" href={"/login"}>
              Login/ Signup
            </Link>
            <div className="lang con-img">
              <Image
                loading="lazy"
                src={"/icons/ind.png"}
                className="ind-icon"
                alt="India Flag"
                width={68}
                height={68}
              />
              <span>ENG</span>
            </div>
          </div>
        </div>
      )}
      <div className="header-content">
        {msg && (
          <div className="msg">
            {" "}
            {icon && (
              <Image
                loading="lazy"
                src={icon}
                alt="Rocket"
                width={68}
                height={68}
              />
            )}{" "}
            {msg}
          </div>
        )}
        {title && <div className="title">{title}</div>}
        {subTitle && <div className="subTitle">{subTitle}</div>}
      </div>
    </div>
  );
};

export default Header;
