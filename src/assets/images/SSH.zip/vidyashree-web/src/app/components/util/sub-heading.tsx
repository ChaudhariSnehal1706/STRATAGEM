"use client";

import styled from "styled-components";

function SubHeading(props: any) {
  const { title } = props;
  return <P>{title}</P>;
}

const P = styled.p`
  color:background:"#3C4852";
  text-align: left;
  font-size: 20px;
  line-height: 30px;
  font-weight: 700;
  position: relative;
  margin-bottom:10px;
`;
export default SubHeading;
