import Image from "next/image";

export default function HomeFeaturedCategories(props: any) {
  const { categories, onSelectCategory, selectedCategory } = props;
  return (
    <>
      <div>
        <div className="main-titel">
          <Image
            loading="lazy"
            src={"/images/featured_category.png"}
            alt="Featured Category"
            width={413}
            height={91}
          />
        </div>
      </div>
      <div className="map">
        {categories.map((item: any, i: any) => (
          <div key={item._id}>
            <div
              className={
                "category " + (item._id == selectedCategory && "active")
              }
              onClick={() => {
                onSelectCategory(item);
              }}
            >
              <Image
                loading="lazy"
                src={`${"http://3.109.118.195:3000"}/uploads/${item.iconUrl}`}
                className="category-img"
                alt="Comptitive Exams"
                width={100}
                height={100}
              />
              <div className="exams">{item.name}</div>
              <div className="class">
                {item.totalTestSeries || 0}+ Class Avaiable
              </div>
            </div>
          </div>
        ))}
      </div>
    </>
  );
}
