import Image from "next/image";

export default function WallOfFames(props: any) {
  const { data } = props;

  return (
    <>
      <div className="all-user">
        <div className="heding">
          <Image
            loading="lazy"
            src={"/icons/text-two.png"}
            className="text-two-icon"
            alt="Wall of fame"
            width={100}
            height={100}
          />
        </div>
        <div
          style={{ backgroundImage: `url('/images/bg-img.png')` }}
          className="bgImg"
        >
          <div className="users">
            {data.map((item: any) => (
              <div className="user-list" key={item._id}>
                <Image
                  loading="lazy"
                  alt=""
                  src={`${"http://3.109.118.195:3000"}/uploads/${item.imageUrl}`}
                  className="user-img"
                  width={200}
                  height={200}
                />
                <button className="btn air-btn">
                  <Image
                    loading="lazy"
                    alt=""
                    src={"/icons/star.png"}
                    className="star-icon"
                    width={60}
                    height={60}
                  />
                  <div className="air-text">{item.rank}</div>
                </button>
                <div className="user-name">{item.name}</div>
                <div className="user-class">{item.category?.name}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </>
  );
}
