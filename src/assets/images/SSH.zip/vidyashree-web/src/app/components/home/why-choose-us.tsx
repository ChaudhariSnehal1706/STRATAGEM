import Image from "next/image";

const cart = [
  {
    title: "Daily Practice",
    images: "/images/sub.png",
  },
  {
    title: "Subject Focus",
    images: "/images/sub.png",
  },
  {
    title: "National Level Tests",
    images: "/images/test.png",
  },
  {
    title: "In-depth Performance Insight",
    images: "/images/performance.png",
  },
  {
    title: "All India Ranking",
    images: "/images/ranking.png",
  },
  {
    title: "Personalized Guidance",
    images: "/images/guidance.png",
  },
  {
    title: "Anytime Access",
    images: "/images/anytime.png",
  },
];

export default function WhyChooseUs() {
  return (
    <div className="subject">
      <div>
        <div className="heading-titel">Why Choose Us</div>
        <div className="heading-text">
          When it comes to exam success, Vidhyashree is your ideal partner. We
          cater to students unique needs with a host of advantages. Here&npos
          why you should choose Vidhyashree.
        </div>
      </div>
      <div className="subject-box">
        {cart.map((item) => (
          <div className="subject-teb" key={Math.random() * 10000000}>
            <Image
              loading="lazy"
              src={item.images}
              className="logo"
              alt="Subject Title"
              width={100}
              height={100}
            />
            <div className="subject-text">{item.title}</div>
            <div className="subject-titel">
              Stay engaged with daily practice tests for consistent progress.
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
