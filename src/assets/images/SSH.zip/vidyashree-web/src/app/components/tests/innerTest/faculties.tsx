import Image from "next/image";

const Faculties = (props: any) => {
  const { facultyName, imageSrc } = props;
  return (
    <div className="overlay-image">
      <Image
        loading="lazy"
        src={imageSrc}
        width="300"
        height="200"
        className="faculty"
        alt="teacher"
      />
      <div className="faculties">
        <h2 className="faculty-heading">Chris</h2>
        <p>Biology Teacher</p>
      </div>
    </div>
  );
};
export default Faculties;
