"use client";
import { useEffect, useState } from "react";
import Carousel from "react-multi-carousel";
import "./classes.css";
import "react-multi-carousel/lib/styles.css";
const Classes = ({
  data,
  onChange,
  onSelectSubcategory,
  selectedSubCategory,
}: any) => {
  const responsive = {
    superLargeDesktop: {
      breakpoint: { max: 4000, min: 3000 },
      items: 5,
      slidesToSlide: 3,
    },
    desktop: {
      breakpoint: { max: 3000, min: 1024 },
      items: 7,
      slidesToSlide: 4,
    },
    tablet: {
      breakpoint: { max: 1024, min: 464 },
      items: 2,
      slidesToSlide: 2,
    },
    mobile: {
      breakpoint: { max: 464, min: 0 },
      items: 1,
      slidesToSlide: 1,
    },
  };
  return (
    <>
      <div className="all-class">
        <div className="class-list">
          <Carousel
            swipeable={false}
            draggable={false}
            showDots={false}
            responsive={responsive}
            ssr={false}
            infinite={true}
            autoPlay={false}
            autoPlaySpeed={1000}
            keyBoardControl={true}
            customTransition="all .5"
            transitionDuration={500}
            containerClass="carousel-container-3"
            removeArrowOnDeviceType={["tablet", "mobile"]}
            renderArrowsWhenDisabled={true}
            dotListClass="custom-dot-list-style"
            itemClass="carousel-item-padding-5-px"
          >
            {data?.map((item: any, i: number) => (
              <div
                className={
                  "std " + (selectedSubCategory == item._id && "active")
                }
                key={item._id}
                onClick={() => {
                  //handleSelectExam(item)
                  //onSelectSubcategory(item._id)
                }}
              >
                {item.name}
              </div>
            ))}
          </Carousel>
        </div>
      </div>
    </>
  );
};

export default Classes;
