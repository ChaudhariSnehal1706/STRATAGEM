import * as cheerio from "cheerio";
import Image from "next/image";
import Link from "next/link";
export default function BlogCardS({
  author,
  date,
  labels,
  title,
  description,
  firstButtonLabel,
  secondButtonLabel,
  imgSrc,
  href,
}: any) {
  const $ = cheerio.load(description, { xmlMode: true });
  return (
    <Link href={href}>
      <div className="mt-8 gap-4 flex">
        <div className="flex gap-4">
          <Image
            loading="lazy"
            src={`${imgSrc}`}
            alt=""
            style={{ minHeight: 188, maxHeight: 188 }}
            width={188}
            height={188}
            className="w-full h-auto"
          />
          <div>
            <p className="text-[#6941C6]">
              {author} • {date}
            </p>
            <p className="mt-3 font-semibold">{title}</p>
            <div
              className="text-[#667085] text-[16px] mt-2"
              style={{
                maxHeight: 70,
                minHeight: 70,
                overflow: "hidden",
                textOverflow: "ellipsis",
              }}
            >
              {$.text()}
            </div>
            <div className="gap-7 flex mt-4">
              {labels.map((label: any) => {
                return (
                  <span
                    key={`label-${Math.random() * 1000}`}
                    className="capitalize inline-block bg-red-200 rounded-full px-3 py-1 text-sm font-semibold text-gray-700 mr-2"
                  >
                    {label}
                  </span>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </Link>
  );
}
