import * as cheerio from "cheerio";
import Image from "next/image";
import Link from "next/link";

export default function BlogCard({
  author,
  date,
  title,
  subtitle,
  description,
  labels,
  imgsrc,
  href,
}: any) {
  const $ = cheerio.load(description, { xmlMode: true });
  console.log("Image SRC", imgsrc);
  return (
    <Link href={href}>
      <div className="max-w-sm rounded overflow-hidden shadow-lg mt-6">
        <Image
          loading="lazy"
          src={imgsrc}
          alt=""
          style={{ minHeight: 240, maxHeight: 240 }}
          width={240}
          height={240}
          className="w-full h-auto"
        />
        <div className="px-6 py-4">
          <div className="text-[14px], text-[#6941C6] mt-6">
            {author} • {date}
          </div>
          <div
            className="text-[24px] font-semibold"
            style={{
              maxHeight: 70,
              minHeight: 70,
              overflow: "hidden",
              textOverflow: "ellipsis",
            }}
          >
            {title} <span className="text-sm">{subtitle}</span>
          </div>
          <p
            className="text-[#667085] text-[16px]"
            style={{
              maxHeight: 150,
              minHeight: 150,
              overflow: "hidden",
              textOverflow: "ellipsis",
            }}
          >
            {$.text()}
          </p>
        </div>
        <div className="px-6 py-4">
          {labels.map((label: any) => {
            return (
              <span
                key={`label-${Math.random() * 1000}`}
                className="capitalize inline-block bg-red-200 rounded-full px-3 py-1 text-sm font-semibold text-gray-700 mr-2"
              >
                {label}
              </span>
            );
          })}
        </div>
      </div>
    </Link>
  );
}
