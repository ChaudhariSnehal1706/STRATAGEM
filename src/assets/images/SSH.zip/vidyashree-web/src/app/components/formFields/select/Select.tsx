import { Box, InputLabel } from "@mui/material";
import FormHelperText from "@mui/material/FormHelperText";
import MenuItem from "@mui/material/MenuItem";
import MaterialSelect, { BaseSelectProps } from "@mui/material/Select";
import { get } from "lodash";
import { Controller, useFormContext } from "react-hook-form";

interface SelectProps<T> extends BaseSelectProps {
  name: string;
  options: T[];
  valuePath?: string;
  labelPath?: string;
  label?: string;
  addEmptyOption?: boolean;
  emptyOptionLabel?: string;
  isLoading: boolean;
  isError: boolean;
}

export const Select = <T extends { [key: string]: any }>({
  name,
  options,
  valuePath,
  labelPath,
  label,
  addEmptyOption = false,
  emptyOptionLabel = "Select a Value",
  isLoading,
  isError,
  ...rest
}: SelectProps<T>) => {
  const { getFieldState, control } = useFormContext();

  const { error } = getFieldState(name);

  const hasError = !!error || !!isError;

  const materialSelectOptions = options.map((option) => (
    <MenuItem
      key={get(option, valuePath || "value")}
      value={get(option, valuePath || "value")}
    >
      {get(option, labelPath || "label")}
    </MenuItem>
  ));

  return (
    <Box display="flex" flexDirection="column" rowGap={1} width="100%">
      {!!label && <InputLabel htmlFor={name}>{label}</InputLabel>}

      <div className="w-full">
        <Controller
          name={name}
          control={control}
          render={({ field }) => {
            return (
              <MaterialSelect
                {...field}
                error={!!error}
                style={{ width: "100%" }}
                {...rest}
              >
                {addEmptyOption && (
                  <MenuItem value="">
                    <em>{emptyOptionLabel}</em>
                  </MenuItem>
                )}
                {materialSelectOptions}
              </MaterialSelect>
            );
          }}
        />

        {hasError ? (
          <FormHelperText error>
            {error?.message || "Something went wrong!"}
          </FormHelperText>
        ) : null}
      </div>
    </Box>
  );
};
