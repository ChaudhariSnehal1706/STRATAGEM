import Image from "next/image";

const SelectexamCategories = () => {
  return (
    <>
      <div className="all-class  ">
        <Image
          loading="lazy"
          src={"/icons/right-icon.png"}
          className="right-icon "
          alt="Class "
          width={84}
          height={84}
        />
        <div className="class-list ">
          {Array.from({ length: 10 }).map((item, i) => (
            <div className={"std " + (i === 0 && "active")} key={i}>
              class {i + 5}
            </div>
          ))}
        </div>
        <Image
          loading="lazy"
          src={"/icons/left-icon.png"}
          className="right-icon"
          alt="Class Icon"
          width={84}
          height={84}
        />
      </div>
    </>
  );
};

export default SelectexamCategories;
