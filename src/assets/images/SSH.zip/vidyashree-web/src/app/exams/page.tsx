"use client";
import Footer from "../components/footer/footer";
import Header from "../components/header/header";
import SelectexamCategories from "./selectexam-categories/selectexam-categories";
import Exams from "../components/exams/exams";
import Classes from "../components/classes/classes";
import { useEffect, useState } from "react";
import api from "@/functions/api";

export default function AllExams() {
  const [subCategories, setSubCategories] = useState([]);
  const [subjects, setSubjects] = useState([]);

  const getSubCategories = async () => {
    try {
      const data: any = await api.get("/subcategories");
      setSubCategories(data);
      if (data) {
        getSubjects(data[0]._id);
      }
    } catch (err) {
      console.log("🚀 ~ getCategories ~ err:", err);
    }
  };
  const getSubjects = async (subcategory: string) => {
    try {
      if (subcategory) {
        const data: any = await api.get(`/subjects?subcategory=${subcategory}`);
        setSubjects(data);
      } else {
        const data: any = await api.get("/subjects");
        setSubjects(data);
      }
    } catch (err) {
      console.log("🚀 ~ getCategories ~ err:", err);
    }
  };
  const handleSelectedSubCategoryChange = (data: any) => {
    console.log("data changes..", data);
    getSubjects(data);
    //setSubjects(tempSubjects)
  };
  useEffect(() => {
    getSubCategories();
  }, []);

  return (
    <>
      <Header title="Exams" />
      <div className="exam-titel text-center mt-4 font-poppins text-[40px] text-[#3C4852] font-semibold">
        Select your Exams to Get Started
      </div>
      {/* <SelectexamCategories />
       <Exams />
       <Exams /> */}
      <Classes
        data={subCategories}
        onChange={handleSelectedSubCategoryChange}
        onSelectSubcategory={handleSelectedSubCategoryChange}
      />
      <Exams data={subjects} />
      <Footer />
    </>
  );
}
