import DashboardLayout from "../dashboard-layout";
import Image from "next/image";
const Home = () => {
  return (
    <DashboardLayout>
      <div>
        <p
          className="text-center w-full ml-[450px] text-8xl"
          style={{ fontFamily: "Poppins", fontWeight: "bold" }}
        >
          HOME
        </p>
      </div>
    </DashboardLayout>
  );
};

export default Home;
