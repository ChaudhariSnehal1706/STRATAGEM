// TestSeriesCard.tsx
import React from "react";

interface TestSeriesCardProps {
  imageSrc: string;
  title: string;
  details: string;
  date: string;
  buttonText: string;
}

const TestSeriesCard: React.FC<TestSeriesCardProps> = ({
  imageSrc,
  title,
  details,
  date,
  buttonText,
}) => {
  return (
    <div className="min-w-[282px] min-h-[359px] shadow-2xl rounded-2xl">
      <div className="px-5 gap-2 py-3 items-center font-semibold text-[15px]">
        <img src={imageSrc} alt="" width={270} height={142} />
        <p>{title}</p>
      </div>
      <div className="py-3 px-3 text-[#778590] text-[14px]">
        <p>{details}</p>
        <p className="mt-2">{date}</p>
        <button className="w-[250px] h-[46px] bg-[#8B75F3] text-white font-semibold mt-6 rounded-xl">
          {buttonText}
        </button>
      </div>
    </div>
  );
};

export default TestSeriesCard;
