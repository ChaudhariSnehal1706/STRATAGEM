// HorizontalScrollItem.tsx
import React from "react";

interface HorizontalScrollItemProps {
  title: string;
  status: string;
  details: string;
  date: string;
  imageUrl: string;
}

const HorizontalScrollItem: React.FC<HorizontalScrollItemProps> = ({
  title,
  status,
  details,
  date,
  imageUrl,
}) => {
  return (
    <div className="min-w-[369px] h-[127px] bg-[#F6F7F8] rounded-2xl ml-4">
      <div className="flex items-start py-2 px-2 gap-2">
        <img src={imageUrl} alt="" width={96} height={61} />
        <p className="text-[16px] font-semibold">{title}</p>
      </div>

      <div className="flex px-3">
        <p className="bg-[#DFF2E0] text-[#06C302] w-[96px] h-[31px] px-1 py-1 text-[14px]">
          {status}
        </p>
        <p
          className="text-[13px] text-[#778590] ml-2"
          style={{ marginTop: -15 }}
        >
          {details}
        </p>
      </div>
      <p
        className="text-[13px]  text-[#778590]"
        style={{ marginTop: -25, marginLeft: 120 }}
      >
        {date}
      </p>
    </div>
  );
};

export default HorizontalScrollItem;
