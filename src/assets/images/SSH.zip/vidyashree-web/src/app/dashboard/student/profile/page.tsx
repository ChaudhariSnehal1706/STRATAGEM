"use client";
import Image from "next/image";
import EditHeader from "../../../components/editHeader/editHeader";
import VerticalSidebar from "../../../components/sidebar/VerticalSidebar";
import { useState } from "react";
import DashboardLayout from "../../dashboard-layout";

export default function StudentEditProfile() {
  const [position, setPosition] = useState(0);
  // const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const arr = [
    "General Information",
    "Contact Information",
    "Academic Information",
    "Guardian Information",
    "Social Media Information",
    "Sibling Information",
    "Requirement Details",
  ];
  // const handleSidebarToggle = () => {
  //   setIsSidebarOpen((prevIsSidebarOpen) => !prevIsSidebarOpen);
  // };
  return (
    <DashboardLayout>
      <div className="w-[80%] h-[950px] ml-[350px]  bg-[white] rounded-2xl">
        <div>
          <div
            className=""
            style={{
              height: 500,
              display: "flex",
              position: "fixed",
              borderRight: "1px solid #EAECED",
              marginLeft: "-18px",
            }}
          >
            <VerticalSidebar arr={arr} activestep={position} />
          </div>
          <p className="py-10 px-80 flex font-semibold text-[#3C4852]">
            General Information
          </p>
          <div
            className="  flex items-center"
            style={{ marginTop: -30, marginLeft: 300 }}
          >
            <Image
              loading="lazy"
              src="/images/Ellipse 230.png"
              alt=""
              width={88}
              height={88}
            />
            <p> Change Profile</p>
          </div>
          <div className="flex justify-between px-80">
            <p> Full Name </p>

            <div style={{ paddingRight: 370 }}>
              <p> DOB</p>
            </div>
          </div>
          <div className="px-80 py-3 flex gap-6">
            <input
              type="text "
              placeholder="Select your Category"
              style={{
                border: "1px solid #C7C7C2",
                borderRadius: "8px",
                width: "393px",
                height: "54px",
                paddingLeft: "14px",
              }}
            />
            <input
              type="date"
              placeholder="Select your Category"
              style={{
                border: "1px solid #C7C7C2",
                borderRadius: "8px",
                width: "393px",
                height: "54px",
                paddingLeft: "14px",
              }}
            />
          </div>
        </div>
        <div className="flex justify-between px-80">
          <p> Blood Group </p>

          <div style={{ paddingRight: 350 }}>
            <p> Gender</p>
          </div>
        </div>
        <div className="px-80 py-3 flex gap-6">
          <input
            type="text"
            placeholder="Select your Category"
            style={{
              border: "1px solid #C7C7C2",
              borderRadius: "8px",
              width: "393px",
              height: "54px",
              paddingLeft: "14px",
            }}
          />
          <select
            id=""
            name=""
            style={{
              border: "1px solid #C7C7C2",
              borderRadius: "8px",
              width: "393px",
              height: "54px",
              paddingLeft: "14px",
            }}
          >
            <option value="" disabled selected hidden>
              Select gender
            </option>
            <option value="" style={{ color: "grey" }}>
              {" "}
              m
            </option>
            <option value="" style={{ color: "grey" }}>
              {" "}
              f
            </option>
          </select>
        </div>

        <div className="flex justify-between px-80">
          <p> Add Category </p>

          <div style={{ paddingRight: 330 }}>
            <p> Language</p>
          </div>
        </div>
        <div className="px-80 py-3 flex gap-6">
          <select
            id=""
            name=""
            style={{
              border: "1px solid #C7C7C2",
              borderRadius: "8px",
              width: "393px",
              height: "54px",
              paddingLeft: "14px",
            }}
          >
            <option value="" style={{ color: "grey" }}>
              {" "}
            </option>
            <option value="" style={{ color: "grey" }}>
              {" "}
            </option>
          </select>
          <select
            id=""
            name=""
            style={{
              border: "1px solid #C7C7C2",
              borderRadius: "8px",
              width: "393px",
              height: "54px",
              paddingLeft: "14px",
            }}
          >
            <option value="" style={{ color: "grey" }}></option>
            <option value="" style={{ color: "grey" }}></option>
          </select>
        </div>
        <div className="flex justify-between px-80">
          <p> PD </p>

          <div style={{ paddingRight: 345 }}>
            <p> Hobbies</p>
          </div>
        </div>
        <div className="px-80 py-3 flex gap-6">
          <select
            id=""
            name=""
            style={{
              border: "1px solid #C7C7C2",
              borderRadius: "8px",
              width: "393px",
              height: "54px",
              paddingLeft: "14px",
            }}
          >
            <option value="" style={{ color: "grey" }}></option>
            <option value="" style={{ color: "grey" }}>
              {" "}
            </option>
          </select>
          <select
            id=""
            name=""
            style={{
              border: "1px solid #C7C7C2",
              borderRadius: "8px",
              width: "393px",
              height: "54px",
              paddingLeft: "14px",
            }}
          >
            <option value="" style={{ color: "grey" }}></option>
            <option value="" style={{ color: "grey" }}>
              {" "}
            </option>
          </select>
        </div>
        {/*  */}

        <div className="flex justify-between px-80">
          <p> About yourself </p>

          <div style={{ paddingRight: 330 }}>
            <p> AIM in Life</p>
          </div>
        </div>
        <div className="px-80 py-3 flex gap-6">
          <input
            type="text "
            placeholder="Write here"
            style={{
              border: "1px solid #C7C7C2",
              borderRadius: "8px",
              width: "393px",
              height: "154px",
              paddingBottom: "100px",
              paddingLeft: "14px",
            }}
          />
          <input
            type="text "
            placeholder="Write here"
            style={{
              border: "1px solid #C7C7C2",
              borderRadius: "8px",
              width: "393px",
              paddingBottom: "100px",
              height: "154px",
              paddingLeft: "14px",
            }}
          />
        </div>
        <div
          className="flex justify-end py-5 gap-3"
          style={{ paddingRight: "365px" }}
        >
          <button
            className="bg-[#8B75F3] text-white w-[167px] h-[46px] rounded-xl"
            onClick={() => {
              if (arr.length <= position) return;
              setPosition((e) => {
                return e + 1;
              });
            }}
          >
            Save & Next
          </button>
        </div>

        {/* <Sidebar /> */}
      </div>
    </DashboardLayout>
  );
}
