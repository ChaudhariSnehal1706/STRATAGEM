import DashboardLayout from "./dashboard-layout";

const Page = () => {
  return (
    <DashboardLayout>
      <h1>Page</h1>
      <p>This is Page content.</p>
    </DashboardLayout>
  );
};

export default Page;
