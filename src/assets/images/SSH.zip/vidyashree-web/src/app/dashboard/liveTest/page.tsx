import Image from "next/image";
import Card from "./card";
import Mytests from "./mytests";
import Alltests from "./alltests";
import "./card.css";
import Recommendedtests from "./recommendedtests";
import DashboardLayout from "../dashboard-layout";
export default function LiveTest() {
  return (
    <DashboardLayout>
      <div>
        <p
          className="text-[24px] text-[#3C4852] font-bold py-10 px-10"
          style={{ marginLeft: 140 }}
        >
          Completed Series
        </p>
        <div className="flex px-40 ">
          <div className="py-6 shadow-2xl rounded-2xl px-2 ">
            <div className="w-[1037px] h-[197px]   py-5  flex overflow-x-scroll custom-scrollbar">
              <Card
                title="UPSC Prelims All India Live Test Series"
                status="Completed"
                details="40 questions l 60 Minutes l 40 Marks"
                date="15 Aug 9:00 AM to 17 Aug 21:00 PM"
                imageUrl="/images/test-img.png"
              />
              <Card
                title="UPSC Prelims All India Live Test Series"
                status="Completed"
                details="40 questions l 60 Minutes l 40 Marks"
                date="15 Aug 9:00 AM to 17 Aug 21:00 PM"
                imageUrl="/images/test-img.png"
              />

              <Card
                title="UPSC Prelims All India Live Test Series"
                status="Completed"
                details="40 questions l 60 Minutes l 40 Marks"
                date="15 Aug 9:00 AM to 17 Aug 21:00 PM"
                imageUrl="/images/test-img.png"
              />
              <Card
                title="UPSC Prelims All India Live Test Series"
                status="Completed"
                details="40 questions l 60 Minutes l 40 Marks"
                date="15 Aug 9:00 AM to 17 Aug 21:00 PM"
                imageUrl="/images/test-img.png"
              />
              <Card
                title="UPSC Prelims All India Live Test Series"
                status="Completed"
                details="40 questions l 60 Minutes l 40 Marks"
                date="15 Aug 9:00 AM to 17 Aug 21:00 PM"
                imageUrl="/images/test-img.png"
              />
            </div>
          </div>
        </div>
        <div>
          <p
            className="text-[24px] text-[#3C4852] font-bold mt-10"
            style={{ marginLeft: 170 }}
          >
            {" "}
            My Tests
          </p>
        </div>

        <div className="px-40">
          <div className="flex gap-4 mt-5 px-1 max-w[100%]  overflow-x-scroll ">
            <Mytests
              imageSrc="/images/Teacher3.png"
              title="UPSC Interview All India Live Test Series"
              details="40 questions l 60 Minutes l 40 Marks"
              date="15 Aug 9:00 AM to 17 Aug 21:00 PM"
            />
            <Mytests
              imageSrc="/images/Teacher3.png"
              title="UPSC Interview All India Live Test Series"
              details="40 questions l 60 Minutes l 40 Marks"
              date="15 Aug 9:00 AM to 17 Aug 21:00 PM"
            />
            <Mytests
              imageSrc="/images/Teacher3.png"
              title="UPSC Interview All India Live Test Series"
              details="40 questions l 60 Minutes l 40 Marks"
              date="15 Aug 9:00 AM to 17 Aug 21:00 PM"
            />
            <Mytests
              imageSrc="/images/Teacher3.png"
              title="UPSC Interview All India Live Test Series"
              details="40 questions l 60 Minutes l 40 Marks"
              date="15 Aug 9:00 AM to 17 Aug 21:00 PM"
            />
            <Mytests
              imageSrc="/images/Teacher3.png"
              title="UPSC Interview All India Live Test Series"
              details="40 questions l 60 Minutes l 40 Marks"
              date="15 Aug 9:00 AM to 17 Aug 21:00 PM"
            />
          </div>
        </div>
        <div>
          <p
            className="text-[24px] text-[#3C4852] font-bold  mt-10"
            style={{ marginLeft: 170 }}
          >
            {" "}
            All Tests
          </p>
        </div>

        <div className="px-40">
          <div className="flex gap-4 mt-6 max-w[100%] px-1 overflow-x-scroll">
            <Alltests
              imageSrc="/images/Teacher3.png"
              title="UPSC Interview All India Live Test Series"
              details="40 questions l 60 Minutes l 40 Marks"
              date="15 Aug 9:00 AM to 17 Aug 21:00 PM"
            />
            <Alltests
              imageSrc="/images/Teacher3.png"
              title="UPSC Interview All India Live Test Series"
              details="40 questions l 60 Minutes l 40 Marks"
              date="15 Aug 9:00 AM to 17 Aug 21:00 PM"
            />
            <Alltests
              imageSrc="/images/Teacher3.png"
              title="UPSC Interview All India Live Test Series"
              details="40 questions l 60 Minutes l 40 Marks"
              date="15 Aug 9:00 AM to 17 Aug 21:00 PM"
            />
            <Alltests
              imageSrc="/images/Teacher3.png"
              title="UPSC Interview All India Live Test Series"
              details="40 questions l 60 Minutes l 40 Marks"
              date="15 Aug 9:00 AM to 17 Aug 21:00 PM"
            />
          </div>
        </div>

        <div>
          <p
            className="text-[24px] text-[#3C4852]  font-bold  mt-10"
            style={{ marginLeft: 170 }}
          >
            Recommended Tests
          </p>
        </div>

        <div className="px-40">
          <div className="flex max-w[100%] mt-6 gap-4 px-1 overflow-x-scroll">
            <Recommendedtests
              imageSrc="/images/test-img.png"
              title="UPSC Interview All India Live Test Series"
              details="40 questions l 60 Minutes l 40 Marks"
              date="15 Aug 9:00 AM to 17 Aug 21:00 PM"
              buttonText="View Test Series"
            />
            <Recommendedtests
              imageSrc="/images/test-img.png"
              title="UPSC Interview All India Live Test Series"
              details="40 questions l 60 Minutes l 40 Marks"
              date="15 Aug 9:00 AM to 17 Aug 21:00 PM"
              buttonText="View Test Series"
            />
            <Recommendedtests
              imageSrc="/images/test-img.png"
              title="UPSC Interview All India Live Test Series"
              details="40 questions l 60 Minutes l 40 Marks"
              date="15 Aug 9:00 AM to 17 Aug 21:00 PM"
              buttonText="View Test Series"
            />
            <Recommendedtests
              imageSrc="/images/test-img.png"
              title="UPSC Interview All India Live Test Series"
              details="40 questions l 60 Minutes l 40 Marks"
              date="15 Aug 9:00 AM to 17 Aug 21:00 PM"
              buttonText="View Test Series"
            />
          </div>
        </div>
        <div>
          <p
            className="text-[24px] text-[#3C4852] font-bold ml-52 mt-10"
            style={{ marginLeft: 170 }}
          >
            {" "}
            Upcoming Exam Test
          </p>
        </div>

        <div className="px-40">
          <div className="flex max-w[100%] gap-4 mt-10 px-1 overflow-x-scroll">
            <Recommendedtests
              imageSrc="/images/test-img.png"
              title="UPSC Interview All India Live Test Series"
              details="40 questions l 60 Minutes l 40 Marks"
              date="15 Aug 9:00 AM to 17 Aug 21:00 PM"
              buttonText="View Test Series"
            />
            <Recommendedtests
              imageSrc="/images/test-img.png"
              title="UPSC Interview All India Live Test Series"
              details="40 questions l 60 Minutes l 40 Marks"
              date="15 Aug 9:00 AM to 17 Aug 21:00 PM"
              buttonText="View Test Series"
            />
            <Recommendedtests
              imageSrc="/images/test-img.png"
              title="UPSC Interview All India Live Test Series"
              details="40 questions l 60 Minutes l 40 Marks"
              date="15 Aug 9:00 AM to 17 Aug 21:00 PM"
              buttonText="View Test Series"
            />
            <Recommendedtests
              imageSrc="/images/test-img.png"
              title="UPSC Interview All India Live Test Series"
              details="40 questions l 60 Minutes l 40 Marks"
              date="15 Aug 9:00 AM to 17 Aug 21:00 PM"
              buttonText="View Test Series"
            />
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}
