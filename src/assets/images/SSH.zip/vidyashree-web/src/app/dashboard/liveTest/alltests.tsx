// TestSeriesCard.tsx
import React from "react";

interface TestSeriesCardProps {
  imageSrc: string;
  title: string;
  details: string;
  date: string;
}

const TestSeriesCard: React.FC<TestSeriesCardProps> = ({
  imageSrc,
  title,
  details,
  date,
}) => {
  return (
    <div className="min-w-[311px] min-h-[247px] shadow-2xl rounded-2xl">
      <div className="px-3 flex gap-2 py-3 items-center font-semibold text-[15px]">
        <img src={imageSrc} alt="" width={75} height={76} />
        <p>{title}</p>
      </div>
      <div className="py-3 px-3 text-[#778590] text-[14px]">
        <p>{details}</p>
        <p className="mt-2">{date}</p>
        <button className="w-[280px] h-[46px] bg-[#8B75F3] text-white font-semibold mt-6 rounded-xl">
          Buy Now
        </button>
      </div>
    </div>
  );
};

export default TestSeriesCard;
