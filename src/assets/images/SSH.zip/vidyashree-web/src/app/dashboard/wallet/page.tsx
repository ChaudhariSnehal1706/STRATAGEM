import DashboardLayout from "./../dashboard-layout";
import Image from "next/image";
const Wallet = () => {
  return (
    <DashboardLayout>
      <div className="w-full justify-center items-center ml-20 mr-20 mt-10">
        <p
          className="text-center text-[24px] mb-8 font-bold text-[#3C4852]"
          style={{ marginTop: "-80px" }}
        >
          Wallet Balance
        </p>
        <div className="w-full h-[132px] bg-[#F3F1FE] rounded-2xl">
          <p className="p-5 text-[#8B75F3] font-bold text-[32px]">
            Rs 12,980.09
          </p>
          <p
            className="ml-5 text-[#8B75F3] text-[16px]"
            style={{ marginTop: "-15px" }}
          >
            Current VidhyaShree Wallet Balance
          </p>
          <div className="flex justify-end">
            {/* <button className='w-[250px] h-[46px] bg-[#8B75F3] rounded-xl text-[white] mr-10'style={{marginTop:-40}}> <Image loading='lazy' src="../images/plus.png" alt=""  /> Add Money to Waitlist</button> */}
            <button
              className=" ml-10 bg-[#8B75F3] w-full max-w-[250px] h-[53px] text-[white] font-normal  "
              style={{
                borderRadius: "12px",
                paddingTop: 2,
                paddingLeft: 20,
                marginTop: -60,
                marginRight: 30,
              }}
            >
              Add Money to Waitlist
              <Image
                loading="lazy"
                src="/images/plus.png"
                alt=""
                width={16}
                height={16}
                style={{ marginTop: -21, marginLeft: 5, display: "flex" }}
              />
            </button>
          </div>
        </div>
        <div>
          <p className="py-10 text-[24px] text-[#3C4852] font-bold">
            {" "}
            Transcations
          </p>
        </div>
        <div
          className="flex justify-between w-full h-[70px] bg-[#F6F7F8] p-5 rounded-xl"
          style={{ marginTop: "-25px" }}
        >
          <p>Student</p>
          <p className="ml-8">Amount</p>
          <p className="mr-16">Status</p>
        </div>
        <div
          className=" flex justify-between w-full h-[470px] bg-[white] shadow-2xl p-5 rounded-xl"
          style={{ marginTop: "-2px" }}
        >
          {/* <div>
            <p>UPSC Course</p>
            <p>01 December,2023 . 5:21pm</p>

            <div className='mt-10'>
            <p>Received Reward</p>
            <p>01 December,2023 . 5:21pm</p>

          </div>

          <div className='mt-10'>
            <p>Received Reward</p>
            <p>01 December,2023 . 5:21pm</p>

          </div>

          <div className='mt-10'>
            <p>Received Reward</p>
            <p>01 December,2023 . 5:21pm</p>

          </div>

          <div className='mt-10'>
            <p>Received Reward</p>
            <p>01 December,2023 . 5:21pm</p>

          </div>

          </div>

          <div className='mr-40'>
            <p>Rs 500</p>

           <div className='mt-16'>
            <p>Rs 500</p>
            </div> 

            <div className='mt-16'>
            <p>Rs 500</p>
            </div>

            <div className='mt-16'>
            <p>Rs 500</p>
            </div>

            <div className='mt-20'>
            <p>Rs 500</p>
            </div>

            </div>
          

          <div>
            <p>Credited</p>
            <div>
            <p>Credited</p> 
            </div>
            

          </div> */}

          <div className="flex items-center" style={{ marginTop: -370 }}>
            <Image
              loading="lazy"
              src="/images/Group2.png"
              alt=""
              width="50"
              height="50"
            />
            <div className="flex-col ml-4 ">
              <p>UPSC Course</p>
              <p>01 December 2023 .5:21 pm</p>
            </div>
            <div className="flex items-center" style={{ marginLeft: -277 }}>
              <Image
                loading="lazy"
                src="/images/Group3.png"
                alt=""
                width={50}
                height={50}
                style={{ marginTop: 185 }}
              />
              <div className="flex-col  ml-4 " style={{ marginTop: 184 }}>
                <p>UPSC Course</p>
                <p>01 December 2023 .5:21 pm</p>
              </div>
            </div>

            <div className="flex items-center" style={{ marginLeft: -277 }}>
              <Image
                loading="lazy"
                src="/images/Group2.png"
                alt=""
                width="50"
                height="50"
                style={{ marginTop: 370 }}
              />
              <div className="flex-col ml-4 " style={{ marginTop: 364 }}>
                <p>UPSC Course</p>
                <p>01 December 2023 .5:21 pm</p>
              </div>
            </div>

            <div className="flex items-center" style={{ marginLeft: -277 }}>
              <Image
                loading="lazy"
                src="/images/Group2.png"
                alt=""
                width="50"
                height="50"
                style={{ marginTop: 555 }}
              />
              <div className="flex-col ml-4 " style={{ marginTop: 553 }}>
                <p>UPSC Course</p>
                <p>01 December 2023 .5:21 pm</p>
              </div>
            </div>

            <div className="flex items-center" style={{ marginLeft: -277 }}>
              <Image
                loading="lazy"
                src="/images/Group3.png"
                alt=""
                width={50}
                height={50}
                style={{ marginTop: 750 }}
              />
              <div className="flex-col ml-4 " style={{ marginTop: 750 }}>
                <p>UPSC Course</p>
                <p>01 December 2023 .5:21 pm</p>
              </div>
            </div>
          </div>
          <div style={{ marginRight: 185 }}>
            <p>Rs 500</p>
            <div className="mt-24">
              <p>Rs 500</p>
            </div>
            <div className="mt-16">
              <p>Rs 500</p>
            </div>
            <div className="mt-16">
              <p>Rs 500</p>
            </div>
            <div className="mt-20">
              <p>Rs 500</p>
            </div>
          </div>

          <div className="mr-14">
            <button
              className="bg-[#DFF2E0] text-[#06C302] text-[14px] w-[91px] h-[31px] rounded-lg"
              style={{ border: "1px solid #DFF2E0" }}
            >
              credited
            </button>
            <div className="mt-24">
              <button
                className="bg-[#DFF2E0] text-[#06C302] text-[14px] w-[91px] h-[31px] rounded-lg"
                style={{ border: "1px solid #DFF2E0" }}
              >
                credited
              </button>
            </div>
            <div className="mt-16">
              <button
                className="bg-[#FFFAE6] text-[#FFC700] text-[14px] w-[91px] h-[31px] rounded-lg"
                style={{ border: "1px solid #FFFAE6" }}
              >
                Processing
              </button>
            </div>
            <div className="mt-16">
              <button
                className="bg-[#DFF2E0] text-[#E90000] text-[14px] w-[91px] h-[31px] rounded-lg"
                style={{ border: "1px solid #FFFAE6" }}
              >
                Debited
              </button>
            </div>
            <div className="mt-14">
              <button
                className="bg-[#FFFAE6] text-[#FFC700] text-[14px] w-[91px] h-[31px] rounded-lg"
                style={{ border: "1px solid #DFF2E0" }}
              >
                Processing
              </button>
            </div>
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
};

export default Wallet;
