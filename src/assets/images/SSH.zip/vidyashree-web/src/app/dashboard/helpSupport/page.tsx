import DashboardLayout from "../dashboard-layout";
import Image from "next/image";
const HelpSupport = () => {
  return (
    <DashboardLayout>
      {/* <div className="flex justify-center">
      <div className="w-full ml-60 mr-60" >
        <div
          className="w-[1037px] h-[276px] bg-[#F9F8FE]"
          style={{ marginTop: 10 }}
        >
          <p className="px-80 py-5 text-center text-[40px] text-[#3C4852] font-bold">
            {" "}
            Get In Touch
          </p>
          <p className="px-8 text-[18px] text-[#778590] text-center">
            We highly respect your time and so, we are presenting simple forms
            with lesser but important fields.

            </p>
            <p className="px-8 text-[18px] text-[#778590] text-center">
              We highly respect your time and so, we are presenting simple forms
              with lesser but important fields.
            </p>
            <p className="px-8 text-[18px] text-[#778590] text-center">
              To capture your thoughts. Your complete and transparent
              information will Help Us Help You Better.
            </p>
            {/* <p className="px-11 text-[18px] text-[#778590] text-center">
            To capture your thoughts. Your complete and transparent information
            will Help Us Help You Better.
          </p> */}
      {/* </div>
        <div
          className="w-[95%] ml-[36px] h-[597px] bg-[#FFFFFF] shadow-2xl  rounded-2xl"
          style={{ marginTop: -60 }}
        >
          <div className="flex p-10">
            <p className="font-medium">Name</p>
            <div style={{ marginLeft: 350 }}>
              <p className="font-medium"> Email</p>
            </div>
          </div>
          <div>
            <input
              type="text"
              placeholder="Enter your name"
              style={{
                marginLeft: 30,
                marginTop: -40,
                width: 357,
                height: 54,
                border: "1px solid #C7C7C2",
                padding: 14,
                borderRadius: 8,
              }}
            />
          </div>
          <div className="flex">
            <input
              type="text"
              placeholder="Enter your Email"
              style={{
                marginLeft: 430,
                marginTop: -55,
                width: 357,
                height: 54,
                border: "1px solid #C7C7C2",
                padding: 14,
                borderRadius: 8,
              }}
            />

          </div>
          <div
            className="w-[95%] ml-[36px] h-[597px] bg-[#FFFFFF] shadow-2xl  rounded-2xl"
            style={{ marginTop: -60 }}
          >
            <div className="flex p-10">
              <p className="font-medium">Name</p>
              <div style={{ marginLeft: 350 }}>
                <p className="font-medium"> Email</p>
              </div>
            </div>
            <div>
              <input
                type="text"
                placeholder="Enter your name"
                style={{
                  marginLeft: 30,
                  marginTop: -40,
                  width: 357,
                  height: 54,
                  border: "1px solid #C7C7C2",
                  padding: 14,
                  borderRadius: 8,
                }}
              />
            </div>
            <div className="flex">
              <input
                type="text"
                placeholder="Enter your Email"
                style={{
                  marginLeft: 430,
                  marginTop: -55,
                  width: 357,
                  height: 54,
                  border: "1px solid #C7C7C2",
                  padding: 14,
                  borderRadius: 8,
                }}
              />
            </div>
            <div className="flex p-10">
              <p className="font-medium">Mobile Number</p>
              <div style={{ marginLeft: 270 }}>
                <p className="font-medium"> Subject</p>
              </div>
            </div>
            <div>
              <input
                type="text"
                placeholder="Enter your Mobile Number"
                style={{
                  marginLeft: 30,
                  marginTop: -40,
                  width: 357,
                  height: 54,
                  border: "1px solid #C7C7C2",
                  padding: 14,
                  borderRadius: 8,
                }}
              />
            </div>
            <div className="flex">
              <input
                type="text"
                placeholder="Enter your Subject"
                style={{
                  marginLeft: 430,
                  marginTop: -55,
                  width: 357,
                  height: 54,
                  border: "1px solid #C7C7C2",
                  padding: 14,
                  borderRadius: 8,
                }}
              />
            </div>

            <div className="flex p-10">
              <p className="font-medium">Message</p>
            </div>
            <div>
              <input
                type="text"
                placeholder="Message Here"
                style={{
                  marginLeft: 30,
                  marginTop: -20,
                  width: 770,
                  height: 131,
                  border: "1px solid #C7C7C2",
                  padding: 14,
                  borderRadius: 8,
                }}
              />
            </div>
            <div className="flex ml-96 mt-8 ">
              <button className="bg-[#8B75F3] w-[174px] h-[48px] rounded-xl text-[white]">
                Send Message{" "}
              </button>
            </div>
          </div>

          <div className="w-full h-[231px] text-center bg-[#F9F8FE] mt-7 rounded-2xl">
            <div className="flex justify-center text-[#8B75F3] font-semibold text-[24px]">
              <p className="p-10 "> Reach Out To Us Directly</p>
            </div>
            <div className=" flex gap-6 items-center justify-center">
              <Image
                loading="lazy"
                src="/images/message1.png"
                alt=""
                width={24}
                height={24}
              ></Image>
              <p className="text-center">care@vidhyashree</p>
              <Image
                loading="lazy"
                src="/images/india.png"
                alt=""
                width={24}
                height={24}
              ></Image>
              <p className="text-center">+91 9090909090</p>
            </div>
            <div style={{ marginTop: 16 }} className="justify-center">
              <p className="text-[#8B75F3] text-[16px]  "> Follow Us</p>
            </div>
            <div className="flex gap-4 items-center mt-3 justify-center">
              <Image
                loading="lazy"
                src="/images/Facebook1.png"
                alt=""
                width={24}
                height={24}
              />
              <Image
                loading="lazy"
                src="/images/insta1.png"
                alt=""
                width={24}
                height={24}
              />
              <Image
                loading="lazy"
                src="/images/link1.png"
                alt=""
                width={24}
                height={24}
              />
              <Image
                loading="lazy"
                src="/images/You.png"
                alt=""
                width={24}
                height={24}
              />
            </div>
          </div>
        </div> */}
      {/* </div> */}
      {/* </div>  */}

      <div className="w-[100dvw] flex flex-col items-center  ">
        <div className="min-w-[1037px] min-h-[276px] bg-[#F9F8FE] flex flex-col items-center rounded-2xl ">
          <p className="text-[40px] font-bold text-[#3C4852] mt-5">
            Get in Touch
          </p>
          <div className="text-[18px] text-[#778590] mt-5">
            <p>
              We highly respect your time and so, we are presenting simple forms
              with lesser but important fields
            </p>
            <p>
              To capture your thoughts. Your complete and transparent
              information will Help Us Help You Better.
            </p>
          </div>
        </div>
        {/* <div className="w-[940px] h-[597px] rounded-2xl shadow-2xl mt-[-60px] bg-[white]">
          <div className="flex">
            <p className="px-[30px] py-10">Name</p>
            <p className="px-[350px] py-10">Email</p>
          </div>
          <div className="lg:flex">
            <input type="text" placeholder="Enter your name" className="ml-[30px] mt-[-30px] w-[357px] h-[54px] px-4 rounded-lg" style={{
              border: "1px solid #C7C7C2"
            }} />

            <input type="text" placeholder="Enter your Email" style={{
              marginLeft: 69,
              marginTop: -30,
              width: 357,
              height: 54,
              border: "1px solid #C7C7C2",
              padding: 14,
              borderRadius: 8,
            }} />
          </div>

          <div className="flex">
            <p className="px-[30px] py-10">MobileNumber</p>
            <p className="px-[280px] py-10">Subject</p>
          </div>
          <div className="flex">
            <input type="text" placeholder="Enter your mobile number" style={{
              marginLeft: 30,
              marginTop: -30,
              width: 357,
              height: 54,
              border: "1px solid #C7C7C2",
              padding: 14,
              borderRadius: 8,
            }} />

            <input type="text" placeholder="Enter Subject" style={{
              marginLeft: 69,
              marginTop: -30,
              width: 357,
              height: 54,
              border: "1px solid #C7C7C2",
              padding: 14,
              borderRadius: 8,
            }} />
          </div>
          <div className="flex">
            <p className="px-[30px] py-10">Message</p>
          </div>

          <div className="flex">
            <input type="text" placeholder="Message here" style={{
              marginLeft: 30,
              marginTop: -30,
              width: 770,
              height: 131,
              border: "1px solid #C7C7C2",
              padding: 14,
              borderRadius: 8,
            }} />
          </div>
          <div className="flex justify-center mt-5">
            <button className="w-[174px] h-[48px] text-[white] bg-[#8B75F3] rounded-xl">Send Message</button>
          </div>
        </div>  */}
        <div className="max-w-[940px] min-h-[597px] rounded-2xl shadow-2xl mt-[-60px] bg-[white]">
          <div className="flex flex-wrap">
            <div className=" flex flex-col sm:flex sm:flex-col sm:justify-center md:flex-col  lg:flex lg:flex-col py-10 px-[30px]  md:w-1/2">
              <label htmlFor="name" className="mb-2 px-[30px]">
                Name
              </label>
              <input
                type="text"
                id="name"
                placeholder="Enter your name"
                className="rounded-md ml-6 px-3 py-2 mb-4 w-[357px] h-[54px]"
                style={{ border: "1px solid #C7C7C2" }}
              />
            </div>
            <div className="flex flex-col w-full py-10 px-[30px]  md:w-1/2 md:pl-4">
              <label htmlFor="email" className="mb-2">
                Email
              </label>
              <input
                type="email"
                id="email"
                placeholder="Enter your email"
                className="border border-gray-300 rounded-md px-3 py-2 mb-4 w-[357px] h-[54px]"
                style={{ border: "1px solid #C7C7C2" }}
              />
            </div>
            <div className="flex flex-col  mt-[-50px] py-10 px-[55px] md:w-1/2">
              <label htmlFor="password" className="mb-2">
                Password
              </label>
              <input
                type="password"
                id="password"
                placeholder="Enter your password"
                className="border border-gray-300 rounded-md px-3 py-2 mb-4 w-[357px] h-[54px]"
                style={{ border: "1px solid #C7C7C2" }}
              />
            </div>
            <div className="flex flex-col w-full mt-[-50px] md:w-1/2 md:pl-4 py-10 px-[30px] ">
              <label htmlFor="subject" className="mb-2">
                Subject
              </label>
              <input
                type="text"
                id="subject"
                placeholder="Enter subject"
                className="border border-gray-300 rounded-md px-3 py-2 mb-4  w-[357px] h-[54px]"
                style={{ border: "1px solid #C7C7C2" }}
              />
            </div>

            <div className="flex flex-col w-full mt-[-50px] py-10 px-[55px]">
              <label htmlFor="password" className="mb-2">
                Message
              </label>
              <input
                type="password"
                id="password"
                placeholder="Enter your password"
                className="border border-gray-300 rounded-md px-3 py-2 mb-4 w-[770px] h-[131px]"
                style={{ border: "1px solid #C7C7C2" }}
              />
            </div>
            <div className="flex justify-center w-full">
              <button className="w-[174px] h-[48px] text-[white] bg-[#8B75F3] rounded-xl">
                Send Message
              </button>
            </div>
          </div>
        </div>

        <div className="w-[941px] h-[231px] rounded-2xl mt-7 bg-[#F9F8FE] flex flex-col items-center">
          <p className="mt-10 text-[24px] text-[#8B75F3]">
            Reach out to us Directly
          </p>
          <div className=" flex gap-6 items-center  mt-5">
            <Image
              loading="lazy"
              src="/images/message1.png"
              alt=""
              width={24}
              height={24}
            ></Image>
            <p className="text-center">care@vidhyashree</p>
            <Image
              loading="lazy"
              src="/images/india.png"
              alt=""
              width={24}
              height={24}
            ></Image>
            <p className="text-center">+91 9090909090</p>
          </div>
          <div style={{ marginTop: 16 }} className="justify-center">
            <p className="text-[#8B75F3] text-[16px]  "> Follow Us</p>
          </div>
          <div className="flex gap-4 items-center mt-3 justify-center">
            <Image
              loading="lazy"
              src="/images/Facebook1.png"
              alt=""
              width={24}
              height={24}
            />
            <Image
              loading="lazy"
              src="/images/insta1.png"
              alt=""
              width={24}
              height={24}
            />
            <Image
              loading="lazy"
              src="/images/link1.png"
              alt=""
              width={24}
              height={24}
            />
            <Image
              loading="lazy"
              src="/images/You.png"
              alt=""
              width={24}
              height={24}
            />
          </div>
        </div>

        <div></div>
        {/* <div  className="max-w-[940px] min-h-[597px] rounded-2xl shadow-2xl mt-[-60px] bg-[white]">
       
<div className="flex items-center flex-wrap">
  <div className="flex flex-col py-10 px-[30px]  md:w-1/2">
    <label htmlFor="name" className="mb-2 px-[30px]">Name:</label>
    <input type="text" id="name" placeholder="Enter your name" className="rounded-md ml-6 px-3 py-2 mb-4 w-[357px] h-[54px]" style={{border:'1px solid #C7C7C2'}}/>
  </div>
  <div className="flex flex-col w-full py-10 px-[30px]  md:w-1/2 md:pl-4">
    <label htmlFor="email" className="mb-2">Email:</label>
    <input type="email" id="email" placeholder="Enter your email" className="border border-gray-300 rounded-md px-3 py-2 mb-4 w-[357px] h-[54px]" style={{border:'1px solid #C7C7C2'}}/>
  </div>
  <div className="flex flex-col  mt-[-50px] py-10 px-[55px] md:w-1/2">
    <label htmlFor="password" className="mb-2">Password:</label>
    <input type="password" id="password" placeholder="Enter your password" className="border border-gray-300 rounded-md px-3 py-2 mb-4 w-[357px] h-[54px]" style={{border:'1px solid #C7C7C2'}} />
  </div>
  <div className="flex flex-col w-full mt-[-50px] md:w-1/2 md:pl-4 py-10 px-[30px] ">
    <label htmlFor="subject" className="mb-2">Subject:</label>
    <input type="text" id="subject" placeholder="Enter subject" className="border border-gray-300 rounded-md px-3 py-2 mb-4  w-[357px] h-[54px]"style={{border:'1px solid #C7C7C2'}} />
  </div>

  <div className="flex flex-col w-full mt-[-50px] py-10 px-[55px]">
    <label htmlFor="password" className="mb-2">Password:</label>
    <input type="password" id="password" placeholder="Enter your password" className="border border-gray-300 rounded-md px-3 py-2 mb-4 w-[770px] h-[131px]" style={{border:'1px solid #C7C7C2'}} />

  </div>
  <div className="">
  <button className="w-[174px] h-[48px] text-[white] bg-[#8B75F3] rounded-xl">Send Message</button>
  </div>
  
  

 
</div>



        </div> */}
      </div>
    </DashboardLayout>
  );
};

export default HelpSupport;
