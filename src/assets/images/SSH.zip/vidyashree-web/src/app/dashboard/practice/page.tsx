import ReusableCard from "@/app/components/practice/card";
import DashboardLayout from "../dashboard-layout";
const Practice = () => {
  const cardData = [
    { key: "1", title: "Maths" },
    { key: "2", title: "Geography" },
    { key: "3", title: "Science" },
    { key: "4", title: "English" },
  ];
  return (
    <DashboardLayout>
      <div className="w-full">
        <div>
          <p className="ml-[450px] mt-10 text-[#3C4852] font-bold text-[24px]">
            {" "}
            UPSC Practice Test
          </p>
        </div>
        <div className="flex  flex-wrap justify-center mt-6 gap-10">
          {cardData.map((card) => (
            <ReusableCard key={card.key} title={card.title} />
          ))}
        </div>
        <div className="flex gap-10 flex-wrap  justify-center mt-3">
          {cardData.map((card) => (
            <ReusableCard key={card.key} title={card.title} />
          ))}
        </div>
        <div>
          <p className="ml-[450px] mt-10 font-bold text-[#3C4852] text-[24px]">
            {" "}
            Current Affairs
          </p>
        </div>
        <div className="flex gap-10 justify-center mt-3 flex-wrap">
          {cardData.map((card) => (
            <ReusableCard key={card.key} title={card.title} />
          ))}
        </div>
        <div>
          <p className="ml-[450px] mt-10 font-bold text-[#3C4852] text-[24px] flex ">
            {" "}
            NCERT Summary
          </p>
        </div>
        <div className="flex gap-10 justify-center mt-3 flex-wrap">
          {cardData.map((card) => (
            <ReusableCard key={card.key} title={card.title} />
          ))}
        </div>
      </div>
    </DashboardLayout>
  );
};
export default Practice;
