import DashboardLayout from "../dashboard-layout";
import Image from "next/image";
const ReferAndEarn = () => {
  return (
    <DashboardLayout>
      {/* <div className="">
        <div
          className=" w-full text-[24px] font-bold flex "
          style={{ marginTop: "40px" , marginLeft:"300px"}}
        >
          Refer and Earn
          <Image
            loading="lazy"
            src="/images/hello2.png"
            alt=""
            width={"474"}
            height={"474"}
            style={{ marginLeft: "-210px" }}
          ></Image> */}
      {/* <div className='mt-40 px-52 w-[412px] h-[212px] bg-[#FFFFFF] shadow-2xl ml-32'>
                <Image loading='lazy' src='/images/Ellipse 230.png'  alt='' width={66} height={66}></Image>
                   <div className='flex-col justify-center'>
                    
                    <p className='text-[20px] font-semibold text-[#3C4852]' > UserName </p>
                    <p className='text-[12px] text-[#778590]'>Student</p>
                    <p className='text-[12px] text-[#778590]'> sharevia<hr /></p>
                   </div>

                </div> */}
      {/* <div className="w-[412px] h-[212px] bg-[#FFFFFF] shadow-2xl ml-32 mt-32">
            <div className="flex">
              <Image
                loading="lazy"
                src="/images/Ellipse 230.png"
                alt=""
                width={66}
                height={66}
                style={{ marginLeft: 15, marginTop: 15 }}
              ></Image> */}
      {/* <p className="mt-6 text-[20px] text-[#3C4852] font-semibold">
                {" "}
                User Name
              </p>
            </div>
            <div
              className="ml-20 text-[12px] text-[#778590]"
              style={{ marginTop: -30 }}
            > */}
      {/* <p> student </p>
            </div>
            <div>
              <p className="px-8 py-3 text-[12px] text-[#778590]">
                {" "}
                share via{" "}
                <hr
                  className="ml-20 border-2 text-[#778590]"
                  style={{ marginTop: -9 }}
                />{" "}
              </p>
            </div> */}

      {/* <div
              className="flex items-center"
              style={{
                border: "dotted",
                color: "#C7C7C2",
                width: 155,
                height: 38,
                marginTop: 10,
                marginLeft: 30,
              }}
            >
              <p className="text-[14px] font-semibold px-3 py-2 text-[black]">
                lorenzo2567
              </p>
              <Image
                loading="lazy"
                src="/images/copy.png"
                alt=""
                width={23}
                height={23}
                style={{ marginLeft: 8 }}
              ></Image>
              <div className="flex">
                <Image
                  loading="lazy"
                  src="/images/whatsapp.png"
                  alt=""
                  width={28}
                  height={28}
                  style={{ marginLeft: 90 }}
                ></Image>
                <Image
                  loading="lazy"
                  src="/images/mail.png"
                  alt=""
                  width={28}
                  height={28}
                  style={{ marginLeft: 20 }}
                ></Image>
              </div>
            </div>
          </div>
        </div> */}
      {/* <div className="">
          <div className="flex px-48">
          <p className="text-[24px] text-[#3C4852] font-bold"> How it Works</p>
          </div>
          <div className="flex justify-center">
            <Image
              loading="lazy"
              src="/images/Group4.png"
              alt=""
              width={474}
              height={474}
            ></Image>
            <div className="w-[412px] h-[314px] bg-[#FFFFFF] shadow-2xl ml-24">
              <div className="flex py-10 px-5 h-80">
                <Image
                  loading="lazy"
                  src="/images/one.png"
                  alt=""
                  width={24}
                  height={24}
                ></Image>
                <div className="flex-col">
                  <p
                    className="px-2 text-[16px] text-[#3C4852] font-semibold"
                    style={{ marginLeft: "" }}
                  >
                    {" "}
                    Share code
                  </p>
                  <p
                    className="px-2 text-[16px] text-[#778590]"
                    style={{ marginLeft: "" }}
                  >
                    {" "}
                    Student uses code to register
                  </p>
                  <div>
                    <p className="py-14 px-2 text-[16px] font-semibold">
                      {" "}
                      User got a discount
                    </p>
                    <p
                      className="px-2 text-[#778590]"
                      style={{ marginTop: -54 }}
                    >
                      75% off up to Rs 500 on 1st Course
                    </p>
                  </div>
                  <div>
                    <p
                      className="py-2 px-2 text-[16px] font-semibold"
                      style={{ marginTop: 50 }}
                    >
                      {" "}
                      You get rewards
                    </p>
                    <p
                      className="px-2 text-[#778590]"
                      style={{ marginTop: -8 }}
                    >
                      Everytime student reaches on milestone
                    </p>
                  </div>
                </div>
              </div> */}

      {/* 
                        <p className='px-16 text-[16px] text-[#778590]' style={{marginTop:'-90px'}}> student uses your code to register</p>
                        <p className='px-16 py-5 text-[#3C4852] font-semibold mt-5'> User got a discount</p>
                        <p className='px-16 text-[16px] text-[#778590]' style={{marginTop:'-90px'}}>75% off up to Rs 500 on 1st Course</p>
                        <p className='px-16 py-5 text-[#3C4852] font-semibold mt-5'> You get rewards</p>
                        <p className='px-16 text-[16px] text-[#778590]' style={{marginTop:'-90px'}}> Every time Student reaches on milestone  </p> */}
      {/* </div>
          </div>
        </div>
      </div> */}
      {/* <div> */}
      <p className="mt-10 flex justify-center sm:px-60 sm:mt-10 md:px-60 text-[24px] text-[#3C4852] font-bold">
        Refer and Earn{" "}
      </p>
      <div className="ml-40 md:flex sm:flex-col md:flex-row">
        <Image src="/images/hello2.png" alt="" width={474} height={474}></Image>
        <div className=" sm:mt-[20px] sm:w-[412px] sm:ml-14  max-w-[412px] max-h-[212px] shadow-2xl md:ml-36  md:mt-32 px-2 py-2 flex items-start ">
          <Image
            src="/images/Ellipse 230.png"
            alt=""
            width={66}
            height={66}
          ></Image>
          <div className="flex-col">
            <p className="px-2 py-4"> UserName</p>
            <p
              className="text-[12px] px-2 text-[#778590]"
              style={{ marginTop: -18 }}
            >
              Student
            </p>
            <div
              className="flex mt-4 text-[12px] text-[#778590]"
              style={{ marginLeft: -50 }}
            >
              <p> share via </p>
              <div
                className="flex mt-10 items-center"
                style={{
                  border: "dotted",
                  color: "#C7C7C2",
                  width: 155,
                  height: 38,
                  marginLeft: -55,
                }}
              >
                <p className="text-[14px] font-semibold px-3 py-2 text-[black]">
                  lorenzo2567
                </p>
                <div
                  className="flex mt-4 text-[12px] text-[#778590]"
                  style={{ marginLeft: -50 }}
                >
                  <p> share via </p>
                  <div
                    className="flex mt-10 items-center"
                    style={{
                      border: "dotted",
                      color: "#C7C7C2",
                      width: 155,
                      height: 38,
                      marginLeft: -55,
                    }}
                  >
                    <p className="text-[14px] font-semibold px-3 py-2 text-[black]">
                      lorenzo2567
                    </p>
                    <Image
                      loading="lazy"
                      src="/images/copy.png"
                      alt=""
                      width={23}
                      height={23}
                      style={{ marginLeft: 8 }}
                    ></Image>
                    <div className="flex">
                      <Image
                        loading="lazy"
                        src="/images/whatsapp.png"
                        alt=""
                        width={28}
                        height={28}
                        style={{ marginLeft: 90 }}
                      ></Image>
                      <Image
                        loading="lazy"
                        src="/images/mail.png"
                        alt=""
                        width={28}
                        height={28}
                        style={{ marginLeft: 20 }}
                      ></Image>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* <div className='mt-40 px-52 w-[412px] h-[212px] bg-[#FFFFFF] shadow-2xl ml-32'>
                <Image loading='lazy' src='/images/Ellipse 230.png'  alt='' width={66} height={66}></Image>
                   <div className='flex-col justify-center'>
                    
                    <p className='text-[20px] font-semibold text-[#3C4852]' > UserName </p>
                    <p className='text-[12px] text-[#778590]'>Student</p>
                    <p className='text-[12px] text-[#778590]'> sharevia<hr /></p>
                   </div>
                   </div> */}
          </div>
          <div className="">
            <div className="mt-10 flex justify-center sm:px-60 sm:mt-10 md:px-60">
              <p className=" text-[24px] text-[#3C4852] font-bold">
                {" "}
                How it Works
              </p>
            </div>
            <div className=" sm:mt-4 md:flex ml-56">
              <Image
                loading="lazy"
                src="/images/Group4.png"
                alt=""
                width={474}
                height={474}
              ></Image>
              <div className=" sm:ml-6 sm: mt-4 min-w-[412px] h-[314px] bg-[#FFFFFF] shadow-2xl md:ml-24 md:mt-[-16px] lg:mt-[-16px]">
                <div className=" px-3 flex sm:flex sm:py-10 sm:px-3 md:flex md:py-10 md:px-3 lg:flex lg:px-3 ">
                  <Image
                    loading="lazy"
                    src="/images/one.png"
                    alt=""
                    width={24}
                    height={24}
                  ></Image>
                  <div className="flex-col">
                    <p
                      className="px-2 text-[16px] text-[#3C4852] font-semibold"
                      style={{ marginLeft: "" }}
                    >
                      {" "}
                      Share code
                    </p>
                    <p
                      className="px-2 text-[16px] text-[#778590]"
                      style={{ marginLeft: "" }}
                    >
                      {" "}
                      Student uses code to register
                    </p>
                    <div>
                      <p className="py-14 px-2 text-[16px] font-semibold">
                        {" "}
                        User got a discount
                      </p>
                      <p
                        className="px-2 text-[#778590]"
                        style={{ marginTop: -54 }}
                      >
                        75% off up to Rs 500 on 1st Course
                      </p>
                    </div>
                    <div>
                      <p
                        className="py-2 px-2 text-[16px] font-semibold"
                        style={{ marginTop: 50 }}
                      >
                        {" "}
                        You get rewards
                      </p>
                      <p
                        className="px-2 text-[#778590]"
                        style={{ marginTop: -8 }}
                      >
                        Everytime student reaches on milestone
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
};

export default ReferAndEarn;
