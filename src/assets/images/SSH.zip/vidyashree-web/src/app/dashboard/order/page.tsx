import DashboardLayout from "../dashboard-layout";
import Image from "next/image";
const Page1 = () => {
  return (
    <DashboardLayout>
      {/* <div className="w-full ml-10 mr-10 mt-20">
        <p
          className="px-7  text-[24px] font-bold text-[#3C4852]"
          style={{ marginTop: "-50px" }}
        >
          {" "}
          Purchased Courses
        </p>
        <div className="w-full h-[305px] mt-5 bg-[#FFFFFF] rounded-2xl shadow-2xl">
          <div className="flex mb-4">
            <Image
              loading="lazy"
              src="/images/groups.png"
              width={250}
              height={250}
              alt=""
              style={{ marginLeft: "10px", paddingTop: "12px" }}
            ></Image>
            <div className="flex-col">
              <p className="mt-5 ml-5 text-[24px] text-[#3C4852] font-semibold">
                UPSC Interview All India Live Test Series{" "}
                <button
                  className="text-[14px] bg-[lightgreen] text-[#37CF10] rounded-xl w-[95px] h-[29px] ml-[840px]"
                  style={{ border: "1px solid #37CF10" }}
                >
                  Purchased
                </button>
              </p>

              <div className="flex-col ml-5 mt-5">
                <p className="text-[16px] text-[#778590]">
                  12 lessons .40 hours
                </p>
                <div>
                  <p className="text-[16px] text-[#778590] mt-5">
                    Lorem Ipsum is simply dummy text of the printing and
                    typesetting industry. Lorem Ipsum has been the industry
                    standard dummy text ever since the 1500s, Lorem Ipsum is
                    simply dummy text of the printing and typesetting industry.
                    Lorem Ipsum has been the industry standard dummy text ever
                    since the 1500s,
                  </p>
                  <div>
                    <button className="w-[250px] h-[46px] rounded-xl bg-[#8B75F3] text-[#FFFFFF] mt-6">
                      View Test
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="w-full h-[297px] ml-0 mt-10 bg-[#FFFFFF] rounded-2xl shadow-2xl">
            <div className="flex">
              <Image
                loading="lazy"
                src="/images/groups.png"
                width={250}
                height={250}
                alt=""
                style={{ marginLeft: "10px", paddingTop: "12px" }}
              ></Image>
              <div className="flex-col">
                <p className="mt-5 ml-5 text-[24px] text-[#3C4852] font-semibold">
                  UPSC Interview All India Live Test Series{" "}
                  <button
                    className="text-[14px] bg-[lightgreen] text-[#37CF10] rounded-xl w-[95px] h-[29px] ml-[840px]"
                    style={{ border: "1px solid #37CF10" }}
                  >
                    Purchased
                  </button>
                </p>

                <div className="flex-col ml-5 mt-5">
                  <p className="text-[16px] text-[#778590]">
                    12 lessons .40 hours
                  </p>
                  <div>
                    <p className="text-[16px] text-[#778590] mt-5">
                      Lorem Ipsum is simply dummy text of the printing and
                      typesetting industry. Lorem Ipsum has been the industry
                      standard dummy text ever since the 1500s, Lorem Ipsum is
                      simply dummy text of the printing and typesetting
                      industry. Lorem Ipsum has been the industry standard dummy
                      text ever since the 1500s,
                    </p>
                    <div>
                      <button className="w-[250px] h-[46px] rounded-xl bg-[#8B75F3] text-[#FFFFFF] mt-6">
                        View Test
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div> */}

      {/* <div> */}

      <p
        className="flex justify-center text-[24px] font-bold text-[#3C4852] "
        style={{ marginTop: "50px" }}
      >
        {" "}
        Purchased Courses
      </p>
      <div className=" w-[100dvw] flex justify-center">
        <div className="max-w-[1000px] min-h-[277px]  mt-4 bg-[#FFFFFF] rounded-2xl shadow-2xl ">
          <div className=" items-center flex-col  flex sm:flex-col  sm:py-5  md:flex-row md:items-start lg:flex-row   ">
            <Image
              src="/images/groups.png"
              width={250}
              height={250}
              alt="course video image"
              className=" mt-2 sm:ml-3 md:ml-3 lg:ml-3 "
            ></Image>
            <div className="flex-col">
              <p className="mt-2 ml-2 text-[24px] text-[#3C4852] font-semibold">
                UPSC Interview All India Live Test Series{" "}
                <button
                  className="sm:ml-[50px] text-[14px] bg-[lightgreen] text-[#37CF10] rounded-xl w-[95px] h-[29px] md:ml-10 lg:ml-[140px]"
                  style={{ border: "1px solid #37CF10" }}
                >
                  Purchased
                </button>{" "}
              </p>
              <div></div>

              <div className="flex-col ml-2 mt-2 ">
                <p className="text-[16px]  text-[#778590]">
                  12 lessons .40 hours
                </p>
                <div>
                  <p className="text-[16px] text-[#778590] mt-5">
                    Lorem Ipsum is simply dummy text of the printing and
                    typesetting industry. Lorem Ipsum has been the
                    industry&apos;s standard dummy text ever since the 1500s,
                    Lorem Ipsum is simply dummy text of the printing and
                    typesetting industry. Lorem Ipsum has been the
                    industry&apos;s standard dummy text ever since the 1500s,
                  </p>
                  <div className="flex gap-4 justify-center sm:justify-center t md:justify-start lg:justify-start">
                    <button className=" w-[250px] h-[46px] rounded-xl bg-[#8B75F3]  sm:bg-[#8B75F3] md:bg-[#8B75F3] text-[#FFFFFF] mt-6   ">
                      View Test
                    </button>

                    <div className="flex-col ml-2 mt-4">
                      <p className="text-[16px]  text-[#778590]">
                        12 lessons .40 hours
                      </p>
                      <div>
                        <p className="text-[16px] text-[#778590] mt-5">
                          Lorem Ipsum is simply dummy text of the printing and
                          typesetting industry. Lorem Ipsum has been the
                          industry&apos;s standard dummy text ever since the
                          1500s, Lorem Ipsum is simply dummy text of the
                          printing and typesetting industry. Lorem Ipsum has
                          been the industry&apos;s standard dummy text ever
                          since the 1500s,
                        </p>
                        <div className="flex gap-4">
                          <button className="w-[250px] h-[46px] rounded-xl bg-[#8B75F3] text-[#FFFFFF] mt-6">
                            View Test
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className=" w-[100dvw] flex justify-center">
        <div className="max-w-[1000px] min-h-[277px]  mt-4 bg-[#FFFFFF] rounded-2xl shadow-2xl ">
          <div className=" items-center flex-col  flex sm:flex-col  sm:py-5  md:flex-row md:items-start lg:flex-row   ">
            <Image
              src="/images/groups.png"
              width={250}
              height={250}
              alt="course video image"
              className=" mt-2 sm:ml-3 md:ml-3 lg:ml-3 "
            ></Image>
            <div className="flex-col">
              <p className="mt-2 ml-2 text-[24px] text-[#3C4852] font-semibold">
                UPSC Interview All India Live Test Series{" "}
                <button
                  className="sm:ml-[50px] text-[14px] bg-[lightgreen] text-[#37CF10] rounded-xl w-[95px] h-[29px] md:ml-10 lg:ml-[140px]"
                  style={{ border: "1px solid #37CF10" }}
                >
                  Purchased
                </button>{" "}
              </p>
              <div></div>

              <div className="flex-col ml-2 mt-2">
                <p className="text-[16px]  text-[#778590]">
                  12 lessons .40 hours
                </p>
                <div>
                  <p className="text-[16px] text-[#778590] mt-5">
                    Lorem Ipsum is simply dummy text of the printing and
                    typesetting industry. Lorem Ipsum has been the
                    industry&apos;s standard dummy text ever since the 1500s,
                    Lorem Ipsum is simply dummy text of the printing and
                    typesetting industry. Lorem Ipsum has been the
                    industry&apos;s standard dummy text ever since the 1500s,
                  </p>
                  <div className="flex gap-4 justify-center sm:justify-center t md:justify-start lg:justify-start">
                    <button className=" w-[250px] h-[46px] rounded-xl bg-[#8B75F3]  sm:bg-[#8B75F3] md:bg-[#8B75F3] text-[#FFFFFF] mt-6   ">
                      View Test
                    </button>

                    <div className="flex-col ml-2 mt-4">
                      <p className="text-[16px]  text-[#778590]">
                        12 lessons .40 hours
                      </p>
                      <div>
                        <p className="text-[16px] text-[#778590] mt-5">
                          Lorem Ipsum is simply dummy text of the printing and
                          typesetting industry. Lorem Ipsum has been the
                          industry&apos;s standard dummy text ever since the
                          1500s, Lorem Ipsum is simply dummy text of the
                          printing and typesetting industry. Lorem Ipsum has
                          been the industry&apos;s standard dummy text ever
                          since the 1500s,
                        </p>
                        <div className="flex gap-4">
                          <button className="w-[250px] h-[46px] rounded-xl bg-[#8B75F3] text-[#FFFFFF] mt-6">
                            View Test
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
};

export default Page1;
