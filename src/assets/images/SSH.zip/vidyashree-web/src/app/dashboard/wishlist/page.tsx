import DashboardLayout from "../dashboard-layout";
import Image from "next/image";
const Wishlist = () => {
  return (
    <DashboardLayout>
      {/* <div className="w-full ml-20 mr-20 mt-20">
        <p
          className=" text-[24px] font-bold text-[#3C4852]"
          style={{ marginTop: "-50px" }}
        >
          {" "}
          Purchased Courses
        </p>
        <div className="w-full h-[277px] mt-2 bg-[#FFFFFF] rounded-2xl shadow-2xl">
          <div className="flex">
            <Image
              loading="lazy"
              src="/images/groups.png"
              width={250}
              height={200}
              alt=""
              style={{ marginLeft: "10px", paddingTop: "12px" }}
            ></Image>
            <div className="flex-col">
              <p className="mt-5 ml-5 text-[24px] text-[#3C4852] font-semibold">
                UPSC Interview All India Live Test Series{" "}
              </p>
              <div>
                <Image
                  loading="lazy"
                  src="/images/delete.png"
                  alt=""
                  width={20}
                  height={20}
                  style={{ marginLeft: 1350, marginTop: -30 }}
                />
              </div>

              <div className="flex-col ml-5 mt-5">
                <p className="text-[16px] text-[#778590]">
                  12 lessons .40 hours
                </p>
                <div className="mr-20">
                  <p className="text-[16px] text-[#778590] mt-5">
                    Lorem Ipsum is simply dummy text of the printing and
                    typesetting industry. Lorem Ipsum has been the industry
                    standard dummy text ever since the 1500s, Lorem Ipsum is
                    simply dummy text of the printing and typesetting industry.
                    Lorem Ipsum has been the industry standard dummy text ever
                    since the 1500s,
                  </p>
                  <div className="flex gap-4">
                    <button className="w-[250px] h-[46px] rounded-xl bg-[#8B75F3] text-[#FFFFFF] mt-6">
                      View Test Series
                    </button>
                    <button className="w-[250px] h-[46px] rounded-xl bg-[#06C302] text-[#FFFFFF] mt-6">
                      Buy Now
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="w-full h-[277px]  mt-8 bg-[#FFFFFF] rounded-2xl shadow-2xl">
            <div className="flex">
              <Image
                loading="lazy"
                src="/images/groups.png"
                width={250}
                height={250}
                alt=""
                style={{ marginLeft: "10px", paddingTop: "12px" }}
              ></Image>
              <div className="flex-col">
                <p className="mt-5 ml-5 text-[24px] text-[#3C4852] font-semibold">
                  UPSC Interview All India Live Test Series
                </p>
                <div>
                  <Image
                    loading="lazy"
                    src="/images/delete.png"
                    alt=""
                    width={20}
                    height={20}
                    style={{ marginLeft: 1350, marginTop: -30 }}
                  />
                </div>

                <div className="flex-col ml-5 mt-4">
                  <p className="text-[16px] text-[#778590]">
                    12 lessons .40 hours
                  </p>
                  <div className="mr-20">
                    <p className="text-[16px] text-[#778590] mt-5">
                      Lorem Ipsum is simply dummy text of the printing and
                      typesetting industry. Lorem Ipsum has been the industry
                      standard dummy text ever since the 1500s, Lorem Ipsum is
                      simply dummy text of the printing and typesetting
                      industry. Lorem Ipsum has been the industry standard dummy
                      text ever since the 1500s,
                    </p>
                    <div className="flex gap-4">
                      <button className="w-[250px] h-[46px] rounded-xl bg-[#8B75F3] text-[#FFFFFF] mt-6">
                        View Test
                      </button>
                      <button className="w-[250px] h-[46px] rounded-xl bg-[#06C302] text-[#FFFFFF] mt-6">
                        Buy Now
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>{" "}
          <br />
        </div> */}
      {/* </div> */}

      <div>
        <p
          className="flex justify-center text-[24px] font-bold text-[#3C4852] "
          style={{ marginTop: "50px" }}
        >
          {" "}
          Wishlist
        </p>
        <div className=" w-[100dvw] flex justify-center">
          <div className="max-w-[1000px] min-h-[277px]  mt-2 bg-[#FFFFFF] rounded-2xl shadow-2xl">
            <div className="items-center flex-col flex md:items-start md:flex-row sm:flex-col sm:py-5 ">
              <Image
                src="/images/groups.png"
                width={250}
                height={250}
                alt="course video image"
                style={{ marginLeft: "10px", paddingTop: "12px" }}
              ></Image>
              <div className="flex-col">
                <p className="mt-2 ml-2 text-[24px] text-[#3C4852] font-semibold">
                  UPSC Interview All India Live Test Series{" "}
                </p>
                <div className=" ">
                  <Image
                    src="/images/delete.png"
                    alt="delete image"
                    width={20}
                    height={20}
                    className="ml-[5px] sm:ml-[600px] sm:mt-[-30px] md:ml-[500px] md:mt-[-30px] lg:ml-[680px] lg:mt-[-30px]"
                  />
                </div>

                <div className="flex-col ml-2 mt-4">
                  <p className="text-[16px]  text-[#778590]">
                    12 lessons .40 hours
                  </p>
                  <div>
                    <p className="text-[16px] text-[#778590] mt-5">
                      Lorem Ipsum is simply dummy text of the printing and
                      typesetting industry. Lorem Ipsum has been the
                      industry&apos;s standard dummy text ever since the 1500s,
                      Lorem Ipsum is simply dummy text of the printing and
                      typesetting industry. Lorem Ipsum has been the
                      industry&apos;s standard dummy text ever since the 1500s,
                    </p>
                    <div className="flex flex-col items-center gap-y-0.5  sm:flex-row sm:justify-center t md:justify-start md:flex-row  lg:justify-start lg:flex-row gap-4">
                      <button className="w-[250px] h-[46px] rounded-xl bg-[#8B75F3] text-[#FFFFFF] mt-6">
                        View Test Series
                      </button>
                      <button className="w-[250px] h-[46px] rounded-xl bg-[#06C302] text-[#FFFFFF] mt-6">
                        Buy Now
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* 
<div className=" w-[100dvw] flex justify-center">
            <div className='max-w-[1000px] min-h-[277px]  mt-2 bg-[#FFFFFF] rounded-2xl shadow-2xl '>
                <div className='flex  md:flex-row sm:flex-col sm:py-5 '>
                    <Image src='/images/groups.png' width={250} height={250} alt="course video image" style={{ marginLeft: '10px', paddingTop: '12px' }}></Image>
                    <div className='flex-col'>
                        <p className='mt-2 ml-2 text-[24px] text-[#3C4852] font-semibold'>UPSC Interview All India Live Test Series </p>
                        <div>
                        <Image src="/images/delete.png" alt="delete image" width={20} height={20} style={{marginLeft:680, marginTop:-30}}/>
                        </div>


                <div className="flex-col ml-2 mt-4">
                  <p className="text-[16px]  text-[#778590]">
                    12 lessons .40 hours
                  </p>
                  <div>
                    <p className="text-[16px] text-[#778590] mt-5">
                      Lorem Ipsum is simply dummy text of the printing and
                      typesetting industry. Lorem Ipsum has been the
                      industry&apos;s standard dummy text ever since the 1500s,
                      Lorem Ipsum is simply dummy text of the printing and
                      typesetting industry. Lorem Ipsum has been the
                      industry&apos;s standard dummy text ever since the 1500s,
                    </p>
                    <div className="flex gap-4">
                      <button className="w-[250px] h-[46px] rounded-xl bg-[#8B75F3] text-[#FFFFFF] mt-6">
                        View Test Series
                      </button>
                      <button className="w-[250px] h-[46px] rounded-xl bg-[#06C302] text-[#FFFFFF] mt-6">
                        Buy Now
                      </button>
                    </div>

                </div>
                </div>
                </div> */}
        <div className=" w-[100dvw] flex justify-center">
          <div className="max-w-[1000px] min-h-[277px]  mt-2 bg-[#FFFFFF] rounded-2xl shadow-2xl">
            <div className="items-center flex-col flex md:items-start md:flex-row sm:flex-col sm:py-5 ">
              <Image
                src="/images/groups.png"
                width={250}
                height={250}
                alt="course video image"
                style={{ marginLeft: "10px", paddingTop: "12px" }}
              ></Image>
              <div className="flex-col">
                <p className="mt-2 ml-2 text-[24px] text-[#3C4852] font-semibold">
                  UPSC Interview All India Live Test Series{" "}
                </p>
                <div className=" ">
                  <Image
                    src="/images/delete.png"
                    alt="delete image"
                    width={20}
                    height={20}
                    className="ml-[5px] sm:ml-[600px] sm:mt-[-30px] md:ml-[500px] md:mt-[-30px] lg:ml-[680px] lg:mt-[-30px]"
                  />
                </div>

                <div className="flex-col ml-2 mt-4">
                  <p className="text-[16px]  text-[#778590]">
                    12 lessons .40 hours
                  </p>
                  <div>
                    <p className="text-[16px] text-[#778590] mt-5">
                      Lorem Ipsum is simply dummy text of the printing and
                      typesetting industry. Lorem Ipsum has been the
                      industry&apos;s standard dummy text ever since the 1500s,
                      Lorem Ipsum is simply dummy text of the printing and
                      typesetting industry. Lorem Ipsum has been the
                      industry&apos;s standard dummy text ever since the 1500s,
                    </p>
                    <div className="flex flex-col items-center gap-y-0.5  sm:flex-row sm:justify-center t md:justify-start md:flex-row  lg:justify-start lg:flex-row gap-4">
                      <button className="w-[250px] h-[46px] rounded-xl bg-[#8B75F3] text-[#FFFFFF] mt-6">
                        View Test Series
                      </button>
                      <button className="w-[250px] h-[46px] rounded-xl bg-[#06C302] text-[#FFFFFF] mt-6">
                        Buy Now
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
};

export default Wishlist;
