// CardComponent.tsx
import React from "react";

interface CardComponentProps {
  imageSrc: string;
  title: string;
  details: string;
  date: string;
}

const CardComponent: React.FC<CardComponentProps> = ({
  imageSrc,
  title,
  details,
  date,
}) => {
  return (
    <div className="min-w-[311px] min-h-[247px] shadow-2xl  rounded-2xl">
      <div className="px-3 flex gap-2 py-3 items-center font-semibold text-[15px]">
        <img src={imageSrc} alt="" width={75} height={76} />
        <p>{title}</p>
      </div>
      <div className="py-3 px-3 text-[#778590] text-[14px]">
        <p>{details}</p>
        <p className="mt-2">{date}</p>
      </div>
    </div>
  );
};

export default CardComponent;
