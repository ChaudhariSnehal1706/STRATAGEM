"use client";

import { useLogout } from "@/hooks/useLogout";
import WalletIcon from "@mui/icons-material/AccountBalanceWallet";
import PracticeIcon from "@mui/icons-material/Assignment";
import LiveTestIcon from "@mui/icons-material/Equalizer";
import ExitToAppIcon from "@mui/icons-material/ExitToApp";
import WishlistIcon from "@mui/icons-material/Favorite";
import HelpIcon from "@mui/icons-material/Help";
import HomeIcon from "@mui/icons-material/Home";
import MenuIcon from "@mui/icons-material/Menu";
import ReferEarnIcon from "@mui/icons-material/People";
import OrderIcon from "@mui/icons-material/ShoppingCart";
import Drawer from "@mui/material/Drawer";
import IconButton from "@mui/material/IconButton";
import List from "@mui/material/List";
import ListItem from "@mui/material/ListItem";
import ListItemIcon from "@mui/material/ListItemIcon";
import ListItemText from "@mui/material/ListItemText";
import Toolbar from "@mui/material/Toolbar";
import { styled } from "@mui/material/styles";
import Image from "next/image";
import { useRouter } from "next/navigation";
import { useState } from "react";
import RequireAuth from "../components/require-auth";

const drawerWidth = 240;

const PREFIX = "DashboardLayout";
const classes = {
  root: `${PREFIX}-root`,
  drawer: `${PREFIX}-drawer`,
  drawerPaper: `${PREFIX}-drawerPaper`,
  content: `${PREFIX}-content`,
};
const Root = styled("div")(({ theme }) => ({
  [`&.${classes.root}`]: {
    display: "flex",
  },
  [`& .${classes.drawer}`]: {
    width: drawerWidth,
    flexShrink: 0,
  },
  [`& .${classes.drawerPaper}`]: {
    width: drawerWidth,
  },
  [`& .${classes.content}`]: {
    flexGrow: 1,
    padding: theme.spacing(3),
  },
}));

const DashboardLayout = ({ children }: any) => {
  const handleLogout = useLogout();

  const router = useRouter();
  const [open, setOpen] = useState(false);

  const navigateTo = (path: any) => {
    router.push(path);
    toggleDrawer(false);
  };
  const toggleDrawer = (state: boolean) => {
    setOpen(state);
    console.log(state);
  };
  return (
    <Root className={classes.root}>
      <Drawer
        open={open}
        className={classes.drawer}
        variant="temporary"
        classes={{
          paper: classes.drawerPaper,
        }}
        style={{ margin: 20 }}
        onClose={() => toggleDrawer(false)}
      >
        <Toolbar style={{ margin: 5 }}>
          <Image src={"/images/logo1.png"} width={75} height={75} alt="logo" />
        </Toolbar>
        <List>
          <ListItem
            button
            onClick={() => navigateTo("/dashboard/student/profile")}
          >
            <ListItemIcon>
              <HomeIcon />
            </ListItemIcon>
            <ListItemText primary="Home" />
          </ListItem>
          <ListItem button onClick={() => navigateTo("/dashboard/practice")}>
            <ListItemIcon>
              <PracticeIcon />
            </ListItemIcon>
            <ListItemText primary="Practice" />
          </ListItem>
          <ListItem button onClick={() => navigateTo("/dashboard/liveTest")}>
            <ListItemIcon>
              <LiveTestIcon />
            </ListItemIcon>
            <ListItemText primary="Live Test" />
          </ListItem>
          <ListItem button onClick={() => navigateTo("/dashboard/wallet")}>
            <ListItemIcon>
              <WalletIcon />
            </ListItemIcon>
            <ListItemText primary="Wallet" />
          </ListItem>
          <ListItem
            button
            onClick={() => navigateTo("/dashboard/referAndEarn")}
          >
            <ListItemIcon>
              <ReferEarnIcon />
            </ListItemIcon>
            <ListItemText primary="Refer and Earn" />
          </ListItem>
          <ListItem button onClick={() => navigateTo("/dashboard/order")}>
            <ListItemIcon>
              <OrderIcon />
            </ListItemIcon>
            <ListItemText primary="Order" />
          </ListItem>
          <ListItem button onClick={() => navigateTo("/dashboard/wishlist")}>
            <ListItemIcon>
              <WishlistIcon />
            </ListItemIcon>
            <ListItemText primary="Wishlist" />
          </ListItem>
          <ListItem button onClick={() => navigateTo("/dashboard/helpSupport")}>
            <ListItemIcon>
              <HelpIcon />
            </ListItemIcon>
            <ListItemText primary="Help Support" />
          </ListItem>
          <ListItem button onClick={handleLogout}>
            <ListItemIcon>
              <ExitToAppIcon />
            </ListItemIcon>
            <ListItemText primary="Logout" />
          </ListItem>
        </List>
      </Drawer>
      <main className={classes.content} style={{ padding: 0 }}>
        <Toolbar style={{ border: 1 }}>
          <IconButton
            color="inherit"
            aria-label="open drawer"
            edge="end"
            onClick={() => {
              toggleDrawer(true);
            }}
            sx={{ ...(open && { display: "none" }) }}
          >
            <MenuIcon />
          </IconButton>
          <h1
            style={{
              fontSize: 28,
              margin: 10,
              display: "flex",
              flexDirection: "row",
            }}
          >
            <span style={{ fontWeight: "bolder" }}>Hello,</span> &nbsp;
            <span> Manit</span>
          </h1>
        </Toolbar>
        <div style={{ margin: 10, display: "flex" }}>{children}</div>
      </main>
    </Root>
  );
};

export default RequireAuth(DashboardLayout);
