import api from "@/functions/api";
import AccordionItem from "./accordion-item";
var _ = require("lodash");

const Accordion = ({ faqs, selectedCategory }: any) => {
  faqs = faqs.filter((faq: any) => faq.category.name == selectedCategory);
  return (
    <div className="bg-white rounded-lg shadow-xl mt-10 overflow-hidden ml-40 mr-40">
      <div className="ml-20 mr-20 mt-5 ">
        {faqs.map((f: any) => {
          return <FAQItem title={f.title} content={f.description} key={f.id} />;
        })}
        {/* Add more AccordionItems as needed */}
      </div>
    </div>
  );
};

const FAQItem = (props: any) => {
  const { title, content } = props;

  return (
    <div className="text-[14px] ">
      <AccordionItem title={title} content={content} />
    </div>
  );
};
export default Accordion;
