import Image from "next/image";

const FaqCategories = ({ categories, onClick }: any) => {
  return (
    <>
      <div className="all-class  ">
        <Image
          loading="lazy"
          src={"/icons/right-icon.png"}
          className="right-icon "
          alt="Class "
          width={84}
          height={84}
        />
        <div className="class-list" style={{ width: "1000px" }}>
          {categories.map((item: any, i: number) => (
            <div
              className={"std " + (i === 0 && "active")}
              key={i}
              onClick={() => {
                onClick(item);
              }}
            >
              {item}
            </div>
          ))}
        </div>
        <Image
          loading="lazy"
          src={"/icons/left-icon.png"}
          className="right-icon"
          alt="Class Icon"
          width={84}
          height={84}
        />
      </div>
    </>
  );
};

export default FaqCategories;
