import { useState } from "react";

interface AccordionItemType {
  title: string;
  content: string;
}
const AccordionItem = ({ title, content }: AccordionItemType) => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <div>
      <div className="mb-4 bg-white rounded-md overflow-hidden">
        <div
          className="p-4 cursor-pointer flex justify-between items-center border-b"
          onClick={() => setIsOpen(!isOpen)}
        >
          <h2 className="text-lg font-medium">{title}</h2>
          <svg
            className={`w-4 h-4 transform ${isOpen ? "rotate-180" : "rotate-0"}`}
            xmlns="http://www.w3.org/2000/svg"
            viewBox="0 0 20 20"
            fill="currentColor"
          >
            <path
              fillRule="evenodd"
              d="M10 3a1 1 0 0 1 1 1v12a1 1 0 1 1-2 0V4a1 1 0 0 1 1-1zM4 8a1 1 0 0 1 1-1h10a1 1 0 0 1 0 2H5a1 1 0 0 1-1-1z"
            />
          </svg>
        </div>
        <div className={`p-4 ${isOpen ? "" : "hidden"}`}>
          <p>{content}</p>
        </div>
      </div>
    </div>
  );
};

export default AccordionItem;
