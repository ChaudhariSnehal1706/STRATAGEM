"use client";
import Footer from "../components/footer/footer";
import Header from "../components/header/header";
import Accordion from "./accordion";
import FaqCategories from "./faq-categories/faq-categories";
import api from "@/functions/api";
import { useEffect, useState } from "react";
var _ = require("lodash");

export default function FAQ() {
  const [faqs, setFaq] = useState([]);
  const [categories, setCategories] = useState(new Array<string>());
  const [selectedCategory, setSelectedCategory] = useState("");
  const getFaq = async () => {
    try {
      const data: any = await api.get("/faq");
      let categories: any = new Array<string>();
      data.forEach((element: any) => {
        categories.push(element.category.name);
      });
      categories = _.uniq(categories);
      console.log(categories);
      setSelectedCategory(categories[0]);
      setCategories(categories);
      setFaq(data);
    } catch (err) {
      console.log("🚀 ~ getFAQ ~ err:", err);
    }
  };

  useEffect(() => {
    getFaq();
  }, []);

  const handleCategoryClick = (category: string) => {
    console.log(category);
    setSelectedCategory(category);
  };

  return (
    <>
      <Header title="FAQ" />
      <FaqCategories categories={categories} onClick={handleCategoryClick} />
      {selectedCategory ? (
        <Accordion faqs={faqs} selectedCategory={selectedCategory} />
      ) : null}
      <br />
      <Footer />
    </>
  );
}
