"use client";
import Header from "../components/header/header";
import Classes from "../components/classes/classes";
import Footer from "../components/footer/footer";

import api from "./../../functions/api";
import Testes from "../components/tests/testes";
import { useEffect, useState } from "react";
const TestSeries = () => {
  const [subCategories, setSubCategories] = useState([]);
  const [recommendedTestSeries, setRecommendedTestSeries] = useState([]);
  const [upcomingTestSeries, setUpcomingTestSeries] = useState([]);
  const [featuredTestSeries, setFeaturedTestSeries] = useState([]);
  const getSubCategories = async () => {
    try {
      const data: any = await api.get("/subcategories");
      setSubCategories(data);
    } catch (err) {
      console.log("🚀 ~ getCategories ~ err:", err);
    }
  };

  const getFeaturedTestSeries = async () => {
    try {
      const data: any = await api.get(
        `/testseries/featured-testseries?featured_flag=true`
      );

      setFeaturedTestSeries(data);
    } catch (err) {
      console.log("🚀 ~ getFeaturedTestSeries ~ err:", err);
    }
  };
  const getUpcomingTestSeries = async () => {
    try {
      const data: any = await api.get(`/testseries/upcoming-testseries`);
      setUpcomingTestSeries(data);
    } catch (err) {
      console.log("🚀 ~ getUpcomingTestSeries ~ err:", err);
    }
  };
  const getRecommendedTestSeries = async () => {
    try {
      const data: any = await api.get(`/testseries/recommended-testseries`);

      setRecommendedTestSeries(data);
    } catch (err) {
      console.log("🚀 ~ getRecommendedTestSeries ~ err:", err);
    }
  };
  useEffect(() => {
    getSubCategories();
    getFeaturedTestSeries();
    getUpcomingTestSeries();
    getRecommendedTestSeries();
  }, []);

  return (
    <>
      <Header title="Test Series" />
      {subCategories ? <Classes data={subCategories} /> : null}

      <Testes title="Recommended Test" testseries={recommendedTestSeries} />
      <Testes title="Featured Test" testseries={featuredTestSeries} />
      <Testes title="Upcoming Test" testseries={upcomingTestSeries} />
      <Footer />
    </>
  );
};

export default TestSeries;
