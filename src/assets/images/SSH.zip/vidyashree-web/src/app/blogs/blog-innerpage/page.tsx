"use client";
import Header from "@/app/components/header/header";
import Footer from "@/app/components/footer/footer";
import Pagination from "../../components/ui/pagination";
import { useEffect, useState } from "react";
import api from "@/functions/api";
import BlogCardMostFeatured from "@/app/components/blogs/blog-card-most-featured";
import util from "@/functions/util";

export default function BlogInnerpage() {
  const [blogs, setBlog] = useState([]);

  const [recentBlogs, setRecentBlog] = useState([]);
  const [totalBlogs, setTotalBlogs] = useState(0);
  const [currentPage, setCurrentPage] = useState(1);
  const limit = 4;
  const getBlog = async () => {
    try {
      const data: any = await api.get(
        `/blogs?skip=${(currentPage - 1) * limit}&limit=${limit}`
      );
      setBlog(data.blogs_data);
      setTotalBlogs(Math.ceil(data.total_records / limit));
    } catch (err) {
      console.log("🚀 ~ getBlog ~ err:", err);
    }
  };
  const handlePagination = (pageNumber: number) => {
    setCurrentPage(pageNumber);
    getBlog();
  };
  const getRecentBlog = async () => {
    try {
      const data: any = await api.get("/blogs/recent");
      if (data) {
        setRecentBlog(data);
      }
    } catch (err) {
      console.log("🚀 ~ getBlog ~ err:", err);
    }
  };
  useEffect(() => {
    getBlog();
    getRecentBlog();
  }, []);
  return (
    <div>
      <Header title="Blogs" />

      <div className="flex gap-6 text-[16px] text-[#667085] justify-center ml-[500px] mt-12 items-center">
        <p>Category</p>

        <p>Category</p>
        <p>Category</p>
        <div className=" flex ">
          <input
            type="text "
            placeholder="Search Blog..."
            style={{
              border: "1px solid #EAECED",
              borderRadius: "8px",
              width: "345px",
              height: "48px",
              paddingLeft: "14px",
            }}
          />
        </div>
      </div>
      <div className="flex justify-center"></div>

      <div style={{ height: 1500 }}>&nbsp;</div>
      <hr className="flex ml-20 mr-20" />
      <Pagination currentPage={2} totalPages={15} handleClick={null} />

      <Footer />
    </div>
  );
}
