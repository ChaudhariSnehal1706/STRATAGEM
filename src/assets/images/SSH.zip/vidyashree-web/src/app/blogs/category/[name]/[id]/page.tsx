"use client";

import Footer from "@/app/components/footer/footer";
import Header from "@/app/components/header/header";
import Pagination from "../../../../components/ui/pagination";
import api from "@/functions/api";
import { useParams } from "next/navigation";
import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import BlogCard from "@/app/components/blogs/blog-card";

export default function BlogCategory() {
  const params: any = useParams();
  const router: any = useRouter();

  const [currentPage, setCurrentPage] = useState(1);
  const [totalBlogs, setTotalBlogs] = useState(0);
  const limit = 40;
  const { id, name } = params;

  const [blogsCategory, setBlogCategory] = useState([]);
  const [blogs, setBlogs] = useState([]);
  const getBlogsByCategory = async () => {
    try {
      const data: any = await api.get(
        `/blogs?category=${id}&skip=${(currentPage - 1) * limit}&limit=${limit}`
      );
      console.log(data);
      setBlogs(data.blogs_data);
      setTotalBlogs(Math.ceil(data.total_records / limit));
    } catch (err) {
      console.log("🚀 ~ getBlog ~ err:", err);
    }
  };

  const handlePagination = (pageNumber: number) => {
    setCurrentPage(pageNumber);
    getBlogsByCategory();
  };

  const getBlogCategory = async () => {
    try {
      const data: any = await api.get(`/blogs-categories`);
      setBlogCategory(data);
    } catch (err) {
      console.log("🚀 ~ getBlog ~ err:", err);
    }
  };
  useEffect(() => {
    // Fetch blog posts for the given category ID and handle them
    // This is where you would typically fetch data from your API
    // using the category ID
    getBlogsByCategory();
    getBlogCategory();
  }, []);
  return (
    <div>
      <Header title="Blogs" />
      <div className="flex gap-6 text-[16px] text-[#667085] justify-center ml-[600px] mt-12 sm:flex-col md:flex-row flex-col items-center">
        {blogsCategory?.map((blogCategory: any) => {
          return (
            <p key={blogCategory._id}>
              <Link
                href={`/blogs/category/${blogCategory.name}/${blogCategory._id}`}
              >
                {blogCategory.name}
              </Link>
            </p>
          );
        })}
        {/* <input type="text " placeholder='Search Blog' /> */}
        <div className=" flex ">
          <input
            type="text "
            placeholder="Search Blog..."
            style={{
              border: "1px solid #EAECED",
              borderRadius: "8px",
              width: "345px",
              height: "48px",
              paddingLeft: "14px",
            }}
          />
        </div>
      </div>
      <div className="text-black ml-64 mt-10 font-semibold sm:flex-col md:flex-row flex-col items-center text-[24px]">
        {name}
      </div>
      <div className="mt-15 flex md:flex-row flex-wrap flex-col items-center  gap-4 justify-center ">
        {blogs
          ? blogs.map((blog: any, index: number) => {
              return (
                <BlogCard
                  key={index}
                  author={blog.author}
                  date={new Date(blog.blogDate).toLocaleDateString(undefined, {
                    day: "numeric",
                    month: "long",
                    year: "numeric",
                  })}
                  title={blog.title}
                  subtitle={blog.subtitle}
                  description={blog.content}
                  labels={blog.tags.split(",")}
                  imgsrc={`http://3.109.118.195:3000/uploads/${blog.imageUrl}`}
                  href={`/blogs/${blog._id}`}
                />
              );
            })
          : null}
      </div>
      <hr className="flex ml-20 mr-20 mt-20 text-black-400" />
      <Pagination
        currentPage={currentPage}
        totalPages={totalBlogs}
        handleClick={handlePagination}
      />
      <div style={{ height: 20 }}>&nbsp;</div>
      <Footer />
    </div>
  );
}
