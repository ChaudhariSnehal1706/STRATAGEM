"use client";
import Footer from "../components/footer/footer";
import Header from "../components/header/header";
import Link from "next/link";
import BlogCard from "../components/blogs/blog-card";
import BlogCardH from "../components/blogs/blog-card-h";
import BlogCardS from "../components/blogs/blog-card-s";
import BlogCardMostFeatured from "../components/blogs/blog-card-most-featured";
import { useEffect, useState } from "react";
import api from "../../functions/api";
import util from "../../functions/util";
import Pagination from "../components/ui/pagination";

export default function Blog() {
  const [blogs, setBlog] = useState([]);
  const [recentBlogs, setRecentBlog] = useState([]);
  const [blogsCategory, setBlogCategory] = useState([]);
  const [currentPage, setCurrentPage] = useState(1);
  const [totalBlogs, setTotalBlogs] = useState(0);
  const limit = 4;
  const getBlogCategory = async () => {
    try {
      const data: any = await api.get(`/blogs-categories`);
      setBlogCategory(data);
    } catch (err) {
      console.log("🚀 ~ getBlog ~ err:", err);
    }
  };
  const getBlog = async () => {
    try {
      const data: any = await api.get(
        `/blogs?skip=${(currentPage - 1) * limit}&limit=${limit}`
      );
      setBlog(data.blogs_data);
      setTotalBlogs(Math.ceil(data.total_records / limit));
    } catch (err) {
      console.log("🚀 ~ getBlog ~ err:", err);
    }
  };
  const handlePagination = (pageNumber: number) => {
    setCurrentPage(pageNumber);
    getBlog();
  };
  const getRecentBlog = async () => {
    try {
      const data: any = await api.get("/blogs/recent");
      if (data) {
        setRecentBlog(data);
      }
    } catch (err) {
      console.log("🚀 ~ getBlog ~ err:", err);
    }
  };
  useEffect(() => {
    getBlog();
    getBlogCategory();
    getRecentBlog();
  }, []);

  return (
    <>
      <Header title="Blogs" />

      <div className=" mt-4 text-[24px] font-semibold  gap-96 flex justify-center items-center">
        Recent Blog Post
        <div className="">
          <div className="flex justify-center gap-6 text-[16px] text-[#667085]  items-center">
            {blogsCategory?.map((blogCategory: any) => {
              return (
                <p key={blogCategory._id}>
                  <Link
                    href={`/blogs/category/${blogCategory.name}/${blogCategory._id}`}
                  >
                    {blogCategory.name}
                  </Link>
                </p>
              );
            })}

            <div className="">
              <input
                type="text "
                placeholder="Search Blog..."
                style={{
                  border: "1px solid #EAECED",
                  borderRadius: "8px",
                  width: "345px",
                  height: "48px",
                  paddingLeft: "14px",
                }}
              />
            </div>
          </div>
        </div>
      </div>
      <div className="flex gap-10 justify-center ">
        {recentBlogs?.length > 0 ? (
          <BlogCardMostFeatured
            author={(recentBlogs[0] as any).author}
            date={util.formatDate((recentBlogs[0] as any).blogDate)}
            title={(recentBlogs[0] as any).title}
            description={(recentBlogs[0] as any).content}
            labels={(recentBlogs[0] as any).tags.split(",")}
            imgSrc={`${"http://3.109.118.195:3000"}/uploads/${(recentBlogs[0] as any).imageUrl}`}
            href={`/blogs/${(recentBlogs[0] as any)._id}`}
          />
        ) : null}

        <div className="w-[590px] h-[200px] flex-col gap-2 mt-4 ">
          {recentBlogs?.length > 0 ? (
            <BlogCardS
              author={(recentBlogs[1] as any).author}
              date={util.formatDate((recentBlogs[1] as any).blogDate)}
              title={(recentBlogs[1] as any).title}
              description={(recentBlogs[1] as any).content}
              labels={(recentBlogs[1] as any).tags.split(",")}
              imgSrc={`${"http://3.109.118.195:3000"}/uploads/${(recentBlogs[1] as any).imageUrl}`}
              href={`/blogs/${(recentBlogs[1] as any)._id}`}
            />
          ) : null}
          {recentBlogs.length > 0 ? (
            <BlogCardS
              author={(recentBlogs[2] as any).author}
              date={util.formatDate((recentBlogs[2] as any).blogDate)}
              title={(recentBlogs[2] as any).title}
              description={(recentBlogs[2] as any).content}
              labels={(recentBlogs[2] as any).tags.split(",")}
              imgSrc={`${"http://3.109.118.195:3000"}/uploads/${(recentBlogs[2] as any).imageUrl}`}
              href={`/blogs/${(recentBlogs[2] as any)._id}`}
            />
          ) : null}
        </div>
      </div>
      {recentBlogs?.length > 0 ? (
        <BlogCardH
          author={(recentBlogs[3] as any).author}
          date={util.formatDate((recentBlogs[3] as any).blogDate)}
          title={(recentBlogs[3] as any).title}
          description={(recentBlogs[3] as any).content}
          labels={(recentBlogs[3] as any).tags.split(",")}
          imgSrc={`${"http://3.109.118.195:3000"}/uploads/${(recentBlogs[3] as any).imageUrl}`}
          href={`/blogs/${(recentBlogs[3] as any)._id}`}
        />
      ) : null}

      <div className="flex justify-center">
        <p className="text-[24px] font-semibold mt-20   "> All Blog Posts</p>
      </div>
      <div className="mt-15 flex md:flex-row flex-wrap flex-col items-center  gap-4 justify-center ">
        {blogs
          ? blogs.map((blog: any, index: number) => {
              return (
                <BlogCard
                  key={index}
                  author={blog.author}
                  date={new Date(blog.blogDate).toLocaleDateString(undefined, {
                    day: "numeric",
                    month: "long",
                    year: "numeric",
                  })}
                  title={blog.title}
                  subtitle={blog.subtitle}
                  description={blog.content}
                  labels={blog.tags.split(",")}
                  imgsrc={`${"http://3.109.118.195:3000"}/uploads/${blog.imageUrl}`}
                  href={`/blogs/${blog._id}`}
                />
              );
            })
          : null}
      </div>

      <hr className="flex ml-20 mr-20 mt-20" />

      <div style={{ height: 10 }}>&nbsp;</div>
      <Pagination
        currentPage={currentPage}
        totalPages={totalBlogs}
        handleClick={handlePagination}
      />
      <Footer />
    </>
  );
}
