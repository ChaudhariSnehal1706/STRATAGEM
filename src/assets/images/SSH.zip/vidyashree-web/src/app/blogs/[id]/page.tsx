"use client";

import BlogCard from "@/app/components/blogs/blog-card";

import Pagination from "../../components/ui/pagination";
import api from "../../../functions/api";
import util from "../../../functions/util";
import Link from "next/link";
import { useParams } from "next/navigation";
import { useEffect, useState } from "react";
import Header from "@/app/components/header/header";
import BlogCardMain from "@/app/components/blogs/blog-card-main";
import Footer from "@/app/components/footer/footer";
export default function BlogDetails() {
  const params: any = useParams();
  const blogId = params.id;
  const [blogs, setBlog] = useState([]);
  const [blogsCategory, setBlogCategory] = useState([]);
  const [blog, setBlogById] = useState([]);
  const [recentBlogs, setRecentBlog] = useState([]);
  const [totalBlogs, setTotalBlogs] = useState(0);
  const [currentPage, setCurrentPage] = useState(1);
  const limit = 4;
  const getBlog = async () => {
    try {
      const data: any = await api.get(
        `/blogs?skip=${(currentPage - 1) * limit}&limit=${limit}`
      );
      setBlog(data.blogs_data);
      setTotalBlogs(Math.ceil(data.total_records / limit));
    } catch (err) {
      console.log("🚀 ~ getBlog ~ err:", err);
    }
  };
  const getBlogCategory = async () => {
    try {
      const data: any = await api.get(`/blogs-categories`);
      console.log("categoru", data);
      setBlogCategory(data);
    } catch (err) {
      console.log("🚀 ~ getBlog ~ err:", err);
    }
  };
  const handlePagination = (pageNumber: number) => {
    setCurrentPage(pageNumber);
    getBlog();
  };
  const getRecentBlog = async () => {
    try {
      const data: any = await api.get("/blogs/recent");
      if (data) {
        setRecentBlog(data);
      }
    } catch (err) {
      console.log("🚀 ~ getBlog ~ err:", err);
    }
  };
  const getBlogById = async () => {
    try {
      const data: any = await api.get(`/blogs/${blogId}`);
      console.log(data);
      if (data) {
        setBlogById(data);
      }
    } catch (err) {
      console.log(err);
      console.log("🚀 ~ getBlog ~ err:", err);
    }
  };
  useEffect(() => {
    getBlogCategory();
    getBlog();
    getRecentBlog();
    getBlogById();
  }, []);
  return (
    <div>
      <Header title="Blogs" />
      <div className="flex gap-6 text-[16px] text-[#667085] justify-center ml-[500px] mt-12 items-center">
        {blogsCategory?.map((blogCategory: any) => {
          return (
            <p key={blogCategory._id}>
              <Link
                href={`/blogs/category/${blogCategory.name}/${blogCategory._id}`}
              >
                {blogCategory.name}
              </Link>
            </p>
          );
        })}
        <div className=" flex ">
          <input
            type="text "
            placeholder="Search Blog..."
            style={{
              border: "1px solid #EAECED",
              borderRadius: "8px",
              width: "345px",
              height: "48px",
              paddingLeft: "14px",
            }}
          />
        </div>
      </div>
      <div className="flex justify-center">
        {blog ? (
          <BlogCardMain
            author={(blog as any).author}
            date={util.formatDate((blog as any).blogDate)}
            title={(blog as any).title}
            description={(blog as any).content}
            labels={(blog as any).tags?.split(",")}
            imgsrc={`${"http://3.109.118.195:3000"}/uploads/${(blog as any).imageUrl}`}
          />
        ) : null}
      </div>
      <div style={{ height: 1800 }}>&nbsp;</div>
      <hr className="flex ml-20 mr-20" />
      <Pagination currentPage={2} totalPages={15} handleClick={null} />

      <Footer />
    </div>
  );
}
