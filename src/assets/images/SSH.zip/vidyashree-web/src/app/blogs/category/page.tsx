"use client";

import Footer from "@/app/components/footer/footer";
import Header from "@/app/components/header/header";
import Pagination from "@/components/ui/pagination";
import api from "@/functions/api";
import { useState } from "react";

export default function BlogCategory() {
  const [blogsCategory, setBlogCategory] = useState([]);
  const getBlogCategory = async () => {
    try {
      const data: any = await api.get(`/blogs?category=`);
      setBlogCategory(data);
    } catch (err) {
      console.log("🚀 ~ getBlog ~ err:", err);
    }
  };
  return (
    <div>
      <Header title="Blogs" />
      <div className="flex gap-6 text-[16px] text-[#667085] justify-center ml-[600px] mt-12 sm:flex-col md:flex-row flex-col items-center">
        <p>Category</p>
        <p>Category</p>
        <p>Category</p>
        {/* <input type="text " placeholder='Search Blog' /> */}
        <div className=" flex ">
          <input
            type="text "
            placeholder="Search Blog..."
            style={{
              border: "1px solid #EAECED",
              borderRadius: "8px",
              width: "345px",
              height: "48px",
              paddingLeft: "14px",
            }}
          />
        </div>
      </div>
      <div className="text-black ml-64 mt-10 font-semibold sm:flex-col md:flex-row flex-col items-center text-[24px]">
        Category Heading Blogs
      </div>
      <div className="mt-15 flex md:flex-row flex-wrap flex-col items-center  gap-4 justify-center ">
        {/* <BlogCard
          author='Natali Craig'
          date='1 Jan 2023'
          title='How collaboration makes'
          subtitle='us better designers'
          description='Collaboration can make our teams stronger and our individual designs better.'
          firstButtonLabel='Design'
          secondButtonLabel='Research'
        />
        <BlogCard
          author='Natali Craig'
          date='1 Jan 2023'
          title='How collaboration makes'
          subtitle='us better designers'
          description='Collaboration can make our teams stronger and our individual designs better.'
          firstButtonLabel='Design'
          secondButtonLabel='Research'
        />
        <BlogCard
          author='Natali Craig'
          date='1 Jan 2023'
          title='How collaboration makes'
          subtitle='us better designers'
          description='Collaboration can make our teams stronger and our individual designs better.'
          firstButtonLabel='Design'
          secondButtonLabel='Research'
        />
        <BlogCard
          author='Natali Craig'
          date='1 Jan 2023'
          title='How collaboration makes'
          subtitle='us better designers'
          description='Collaboration can make our teams stronger and our individual designs better.'
          firstButtonLabel='Design'
          secondButtonLabel='Research'
        />
        <BlogCard
          author='Natali Craig'
          date='1 Jan 2023'
          title='How collaboration makes'
          subtitle='us better designers'
          description='Collaboration can make our teams stronger and our individual designs better.'
          firstButtonLabel='Design'
          secondButtonLabel='Research'
        />
        <BlogCard
          author='Natali Craig'
          date='1 Jan 2023'
          title='How collaboration makes'
          subtitle='us better designers'
          description='Collaboration can make our teams stronger and our individual designs better.'
          firstButtonLabel='Design'
          secondButtonLabel='Research'
        />

        <BlogCard
          author='Natali Craig'
          date='1 Jan 2023'
          title='How collaboration makes'
          subtitle='us better designers'
          description='Collaboration can make our teams stronger and our individual designs better.'
          firstButtonLabel='Design'
          secondButtonLabel='Research'
        />
        <BlogCard
          author='Natali Craig'
          date='1 Jan 2023'
          title='How collaboration makes'
          subtitle='us better designers'
          description='Collaboration can make our teams stronger and our individual designs better.'
          firstButtonLabel='Design'
          secondButtonLabel='Research'
        /> */}
      </div>
      <hr className="flex ml-20 mr-20 mt-20 text-black-400" />
      <Pagination currentPage={2} totalPages={15} handleClick={null} />
      <div style={{ height: 20 }}>&nbsp;</div>
      <Footer />
    </div>
  );
}
