"use client";

import Header from "./components/header/header";
import "./page.css";
import Image from "next/image";
import Footer from "./components/footer/footer";
import api from "./../functions/api";

import { useEffect, useRef, useState } from "react";
import HomeFeaturedCategories from "./components/home/featured-category";
import HowToRegister from "./components/home/how-to-register";
import WhyChooseUs from "./components/home/why-choose-us";
import WallOfFames from "./components/home/wall-of-fames";
import PowerfulTestingHub from "./components/home/powerful-testing-hub";
import HomeExamsSection from "./components/home/home-exams";
import AllIndiaTestSeries from "./components/home/all-india-test-series";
import Testimonials from "./components/home/testimonials";
import Partners from "./components/home/partners";

const App = () => {
  const [categories, setCategories] = useState([]);
  const [selectedCategory, setSelectedCategory] = useState("");
  const [selectedSubCategory, setSelectedSubCategory] = useState("");
  const [subCategories, setSubCategories] = useState([]);
  const [parteners, setPartners] = useState([]);
  const [testseries, setTestSeries] = useState([]);
  const [testimonals, setTestimonal] = useState([]);
  const [subjects, setSubjects] = useState([]);
  const [wallOfFames, setWallOfFames] = useState([]);
  const [page, setPage] = useState(0);
  const [scroll, setScroll] = useState(0);
  const sliderRef = useRef();

  const getCategories = async () => {
    try {
      const data: any = await api.get("/categories");
      setCategories(data);
      if (data) {
        getSubCategories(data[0]._id);
        // getTestSeries(data[0]._id)
      }
    } catch (err) {
      console.log("🚀 ~ getCategories ~ err:", err);
    }
  };

  const getTestSeries = async (selectedCategory: string) => {
    try {
      if (selectedCategory) {
        setSelectedCategory(selectedCategory);
      }

      const data: any = await api.get(
        `/testseries?subcategory=${selectedCategory}`
      );
      console.log(data);
      setTestSeries(data);
      // if (data && data.length) {
      //   getSubjects(data[0]._id)
      // }
    } catch (err) {
      console.log("🚀 ~ getSubCategories ~ err:", err);
    }
  };

  const getSubCategories = async (selectedCategory: string) => {
    try {
      if (selectedCategory) {
        setSelectedCategory(selectedCategory);
      }
      const data: any = await api.get(
        `/subcategories?category=${selectedCategory}`
      );

      setSubCategories(data);
      if (data && data.length) {
        setSelectedSubCategory(data[0]._id);
        getTestSeries(data[0]._id);
        getSubjects(data[0]._id);
      }
    } catch (err) {
      console.log("🚀 ~ getSubCategories ~ err:", err);
    }
  };

  const getPartners = async () => {
    try {
      const data: any = await api.get("/partners");
      setPartners(data);
    } catch (err) {
      console.log("🚀 ~ getPartners ~ err:", err);
    }
  };

  const getTestimonals = async () => {
    try {
      const data: any = await api.get("/testimonials");
      setTestimonal(data);
    } catch (err) {
      console.log("🚀 ~ getTestimonals ~ err:", err);
    }
  };

  const getSubjects = async (subcategory: string) => {
    try {
      if (subcategory) {
        setSelectedSubCategory(subcategory);
        const data: any = await api.get(`/subjects?subcategory=${subcategory}`);
        setSubjects(data);
        // } else {
        //   const data: any = await api.get('/subjects')
        //   setSubjects(data)
      }
    } catch (err) {
      console.log("🚀 ~ getSubject ~ err:", err);
    }
  };

  const getWallOfFames = async () => {
    try {
      const data: any = await api.get("/wallOfFames");
      setWallOfFames(data);
    } catch (err) {
      console.log("🚀 ~ getWallOfFames ~ err:", err);
    }
  };

  useEffect(() => {
    getCategories();
    //getSubCategories()
    getPartners();
    getTestimonals();
    getWallOfFames();
  }, []);

  const handleCategoryClick = (data: any) => {
    getSubCategories(data._id);
  };

  const handleSubCategoryClick = (data: any) => {
    console.log(data);
    getSubjects(data);
    getTestSeries(data);
  };

  useEffect(() => {
    const scrollSlider = () => {
      if (sliderRef.current) {
        const page = Math.round(scroll / 400);
        // sliderRef.current.scrollTo(0, page >= 2 ? 0 : (page + 1) * 400)
      }
    };

    const int = setTimeout(() => {
      scrollSlider();
    }, 2000);
    return () => clearTimeout(int);
  }, [scroll]);

  return (
    <div className="home">
      <div>
        <Header
          containerClassName="big-img"
          msg="Start your Journey with us"
          title="The Most Comprehensive Exam Preparation Platform"
          icon={"/icons/rocket.png"}
        />
        <div className="mobail-num-verified">
          <div className="test-text ls">
            <h2>Get Started with All India Test Series</h2>
            <div>
              <div className="input-box">
                <Image
                  loading="lazy"
                  src={"/icons/ind.png"}
                  className="num-ind"
                  alt="India flag"
                  width={68}
                  height={68}
                />
                <div className="num">+91</div>
                <Image
                  loading="lazy"
                  src={"/icons/down.png"}
                  alt="down picture"
                  width={68}
                  height={68}
                />
              </div>
              <input placeholder="Enter your mobile number" />
            </div>
            <span className="sent-otp">
              We&aposll send an OTP for verification
            </span>
            <button className="num-btn">Continue</button>
          </div>
          <div className="rs">
            <div
              className="slider"
              // ref={sliderRef}
              onScroll={(e) => {
                setPage(Math.round(e.currentTarget.scrollTop / 400));
                setScroll(Math.round(e.currentTarget.scrollTop));
              }}
            >
              <div className="imgs">
                {Array(3)
                  .fill("Image")
                  .map((item, index) => (
                    <section key={`section-${index}`}>
                      <Image
                        alt=""
                        loading="lazy"
                        src="https://res.cloudinary.com/dgivdchdh/image/upload/v1707324380/Group_4568_v9ofgg.png"
                        key={index}
                        width={403}
                        height={703}
                      />
                    </section>
                  ))}
              </div>
            </div>
            <div className="pagination">
              {Array(3)
                .fill("Image Dot")
                .map((item, index) => (
                  <div
                    key={`dot-${index}`}
                    className={"pagination-dot " + (index === page && "active")}
                    // onClick={() => setPage(index)}
                  />
                ))}
            </div>
          </div>
        </div>
      </div>
      <HomeFeaturedCategories
        categories={categories}
        selectedCategory={selectedCategory}
        onSelectCategory={handleCategoryClick}
      />
      (
      <AllIndiaTestSeries
        subCategories={subCategories}
        selectedSubCategory={selectedSubCategory}
        testseries={testseries}
        onSelectSubcategory={handleSubCategoryClick}
      />
      )
      <WhyChooseUs />
      <HowToRegister />
      <HomeExamsSection
        subjects={subjects}
        subCategories={subCategories}
        selectedSubCategory={selectedSubCategory}
        onSelectSubcategory={handleSubCategoryClick}
      />
      <Testimonials testimonals={testimonals} />
      <Partners data={parteners} />
      <PowerfulTestingHub />
      <WallOfFames data={wallOfFames} />
      <Footer />
    </div>
  );
};

export default App;
