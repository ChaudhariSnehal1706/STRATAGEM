"use client";

import "./page.css";
import Footer from "../components/footer/footer";
import Header from "../components/header/header";
import SectionHeading from "../components/util/section-heading";
import List from "../components/util/list";

export default function TermsAndCondition() {
  return (
    <>
      <Header
        title="Terms & Condition"
        subTitle="Last Modification 20 January 2023"
      />
      <div>
        <SectionHeading>
          Welcome to Vidyashreee, Our Terms & Conditions govern your use of our
          platforms and services. Using any of our services means you have read,
          understood, and agreed with our terms and conditions. Vidyashree can
          modify, update, or change its services anytime. If we do this, we will
          post a notice that we have made changes to our terms and conditions.
        </SectionHeading>
        <SectionHeading title="Registration ">
          To avail access to certain features and services of Vidyashree, you
          may be required to register and submit your details. In that case, it
          is your responsibility to provide the correct and complete information
          during the registration process. You can update such information to
          keep it accurate. Also, it is your responsibility to keep your account
          and password confidential.
        </SectionHeading>
        <SectionHeading title="Subscription">
          You may be required to subscribe to our plans to avail some of our
          services. You can choose monthly or annual subscriptions of
          Vidyashree. When you purchase a subscription, payment can be processed
          by third parties who act on our behalf or directly by third-party
          platforms. Vidyashree holds the right to modify its rates at any time.
          The subscription plan will be auto-renewed unless canceled. If you
          have purchased the subscription plan using third-party platforms and
          face any kind of billing problem, you must contact the third party.
          But if you have purchased our services using our online platform, you
          can contact us.
        </SectionHeading>
        <SectionHeading title="Termination">
          We reserve the right to terminate or suspend your account and access
          to Vidyashree at our sole discretion, without notice, for conduct that
          we believe is against our terms and conditions.
        </SectionHeading>
      </div>
      <SectionHeading title="Refund Policy" />
      <List>
        The refund is applicable for our product or services only until it’s not
        dispatched or the login details for online access have not been
        disclosed to you
      </List>
      <List>
        Please include your ID or order no (sent to you via email after your
        order) and tell us your reason for refund.
      </List>
      <List>
        All refunds, if eligible, will be processed within 10 business days
        after receiving the cancellation or refund request.
      </List>

      <SectionHeading title="Intellectual Property" />
      <List>
        All the content, features, and functionality in Vidyahsree are owned by
        us and are protected by international copyright, trademark, patent,
        trade secret, and other intellectual property or proprietary rights
        laws.
      </List>
      <List>
        You can not copy, repost, distribute, transmit, display, or sell the
        content available on Vidyashree, without our permission.
      </List>
      <SectionHeading title="Notice For Claim & Copyright">
        If you believe that the product or thing shown at Vidyashree or its
        platform is yours, you can submit a copyright infringement notification
        to Vidysharee at (email id) with proof.
      </SectionHeading>
      <br />
      <Footer />
    </>
  );
}
