import React from "react";
import styled from "styled-components";
import Carousel from "react-multi-carousel";
import "react-multi-carousel/lib/styles.css";
import "./carousel.css";

const CarouselComponent = () => {
  const cards = [
    {
      image: "/images/teams.png",
      text: "Lorem ipsum dolor sit amet, consectetur adipiscing elit.",
    },
    {
      image: "/images/teams.png",
      text: "Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.",
    },
    {
      image: "/images/teams.png",
      text: "Ut enim ad minim veniam, quis nostrud exercitation ullamco.",
    },
    {
      image: "/images/teams.png",
      text: "Ut enim ad minim veniam, quis nostrud exercitation ullamco.",
    },
    {
      image: "/images/teams.png",
      text: "Ut enim ad minim veniam, quis nostrud exercitation ullamco.",
    },
    {
      image: "/images/teams.png",
      text: "Ut enim ad minim veniam, quis nostrud exercitation ullamco.",
    },
    {
      image: "/images/teams.png",
      text: "Ut enim ad minim veniam, quis nostrud exercitation ullamco.",
    },
  ];

  const responsive = {
    superLargeDesktop: {
      breakpoint: { max: 4000, min: 3000 },
      items: 5,
      slidesToSlide: 3,
    },
    desktop: {
      breakpoint: { max: 3000, min: 1024 },
      items: 5,
      slidesToSlide: 4,
    },
    tablet: {
      breakpoint: { max: 1024, min: 464 },
      items: 2,
      slidesToSlide: 2,
    },
    mobile: {
      breakpoint: { max: 464, min: 0 },
      items: 1,
      slidesToSlide: 1,
    },
  };

  return (
    <Carousel
      swipeable={false}
      draggable={false}
      showDots={false}
      responsive={responsive}
      ssr={false}
      infinite={true}
      autoPlay={false}
      autoPlaySpeed={1000}
      keyBoardControl={true}
      customTransition="all .5"
      transitionDuration={500}
      containerClass="carousel-container-4"
      removeArrowOnDeviceType={["tablet", "mobile"]}
      renderArrowsWhenDisabled={true}
      itemClass="carousel-item-padding-5-px"
    >
      {cards.map((card, index) => (
        <div key={index}>
          <StyledCard>
            <TeamImage src={card.image} alt={`Card ${index + 1}`} />
            <div>
              <p className="text-lg font-semibold text-center">{card.text}</p>
            </div>
          </StyledCard>
        </div>
      ))}
    </Carousel>
  );
};

const StyledCard = styled.div`
  padding: 1rem;
`;

const TeamImage = styled.img`
  width: 250px;
  margin: 20px;
`;

export default CarouselComponent;
