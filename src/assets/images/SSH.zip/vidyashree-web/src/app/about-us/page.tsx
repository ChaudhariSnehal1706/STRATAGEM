"use client";
import Footer from "./../components/footer/footer";
import SectionHeading from "./../components/util/section-heading";
import Image from "next/image";
import styled from "styled-components";
import CarouselComponent from "./carousel";
import Header from "../components/header/header";

export default function AboutUs() {
  return (
    <>
      <Header title="About Us" />
      <Div className="grid grid-cols-2 ">
        <div>
          <SectionHeading title="Our Mission"></SectionHeading>
          <Div>
            Lorem Ipsum is simply dummy text of the printing and typesetting
            industry. Lorem Ipsum has been the industry&apos; standard dummy
            text ever since the 1500s, when an unknown printer took a galley of
            type and scrambled it to make a type specimen book. Lorem Ipsum is
            simply dummy text of the printing and typesetting industry. Lorem
            Ipsum has been the industry&apos; standard dummy text ever since the
            1500s, when an unknown printer took a galley of type and scrambled
            it to make a type specimen book.
          </Div>
        </div>
        <Div>
          <Image
            loading="lazy"
            src="/images/vision.png"
            alt="Our vision"
            width={500}
            height={300}
          />
        </Div>
      </Div>
      <Div className="grid grid-cols-2 ">
        <Div>
          <Image
            loading="lazy"
            src="/images/vision.png"
            alt="Our Vision"
            width={500}
            height={300}
          />
        </Div>
        <div>
          <SectionHeading title="Our Vision"></SectionHeading>
          <Div>
            Lorem Ipsum is simply dummy text of the printing and typesetting
            industry. Lorem Ipsum has been the industry&apos; standard dummy
            text ever since the 1500s, when an unknown printer took a galley of
            type and scrambled it to make a type specimen book. Lorem Ipsum is
            simply dummy text of the printing and typesetting industry. Lorem
            Ipsum has been the industry&apos; standard dummy text ever since the
            1500s, when an unknown printer took a galley of type and scrambled
            it to make a type specimen book.
          </Div>
        </div>
      </Div>
      <div style={{ justifyContent: "center", display: "flex" }}>
        <CarouselComponent />
      </div>
      <Footer />
    </>
  );
}
const Image1 = styled.image``;
const Div = styled.div`
  margin: 20px 120px 20px 120px;
  width: 80%;
`;
const P = styled.p`
  color: var(--darkbluegrey, #3c4852);
  text-align: left;
  font-family: "Poppins-Bold", sans-serif;
  font-size: 64px;
  line-height: 30px;
  font-weight: 700;
  position: relative;
`;
