import { apiRoutes } from "@/constants/apiRoutes";
import { apiSlice } from "./apiSlice";

const authSlice = apiSlice.injectEndpoints({
  endpoints: (builder) => ({
    registerUser: builder.mutation({
      query: (body) => {
        return {
          url: apiRoutes.auth.registerStudent,
          method: "POST",
          body,
        };
      },
      // invalidatesTags: ["user"],
    }),
    registerStudentVerifyOtp: builder.mutation({
      query: (body) => {
        return {
          url: apiRoutes.auth.registerStudentVerifyOtp,
          method: "POST",
          body,
        };
      },
    }),
    loginStudent: builder.mutation({
      query: (body) => {
        return {
          url: apiRoutes.auth.login,
          method: "POST",
          body,
          headers: {
            credentials: "include",
          },
        };
      },
    }),
    loginStudentOtp: builder.mutation({
      query: (body) => {
        return {
          url: apiRoutes.auth.loginStudentOtp,
          method: "POST",
          body,
        };
      },
    }),
    verifyStudentLoginAndLogIn: builder.mutation({
      query: (body) => {
        return {
          url: apiRoutes.auth.verifyStudentLoginAndLogIn,
          method: "POST",
          body,
        };
      },
    }),
    forgetPasswordRequestOtp: builder.mutation({
      query: (body) => {
        return {
          url: apiRoutes.auth.forgetPasswordRequestOtp,
          method: "POST",
          body,
        };
      },
    }),
    forgetPasswordVerifyOtp: builder.mutation({
      query: (body) => {
        return {
          url: apiRoutes.auth.forgetPasswordVerifyOtp,
          method: "POST",
          body,
        };
      },
    }),
    resetPassword: builder.mutation({
      query: (body) => {
        return {
          url: apiRoutes.auth.resetPassword,
          method: "POST",
          body,
        };
      },
    }),
  }),
});

export default authSlice;
export const {
  useRegisterUserMutation,
  useRegisterStudentVerifyOtpMutation,
  useLoginStudentMutation,
  useLoginStudentOtpMutation,
  useVerifyStudentLoginAndLogInMutation,
  useForgetPasswordRequestOtpMutation,
  useForgetPasswordVerifyOtpMutation,
  useResetPasswordMutation,
} = authSlice;
