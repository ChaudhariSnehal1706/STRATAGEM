import { apiRoutes } from "@/constants/apiRoutes";
import { apiSlice } from "./apiSlice";

const commonSlice = apiSlice.injectEndpoints({
  endpoints: (builder) => ({
    initialDetail: builder.query({
      query: () => {
        return {
          url: apiRoutes.auth.initialDetail,
          method: "GET",
        };
      },
    }),
    categories: builder.query({
      query: () => {
        return {
          url: apiRoutes.categories.list,
          method: "GET",
        };
      },
    }),
    subCategoriesByCategoryId: builder.query({
      query: ({ categoryId }: { categoryId: string }) => {
        return {
          url: apiRoutes.subCategories.listByCategoryId(categoryId),
          method: "GET",
        };
      },
    }),
    subjectsBySubcategoryId: builder.query({
      query: ({ subcategoryId }: { subcategoryId: string }) => {
        return {
          url: apiRoutes.subjects.listBySubcategoryId(subcategoryId),
          method: "GET",
        };
      },
    }),
  }),
});

export default commonSlice;
export const {
  useLazyInitialDetailQuery,
  useCategoriesQuery,
  useSubCategoriesByCategoryIdQuery,
  useSubjectsBySubcategoryIdQuery,
} = commonSlice;
