import { PayloadAction, createSlice } from "@reduxjs/toolkit";

export type UserType = {
  _id: string;
  name: string;
  email: string;
  mobileNumber: string;
  isMobileVerified: boolean;
  isEmailVerified: boolean;
  category: string;
  subcategory: string;
};

type AuthState = {
  user: UserType | null;
};

const initialState = {
  user: null,
} as AuthState;

export const auth = createSlice({
  name: "auth",
  initialState,
  reducers: {
    resetAuth: () => initialState,
    setUserDetail: (state, action: PayloadAction<UserType>) => {
      state.user = action.payload;
    },
  },
});

export const { resetAuth, setUserDetail } = auth.actions;

export default auth.reducer;
