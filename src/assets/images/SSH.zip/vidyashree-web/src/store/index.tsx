import { Middleware, configureStore } from "@reduxjs/toolkit";
import { TypedUseSelectorHook, useDispatch, useSelector } from "react-redux";
import { toast } from "react-toastify";
import { apiSlice, cookies } from "./api/apiSlice";
import authReducer from "./slice/authSlice";

const toastMsgMiddleware: Middleware = (_api) => (next) => async (action) => {
  const response: any = next(action);

  if ([404, 500].includes(response?.payload?.status)) {
    const msg = response?.payload?.data?.message;
    toast.error(msg);
  }

  if ([401].includes(response?.payload?.status)) {
    cookies.remove("authToken");
  }

  return response;
};

export const store = configureStore({
  devTools: process.env.NODE_ENV !== "production",
  reducer: {
    auth: authReducer,
    [apiSlice.reducerPath]: apiSlice.reducer,
  },
  middleware: (getDefaultMiddleware) =>
    getDefaultMiddleware().concat(apiSlice.middleware, toastMsgMiddleware),
});

export type RootState = ReturnType<typeof store.getState>;
export type AppDispatch = typeof store.dispatch;

export const useAppDispatch = () => useDispatch<AppDispatch>();
export const useAppSelector: TypedUseSelectorHook<RootState> = useSelector;
