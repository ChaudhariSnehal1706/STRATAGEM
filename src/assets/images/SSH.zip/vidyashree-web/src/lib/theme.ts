"use client";

import { createTheme } from "@mui/material/styles";
import { Poppins } from "next/font/google";

const poppins = Poppins({
  weight: ["300", "400", "500", "600", "700"],
  subsets: ["latin"],
  display: "swap",
});

const theme = createTheme({
  typography: {
    fontFamily: poppins.style.fontFamily,
  },
  components: {
    MuiOutlinedInput: {
      styleOverrides: {
        root: ({ ownerState }) => {
          if (ownerState.size === "medium") {
            return {
              border: "none",
              borderRadius: "8px",
              height: "54px",
              "& .MuiInputBase-input": {
                height: "1.2375em",
                fontFamily: "inherit",
                fontSize: "100%",
                fontWeight: "inherit",
                lineHeight: "inherit",
              },
            };
          }
        },
      },
    },
    MuiInputLabel: {
      styleOverrides: {
        root: () => {
          return {
            color: "#000000",
            fontWeight: "normal",
          };
        },
      },
    },
  },
});

export default theme;
