"use client";

import { useAppDispatch } from "@/store";
import { cookies } from "@/store/api/apiSlice";
import { useLazyInitialDetailQuery } from "@/store/api/commonSlice";
import { setUserDetail } from "@/store/slice/authSlice";
import React, { useEffect } from "react";

interface Props {
  children: React.ReactNode;
}

const AppWrapper: React.FC<Props> = ({ children }) => {
  const [getInitialDetail] = useLazyInitialDetailQuery();
  const dispatch = useAppDispatch();

  useEffect(() => {
    const token = cookies.get("authToken");

    if (token) {
      getInitialDetail(null).then((res) => {
        dispatch(setUserDetail(res?.data?.data));
      });
    }
  }, [dispatch, getInitialDetail]);

  return <>{children}</>;
};

export default AppWrapper;
