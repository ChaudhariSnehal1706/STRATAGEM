const rhfSetError = (errors: object, setError: any) => {
  Object.entries(errors).map(([key, value]) => {
    return setError(key, { message: `${value}` });
  });
};

export default rhfSetError;
