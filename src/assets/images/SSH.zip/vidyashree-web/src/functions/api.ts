const { default: axios } = require("axios");

const baseURL = process.env.NEXT_PUBLIC_BASE_URL;

const api = {
  get: (path: string) =>
    new Promise(async (resolve, reject) => {
      try {
        const { data } = await axios.get(baseURL + path);

        if (data.success) return resolve(data.data);

        reject(data.message || "Something went wrong");
      } catch (err) {
        console.log("🚀 ~ newPromise ~ err:", err);
        return reject("Something went wrong");
      }
    }),
};

export default api;
