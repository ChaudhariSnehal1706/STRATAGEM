import { forEach } from "lodash";

const convertDottedKeysToNestedObject = (obj: any) => {
  const result: any = {};

  forEach(obj, (value, key) => {
    const keys = key.split(".");
    let currentObj = result;

    forEach(keys, (nestedKey, index) => {
      if (!currentObj[nestedKey]) {
        if (index === keys.length - 1) {
          // If it's the last key, assign the value
          currentObj[nestedKey] = value;
        } else {
          // Create an empty object for nested keys
          currentObj[nestedKey] = {};
        }
      }

      currentObj = currentObj[nestedKey];
    });
  });

  return result;
};

export default convertDottedKeysToNestedObject;
