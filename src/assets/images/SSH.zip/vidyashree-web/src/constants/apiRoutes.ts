export const apiRoutes = {
  auth: {
    initialDetail: "/auth/initial-detail",
    registerStudent: "/auth/register-student",
    registerStudentVerifyOtp: "/auth/register-student-verify-otp",
    login: "/auth/login-student",
    loginStudentOtp: "/auth/login-student-otp",
    verifyStudentLoginAndLogIn: "/auth/login-student-mobile",
    forgetPasswordRequestOtp: "/auth/forget-password/request-otp",
    forgetPasswordVerifyOtp: "/auth/forget-password/verify-otp",
    resetPassword: "/auth/reset-password",
  },
  categories: {
    list: "/categories",
  },
  subCategories: {
    listByCategoryId: (categoryId: string) =>
      `/subcategories/category/${categoryId}`,
  },
  subjects: {
    listBySubcategoryId: (subcategoryId: string) =>
      `/subjects/subcategory/${subcategoryId}`,
  },
};
