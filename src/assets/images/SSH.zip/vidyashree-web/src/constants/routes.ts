export const routes = {
  register: {
    student: "/register/student",
    teacher: "/register/teacher",
  },
  forgotPassword: {
    student: "/forgot-password/student",
    teacher: "/forgot-password/teacher",
    success: "/forgot-password/success",
  },

  login: "/login",
  home: "/",
  dashboard: "/dashboard",
};
