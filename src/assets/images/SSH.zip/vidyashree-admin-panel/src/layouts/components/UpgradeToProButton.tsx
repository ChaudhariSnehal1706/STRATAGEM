const BuyNowButton = () => {
  return <></>
}

export default BuyNowButton
