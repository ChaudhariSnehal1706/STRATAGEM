// ** React Imports
import { useState, ChangeEvent, useEffect } from 'react'

// ** MUI Imports

import Paper from '@mui/material/Paper'
import Table from '@mui/material/Table'
import TableRow from '@mui/material/TableRow'
import TableHead from '@mui/material/TableHead'
import TableBody from '@mui/material/TableBody'
import TableCell from '@mui/material/TableCell'
import TableContainer from '@mui/material/TableContainer'
import TablePagination from '@mui/material/TablePagination'

import PlusCircleOutline from 'mdi-material-ui/PlusCircleOutline'
import Button from '@mui/material/Button'
import Dialog from '@mui/material/Dialog'
import DialogTitle from '@mui/material/DialogTitle'
import DialogContent from '@mui/material/DialogContent'
import TextField from '@mui/material/TextField'
import DialogActions from '@mui/material/DialogActions'
import { DeleteAlert, Pencil } from 'mdi-material-ui'
import FormControl from '@mui/material/FormControl'
import InputLabel from '@mui/material/InputLabel'
import MenuItem from '@mui/material/MenuItem'
import Select from '@mui/material/Select'
import Swal from 'sweetalert2'

import Link from 'next/link'
import { Avatar } from '@mui/material'

interface Column {
  id:
    | 'noOfQuestions'
    | 'name'
    | 'status'
    | 'category'
    | 'banner_url'
    | 'description'
    | 'durationMinutes'
    | 'maxMarks'
    | 'scheduleStartTime'
    | 'scheduleEndTime'
    | 'subcategory'
    | 'featured_flag'
  label: string
  minWidth?: number
  align?: 'left'
  format?: (value: number) => string
}

const columns: readonly Column[] = [
  {
    id: 'banner_url',
    label: 'Banner URL',
    minWidth: 170,
    align: 'left'
  },
  { id: 'name', label: 'Name', minWidth: 170 },
  {
    id: 'description',
    label: 'Description',
    minWidth: 170,
    align: 'left'
  },
  {
    id: 'status',
    label: 'status',
    minWidth: 170,
    align: 'left'
  },

  {
    id: 'category',
    label: 'Test Category',
    minWidth: 170,
    align: 'left'
  },
  {
    id: 'subcategory',
    label: 'Subcategory',
    minWidth: 170,
    align: 'left'
  },
  { id: 'noOfQuestions', label: 'No of Questions', minWidth: 170 },

  {
    id: 'durationMinutes',
    label: 'Duration',
    minWidth: 170,
    align: 'left'
  },
  {
    id: 'maxMarks',
    label: 'Maximum Marks',
    minWidth: 170,
    align: 'left'
  },

  {
    id: 'scheduleStartTime',
    label: 'Schedule Start Time',
    minWidth: 170,
    align: 'left'
  },
  {
    id: 'scheduleEndTime',
    label: 'Schedule End Time',
    minWidth: 170,
    align: 'left'
  },
  {
    id: 'featured_flag',
    label: 'Featured Flag',
    minWidth: 170,
    align: 'left'
  }
]

interface Data {
  noOfQuestions: number
  name: string
  status: string
  scheduleEndTime: string
  scheduleStartTime: string
  maxMarks: number
  durationMinutes: number
  description: string
  banner_url: string
  category: string
  id: string
  category_id: string
  subcategory: string
  subcategory_id: string
  featured_flag: string
}

function createData(
  noOfQuestions: number,
  name: string,
  status: boolean,
  scheduleEndTime: string,
  scheduleStartTime: string,
  maxMarks: number,
  durationMinutes: number,
  description: string,
  banner_url: string,
  category: string,
  id: string,
  category_id: string,
  subcategory: string,
  subcategory_id: string,
  featured_flag: string
): Data {
  return {
    noOfQuestions,
    name,
    status: status ? 'Active' : 'Inactive',
    category,
    banner_url,
    description,
    durationMinutes,
    maxMarks,
    scheduleStartTime,
    scheduleEndTime,
    id,
    category_id,
    subcategory,
    subcategory_id,
    featured_flag: featured_flag ? 'Active' : 'Inactive'
  }
}

const TestSeriesTable = (props: any) => {
  const [rows, setRows] = useState<Data[]>([])
  const [open, setOpen] = useState(false)
  const [selectedCategory, setSelectedCategory] = useState<string>('')
  const [selectedSubCategory, setSubSelectedCategory] = useState<string>('')

  // const [editOpen, setEditOpen] = useState(false)
  const [selectedRow, setSelectedRow] = useState<Data | null>(null)

  const handleClose = () => {
    setOpen(false)

    // setEditOpen(false)
  }
  const { data, onDelete, categories, subcategory, onUpdate, onAdd, onCategoryChange } = props

  useEffect(() => {
    const updatedRows = data.map((element: any) =>
      createData(
        element.noOfQuestions,
        element.name,
        element.status,
        element.scheduleEndTime,
        element.scheduleStartTime,
        element.maxMarks,
        element.durationMinutes,
        element.description,
        element.banner_url,
        element.category ? element.category.name : '',
        element._id,
        element.category ? element.category._id : '',
        element.subcategory ? element.subcategory.name : '',
        element.subcategory ? element.subcategory._id : '',
        element.featured_flag
      )
    )
    setRows(updatedRows)
  }, [data])

  const filteredRows = rows.filter(row => {
    if (selectedCategory && selectedSubCategory) {
      return row.category_id === selectedCategory && row.subcategory_id === selectedSubCategory
    } else if (selectedCategory) {
      return row.category_id === selectedCategory
    } else {
      return true
    }
  })
  const handleChange = (event: any) => {
    setSelectedCategory(event.target.value as string)
    setSubSelectedCategory('')
  }
  const handleSubcategoryChange = (event: any) => {
    setSubSelectedCategory(event.target.value as string)
  }
  const [page, setPage] = useState<number>(0)
  const [rowsPerPage, setRowsPerPage] = useState<number>(10)

  const handleChangePage = (event: unknown, newPage: number) => {
    setPage(newPage)
  }

  const handleChangeRowsPerPage = (event: ChangeEvent<HTMLInputElement>) => {
    setRowsPerPage(+event.target.value)
    setPage(0)
  }
  const handleDelete = (row: any) => {
    Swal.fire({
      title: 'Are you sure?',
      text: 'You will not be able to recover this record!',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#d33',
      cancelButtonColor: '#3085d6',
      confirmButtonText: 'Yes, delete it!'
    }).then(result => {
      if (result.isConfirmed) {
        onDelete(row.id)
        Swal.fire('Deleted!', 'Your record has been deleted.', 'success')
      }
    })
  }
  const handleEditClick = (row: Data) => {
    setSelectedRow(row)

    // setEditOpen(true)
  }

  return (
    <Paper sx={{ width: '100%', overflow: 'hidden' }}>
      <div style={{ margin: 15, float: 'right' }}>
        <Button
          variant='outlined'
          className='btn'
          onClick={() => {
            setSelectedRow(null)
            setOpen(true)
          }}
        >
          <PlusCircleOutline style={{ margin: 5 }} />
          New Record
        </Button>
      </div>

      <div style={{ margin: 15, float: 'right' }}>
        <FormControl>
          <InputLabel id='form-layouts-separator-select-label'>SubCategory</InputLabel>
          <Select
            label='SubCategory'
            value={selectedSubCategory}
            onChange={handleSubcategoryChange}
            defaultValue=''
            id='form-layouts-separator-select'
            labelId='form-layouts-separator-select-label'
          >
            {subcategory.map((subcategory: any) =>
              selectedCategory == subcategory.category._id ? (
                <MenuItem key={subcategory._id} value={subcategory._id}>
                  {subcategory.name}
                </MenuItem>
              ) : null
            )}
            <MenuItem value=''>All</MenuItem>
          </Select>
        </FormControl>
      </div>
      <div style={{ margin: 15, float: 'right' }}>
        <FormControl>
          <InputLabel id='form-layouts-separator-select-label'>Category</InputLabel>
          <Select
            label='Category'
            value={selectedCategory}
            onChange={(event: any) => {
              handleChange(event)
            }}
            id='form-layouts-separator-select'
            labelId='form-layouts-separator-select-label'
          >
            {categories.map((category: any) => (
              <MenuItem key={category._id} value={category._id}>
                {category.name}
              </MenuItem>
            ))}
            <MenuItem value=''>All</MenuItem>
          </Select>
        </FormControl>
      </div>
      <TableContainer sx={{ maxHeight: 700 }}>
        <Table stickyHeader aria-label='sticky table'>
          <TableHead>
            <TableRow>
              {columns.map(column => (
                <TableCell key={column.id} align={column.align} sx={{ minWidth: column.minWidth }}>
                  {column.label}
                </TableCell>
              ))}
              <TableCell key='edit' align='center'>
                Update
              </TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {filteredRows.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage).map(row => {
              return (
                <TableRow hover role='checkbox' tabIndex={-1} key={row.id}>
                  {columns.map(column => {
                    const value = row[column.id]
                    if (column.id == 'banner_url') {
                      return (
                        <TableCell key={column.id} align={column.align}>
                          <Avatar
                            variant='rounded'
                            src={`${process.env.NEXT_PUBLIC_FILE_URL}/uploads/${value.toString()}`}
                            style={{ width: 150, height: 'auto' }}
                          />
                        </TableCell>
                      )
                    } else {
                      return (
                        <TableCell key={column.id} align={column.align}>
                          {column.format && typeof value === 'number' ? column.format(value) : value}
                        </TableCell>
                      )
                    }
                  })}
                  <TableCell align='center' style={{ width: 800 }}>
                    <Link href={`/test-series/${row.id}`}>
                      <Button variant='text' className='btn' onClick={() => handleEditClick(row)}>
                        <Pencil
                          color='info'
                          onClick={() => {
                            setSelectedRow(row)
                          }}
                        />
                      </Button>
                    </Link>
                    <Button variant='text' className='btn' onClick={() => handleDelete(row)}>
                      <DeleteAlert color='error' />
                    </Button>
                  </TableCell>
                </TableRow>
              )
            })}
          </TableBody>
        </Table>
      </TableContainer>
      <TablePagination
        rowsPerPageOptions={[10, 25, 100]}
        component='div'
        count={rows.length}
        rowsPerPage={rowsPerPage}
        page={page}
        onPageChange={handleChangePage}
        onRowsPerPageChange={handleChangeRowsPerPage}
      />
      {open ? (
        <FormDialog
          show={open}
          categories={categories}
          subcategory={subcategory}
          onClick={handleClose}
          onUpdate={onUpdate}
          onAdd={onAdd}
          initialData={selectedRow}
          onCategoryChange={onCategoryChange}
        />
      ) : null}
    </Paper>
  )
}
function FormDialog(props: any) {
  const { show, onClick, onAdd, categories, subcategory, onUpdate, initialData, onCategoryChange } = props
  const [formData, setFormData] = useState({
    name: initialData ? initialData.name : '',
    noOfQuestions: initialData ? initialData.noOfQuestions : 0,
    category: initialData ? initialData.category_id : '',
    image: initialData ? initialData.image : '',
    description: initialData ? initialData.description : '',
    durationMinutes: initialData ? initialData.durationMinutes : 0,
    maxMarks: initialData ? initialData.maxMarks : 0,
    scheduleStartTime: initialData ? initialData.scheduleStartTime : new Date().toLocaleDateString(),
    scheduleEndTime: initialData ? initialData.scheduleEndTime : new Date().toLocaleDateString(),
    status: initialData ? (initialData.status === 'Active' ? 'true' : 'false') : 'false',
    subcategory: initialData ? initialData.subcategory_id : '',
    featured_flag: initialData ? (initialData.featured_flag === 'Active' ? 'true' : 'false') : 'false'
  })

  const handleInputChange = (event: any) => {
    const { name, value } = event.target
    setFormData({
      ...formData,
      [name]: value
    })
  }

  const handleFormSubmit = async (event: any) => {
    event.preventDefault()
    const fdata = { ...formData }
    fdata.noOfQuestions = Number(fdata.noOfQuestions)
    fdata.durationMinutes = Number(fdata.durationMinutes)
    fdata.maxMarks = Number(fdata.maxMarks)

    // Assuming you have a server endpoint to handle MongoDB insertion
    if (initialData && initialData.id) {
      onUpdate(initialData.id, fdata)
    } else {
      onAdd(fdata)
    }
    onClick()
  }

  return (
    <Dialog open={show} onClose={onClick}>
      <form onSubmit={handleFormSubmit}>
        <DialogTitle>{initialData ? 'Edit Record' : 'New Record'}</DialogTitle>
        <DialogContent>
          {/* <DialogContentText>
            To subscribe to this website, please enter your email address here. We
            will send updates occasionally.
          </DialogContentText> */}
          <TextField
            autoFocus
            required
            margin='dense'
            id='name'
            name='name'
            label='Name'
            type='text'
            fullWidth
            variant='outlined'
            value={formData.name}
            onChange={handleInputChange}
          />
          <TextField
            required
            margin='dense'
            id='noOfQuestions'
            name='noOfQuestions'
            label='No of questions'
            type='number'
            fullWidth
            variant='outlined'
            value={formData.noOfQuestions}
            onChange={handleInputChange}
          />
          <FormControl fullWidth margin='dense'>
            <InputLabel id='form-layouts-separator-select-label'>Categories</InputLabel>
            <Select
              label='Category'
              value={formData.category}
              id='category'
              name='category'
              fullWidth
              variant='outlined'
              labelId='category'
              onChange={(event: any) => {
                console.log(event.target.value)
                onCategoryChange(event.target.value)
                handleInputChange(event)
              }}
            >
              {categories?.map((c: any) => {
                return (
                  <MenuItem key={c._id} value={c._id}>
                    {c.name}
                  </MenuItem>
                )
              })}

              {/* <MenuItem value='false'>Inactive</MenuItem> */}
            </Select>
          </FormControl>
          <FormControl fullWidth margin='dense'>
            <InputLabel id='form-layouts-separator-select-label'>SubCategories</InputLabel>
            <Select
              label='Sub Category'
              value={formData.subcategory}
              id='subcategory'
              name='subcategory'
              fullWidth
              variant='outlined'
              labelId='subcategory'
              onChange={handleInputChange}
            >
              {subcategory?.map((c: any) => {
                return (
                  <MenuItem key={c._id} value={c._id}>
                    {c.name}
                  </MenuItem>
                )
              })}

              {/* <MenuItem value='false'>Inactive</MenuItem> */}
            </Select>
          </FormControl>
          {/* <TextField
            required
            margin='dense'
            id='banner_url'
            name='banner_url'
            label='Banner URL'
            type='url'
            fullWidth
            variant='outlined'
            value={formData.banner_url}
            onChange={handleInputChange}
          /> */}
          <TextField
            required
            margin='dense'
            id='description'
            name='description'
            label='Description'
            type='text'
            fullWidth
            variant='outlined'
            value={formData.description}
            onChange={handleInputChange}
          />
          <TextField
            required
            margin='dense'
            id='maxMarks'
            name='maxMarks'
            label='Maximum Marks'
            type='number'
            fullWidth
            variant='outlined'
            value={formData.maxMarks}
            onChange={handleInputChange}
          />
          <TextField
            required
            margin='dense'
            id='durationMinutes'
            name='durationMinutes'
            label='Duration'
            type='number'
            fullWidth
            variant='outlined'
            value={formData.durationMinutes}
            onChange={handleInputChange}
          />
          <TextField
            required
            margin='dense'
            id='scheduleStartTime'
            name='scheduleStartTime'
            label='Schedule Start Time'
            type='datetime-local'
            fullWidth
            variant='outlined'
            value={formData.scheduleStartTime}
            onChange={handleInputChange}
          />
          <InputLabel id='form-layouts-separator-select-label'>Schedule End Time</InputLabel>
          <TextField
            required
            margin='dense'
            id='scheduleEndTime'
            name='scheduleEndTime'
            label='Schedule End Time'
            type='datetime-local'
            fullWidth
            variant='outlined'
            value={formData.scheduleEndTime}
            onChange={handleInputChange}
          />
          {initialData ? (
            <FormControl fullWidth margin='dense'>
              <InputLabel id='form-layouts-separator-select-label'>Status</InputLabel>
              <Select
                label='Status'
                value={formData.status}
                id='status'
                name='status'
                fullWidth
                variant='outlined'
                labelId='status'
                onChange={handleInputChange}
              >
                <MenuItem value='true'>Active</MenuItem>
                <MenuItem value='false'>Inactive</MenuItem>
              </Select>
            </FormControl>
          ) : null}
          <FormControl fullWidth margin='dense'>
            <InputLabel id='form-layouts-separator-select-label'>Featured Flag</InputLabel>
            <Select
              label='Featured Flag'
              value={formData.featured_flag}
              id='featured_flag'
              name='featured_flag'
              fullWidth
              variant='outlined'
              labelId='featured_flag'
              onChange={handleInputChange}
            >
              <MenuItem value='true'>Active</MenuItem>
              <MenuItem value='false'>Inactive</MenuItem>
            </Select>
          </FormControl>
        </DialogContent>
        <DialogActions>
          <Button onClick={onClick}>Cancel</Button>
          <Button type='submit' variant='contained' onClick={handleFormSubmit} color='success'>
            {initialData ? 'Update' : 'Save'}
          </Button>
        </DialogActions>
      </form>
    </Dialog>
  )
}
export default TestSeriesTable
