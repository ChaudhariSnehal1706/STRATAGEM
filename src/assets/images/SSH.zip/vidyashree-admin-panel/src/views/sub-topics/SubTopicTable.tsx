// ** React Imports
import { useState, ChangeEvent, useEffect } from 'react'

// ** MUI Imports
import Paper from '@mui/material/Paper'
import Table from '@mui/material/Table'
import TableRow from '@mui/material/TableRow'
import TableHead from '@mui/material/TableHead'
import TableBody from '@mui/material/TableBody'
import TableCell from '@mui/material/TableCell'
import TableContainer from '@mui/material/TableContainer'
import TablePagination from '@mui/material/TablePagination'
import { Button, Dialog, DialogTitle, DialogContent, TextField, DialogActions } from '@mui/material'
import { PlusCircleOutline } from 'mdi-material-ui'
import { Pencil } from 'mdi-material-ui'
import { DeleteAlert } from 'mdi-material-ui'
import FormControl from '@mui/material/FormControl'
import InputLabel from '@mui/material/InputLabel'
import MenuItem from '@mui/material/MenuItem'
import Select from '@mui/material/Select'
import Swal from 'sweetalert2'

interface Column {
  id: 'topic' | 'subject' | 'board' | 'subcategory' | 'category' | 'chapter' | 'status' | 'subTopic'
  label: string
  minWidth?: number
  align?: 'left'
  format?: (value: number) => string
}

const columns: readonly Column[] = [
  {
    id: 'category',
    label: 'Category',
    minWidth: 100,
    align: 'left'
  },
  {
    id: 'board',
    label: 'Boards',
    minWidth: 100,
    align: 'left'
  },
  {
    id: 'subcategory',
    label: 'Classes',
    minWidth: 100,
    align: 'left'
  },
  {
    id: 'subject',
    label: 'Subjects',
    minWidth: 100,
    align: 'left'
  },
  { id: 'chapter', label: 'Chapters', minWidth: 170 },
  { id: 'topic', label: 'Topic', minWidth: 170 },
  { id: 'subTopic', label: 'Sub-Topic', minWidth: 170 },
  {
    id: 'status',
    label: 'status',
    minWidth: 100,
    align: 'left'
  }
]

interface Data {
  board: string
  chapter: string
  topic: string
  subject: string
  status: string
  id: string
  subcategory: string
  category: string
  category_id: string
  board_id: string
  chapter_id: string
  subject_id: string
  subcategory_id: string
  topic_id: string
  subTopic: string
}

function createData(
  topic: string,
  board: string,
  chapter: string,
  subject: string,
  status: boolean,
  id: string,
  subcategory: string,
  board_id: string,
  chapter_id: string,
  subject_id: string,
  category: string,
  category_id: string,
  subcategory_id: string,
  topic_id: string,
  subTopic: string
): Data {
  return {
    topic,
    subject,
    board,
    chapter,
    board_id,
    chapter_id,
    subject_id,
    status: status ? 'Active' : 'Inactive',
    id,
    subcategory,
    category,
    category_id,
    subcategory_id,
    topic_id,
    subTopic
  }
}

const SubTopicTable = (props: any) => {
  const [rows, setRows] = useState<Data[]>([])
  const [open, setOpen] = useState(false)
  const [selectedCategory, setSelectedCategory] = useState<string>('')
  const [selectedSubCategory, setSubSelectedCategory] = useState<string>('')
  const [selectedBoard, setSelectedBoard] = useState<string>('')
  const [selectedSubject, setSubjectSelectedCategory] = useState<string>('')
  const [selectedChapter, setChapterSelectedCategory] = useState<string>('')
  const [boardList, setBoardList] = useState([])
  const [subcategoryList, setSubcategoryList] = useState([])
  const [subjectList, setSubjectList] = useState([])
  const [chapterList, setChapterList] = useState([])

  // const [editOpen, setEditOpen] = useState(false)
  const [selectedRow, setSelectedRow] = useState<Data | null>(null)
  const filteredRows = rows.filter(row => {
    if (selectedChapter) {
      return row.chapter_id === selectedChapter && row.chapter_id === selectedChapter
    }

    if (selectedSubject) {
      return row.subject_id === selectedSubject && row.subject_id === selectedSubject
    }

    if (selectedSubCategory) {
      return row.subcategory_id === selectedSubCategory && row.subcategory_id === selectedSubCategory
    }

    if (selectedBoard) {
      return row.board_id === selectedBoard && row.board_id === selectedBoard
    }

    if (selectedCategory && selectedSubCategory) {
      return row.category_id === selectedCategory && row.subcategory_id === selectedSubCategory
    }

    if (selectedCategory) {
      return row.category_id === selectedCategory
    } else {
      return true
    }
  })
  const handleBoardListChange = (event: any) => {
    setSubSelectedCategory('')
    setSelectedBoard(event.target.value)
    const filterdSubCategorys = subcategories.filter((subcategory: any) => subcategory.board._id == event.target.value)
    setSubcategoryList(filterdSubCategorys)
  }
  const handleChange = (event: any) => {
    setSelectedCategory(event.target.value as string)
    setSelectedBoard('')
    setSubSelectedCategory('')
    setSubjectSelectedCategory('')
    setChapterSelectedCategory('')

    // setSubSelectedCategory(event.target.value as string)
    const filterdBoards = boards.filter((board: any) => board.category._id == event.target.value)
    setBoardList(filterdBoards)
  }
  const handleFilterSubjectChange = (event: any) => {
    setChapterSelectedCategory('')
    setSubjectSelectedCategory(event.target.value as string)
    const filteredChapters = chapters.filter((chapter: any) => chapter.subject._id == event.target.value)
    setChapterList(filteredChapters)
  }
  const handleFilterChapterChange = (event: any) => {
    setChapterSelectedCategory(event.target.value as string)
  }
  const handleFilterSubcategoryChange = (event: any) => {
    setSubjectSelectedCategory('')
    setSubSelectedCategory(event.target.value as string)
    const filteredSubjects = subjects.filter((subject: any) => subject.subcategory._id == event.target.value)
    setSubjectList(filteredSubjects)
  }

  const handleClose = () => {
    setOpen(false)

    // setEditOpen(false)
  }
  const {
    data,
    onDelete,
    handleChapterChange,
    handleCategoryChange,
    handleBoardChange,
    handleSubjectChange,
    handleSubcategoryChange,
    subcategories,
    subjects,
    topics,
    chapters,
    boards,
    categories,
    onAdd,
    onUpdate
  } = props

  useEffect(() => {
    const updatedRows = data.map((element: any) =>
      createData(
        element.topic ? element.topic.topic : '',
        element.board ? element.board.board : '',
        element.chapter ? element.chapter.chapter : '',
        element.subject ? element.subject.name : '',
        element.status,
        element._id,
        element.subcategory ? element.subcategory.name : '',
        element.board ? element.board._id : '',
        element.chapter ? element.chapter._id : '',
        element.subject ? element.subject._id : '',
        element.category ? element.category.name : '',
        element.category ? element.category._id : '',
        element.subcategory ? element.subcategory._id : '',
        element.topic ? element.topic._id : '',
        element.subTopic
      )
    )
    setRows(updatedRows)
  }, [data])

  const [page, setPage] = useState<number>(0)
  const [rowsPerPage, setRowsPerPage] = useState<number>(10)

  const handleChangePage = (event: unknown, newPage: number) => {
    setPage(newPage)
  }
  const handleEditClick = (row: Data) => {
    setSelectedRow(row)

    // setEditOpen(true)
  }

  const handleChangeRowsPerPage = (event: ChangeEvent<HTMLInputElement>) => {
    setRowsPerPage(+event.target.value)
    setPage(0)
  }

  const handleDelete = (row: any) => {
    Swal.fire({
      title: 'Are you sure?',
      text: 'You will not be able to recover this record!',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#d33',
      cancelButtonColor: '#3085d6',
      confirmButtonText: 'Yes, delete it!'
    }).then(result => {
      if (result.isConfirmed) {
        onDelete(row.id)
        Swal.fire('Deleted!', 'Your record has been deleted.', 'success')
      }
    })
  }

  return (
    <Paper sx={{ width: '100%', overflow: 'hidden' }}>
      <div style={{ margin: 15, float: 'right' }}>
        <Button
          variant='outlined'
          className='btn'
          onClick={() => {
            setSelectedRow(null)
            setOpen(true)
          }}
        >
          <PlusCircleOutline style={{ margin: 5 }} />
          New Record
        </Button>
      </div>

      <div style={{ margin: 15, float: 'right' }}>
        <FormControl>
          <InputLabel id='form-layouts-separator-select-label'>Chapter</InputLabel>
          <Select
            label='Chapter'
            value={selectedChapter}
            onChange={handleFilterChapterChange}
            defaultValue=''
            id='form-layouts-separator-select'
            labelId='form-layouts-separator-select-label'
          >
            {chapterList.map((chapter: any) => (
              <MenuItem key={chapter._id} value={chapter._id}>
                {chapter.chapter}
              </MenuItem>
            ))}
            <MenuItem value=''>All</MenuItem>
          </Select>
        </FormControl>
      </div>
      <div style={{ margin: 15, float: 'right' }}>
        <FormControl>
          <InputLabel id='form-layouts-separator-select-label'>Subject</InputLabel>
          <Select
            label='Subject'
            value={selectedSubject}
            onChange={handleFilterSubjectChange}
            defaultValue=''
            id='form-layouts-separator-select'
            labelId='form-layouts-separator-select-label'
          >
            {subjectList.map((subject: any) => (
              <MenuItem key={subject._id} value={subject._id}>
                {subject.name}
              </MenuItem>
            ))}
            <MenuItem value=''>All</MenuItem>
          </Select>
        </FormControl>
      </div>
      <div style={{ margin: 15, float: 'right' }}>
        <FormControl>
          <InputLabel id='form-layouts-separator-select-label'>SubCategory</InputLabel>
          <Select
            label='SubCategory'
            value={selectedSubCategory}
            onChange={handleFilterSubcategoryChange}
            defaultValue=''
            id='form-layouts-separator-select'
            labelId='form-layouts-separator-select-label'
          >
            {subcategoryList.map((subcategory: any) =>
              selectedCategory == subcategory.category?._id ? (
                <MenuItem key={subcategory._id} value={subcategory._id}>
                  {subcategory.name}
                </MenuItem>
              ) : null
            )}
            <MenuItem value=''>All</MenuItem>
          </Select>
        </FormControl>
      </div>
      <div style={{ margin: 15, float: 'right' }}>
        <FormControl>
          <InputLabel id='form-layouts-separator-select-label'>Board</InputLabel>
          <Select
            label='Board'
            value={selectedBoard}
            onChange={(event: any) => {
              handleBoardListChange(event)
            }}
            id='form-layouts-separator-select'
            labelId='form-layouts-separator-select-label'
          >
            {boardList.map((c: any) => (
              <MenuItem key={c._id} value={c._id}>
                {c.board}
              </MenuItem>
            ))}
            <MenuItem value=''>All</MenuItem>
          </Select>
        </FormControl>
      </div>
      <div style={{ margin: 15, float: 'right' }}>
        <FormControl>
          <InputLabel id='form-layouts-separator-select-label'>Category</InputLabel>
          <Select
            label='Category'
            value={selectedCategory}
            onChange={(event: any) => {
              handleChange(event)
            }}
            id='form-layouts-separator-select'
            labelId='form-layouts-separator-select-label'
          >
            {categories.map((category: any) => (
              <MenuItem key={category._id} value={category._id}>
                {category.name}
              </MenuItem>
            ))}
            <MenuItem value=''>All</MenuItem>
          </Select>
        </FormControl>
      </div>
      <TableContainer sx={{ maxHeight: 700 }}>
        <Table stickyHeader aria-label='sticky table'>
          <TableHead>
            <TableRow>
              {columns.map(column => (
                <TableCell key={column.id} align={column.align} sx={{ minWidth: column.minWidth }}>
                  {column.label}
                </TableCell>
              ))}
              <TableCell key='edit' align='center'>
                Update
              </TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {filteredRows.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage).map(row => {
              return (
                <TableRow hover role='checkbox' tabIndex={-1} key={row.id}>
                  {columns.map(column => {
                    const value = row[column.id]

                    return (
                      <>
                        <TableCell key={column.id} align={column.align} sx={{ minWidth: column.minWidth }}>
                          {column.format && typeof value === 'number' ? column.format(value) : value}
                        </TableCell>
                      </>
                    )
                  })}
                  <TableCell align='center' style={{ width: 200 }}>
                    <Button variant='text' className='btn' onClick={() => handleEditClick(row)}>
                      <Pencil
                        color='info'
                        onClick={() => {
                          setSelectedRow(row)
                          setOpen(true)
                        }}
                      />
                    </Button>
                    <Button variant='text' className='btn' onClick={() => handleDelete(row)}>
                      <DeleteAlert color='error' />
                    </Button>
                  </TableCell>
                </TableRow>
              )
            })}
          </TableBody>
        </Table>
      </TableContainer>
      <TablePagination
        rowsPerPageOptions={[10, 25, 100]}
        component='div'
        count={rows.length}
        rowsPerPage={rowsPerPage}
        page={page}
        onPageChange={handleChangePage}
        onRowsPerPageChange={handleChangeRowsPerPage}
      />
      {open ? (
        <FormDialog
          show={open}
          subcategories={subcategories}
          categories={categories}
          subjects={subjects}
          boards={boards}
          chapters={chapters}
          topics={topics}
          onClick={handleClose}
          onUpdate={onUpdate}
          onAdd={onAdd}
          handleCategoryChange={handleCategoryChange}
          handleBoardChange={handleBoardChange}
          handleSubcategoryChange={handleSubcategoryChange}
          handleSubjectChange={handleSubjectChange}
          handleChapterChange={handleChapterChange}
          initialData={selectedRow}
        />
      ) : null}
    </Paper>
  )
}

function FormDialog(props: any) {
  const {
    show,
    onClick,
    onAdd,
    topics,
    handleChapterChange,
    handleCategoryChange,
    handleBoardChange,
    handleSubjectChange,
    handleSubcategoryChange,
    onUpdate,
    boards,
    chapters,
    subjects,
    categories,
    subcategories,
    initialData
  } = props
  const [isFormValid, setIsFormValid] = useState(false) // State to manage form validation

  const [formData, setFormData] = useState({
    category: initialData ? initialData.category : '',
    status: initialData ? (initialData.status === 'Active' ? 'true' : 'false') : 'true',
    subject: initialData ? initialData.subject : '',
    subcategory: initialData ? initialData.subcategory : '',
    chapter: initialData ? initialData.chapter : '',
    board: initialData ? initialData.board : '',
    topic: initialData ? initialData.topic : '',
    subTopic: initialData ? initialData.subTopic : ''
  })

  const handleInputChange = (event: any) => {
    const { name, value } = event.target
    console.log(name, value)
    setFormData({
      ...formData,
      [name]: value
    })
  }

  const handleFormSubmit = async (event: any) => {
    event.preventDefault()

    // Assuming you have a server endpoint to handle MongoDB insertion
    if (initialData && initialData.id) {
      onUpdate(initialData.id, formData)
    } else {
      onAdd(formData)
    }
    onClick()
  }

  useEffect(() => {
    // Check if all fields are filled
    const isFilled = Object.values(formData).every(value => value !== '')
    setIsFormValid(isFilled)
  }, [formData])

  return (
    <Dialog open={show} onClose={onClick}>
      <form onSubmit={handleFormSubmit}>
        <DialogTitle>{initialData ? 'Edit Record' : 'New Record'}</DialogTitle>
        <DialogContent>
          {/* <DialogContentText>
            To subscribe to this website, please enter your email address here. We
            will send updates occasionally.
          </DialogContentText> */}
          <TextField
            autoFocus
            required
            margin='dense'
            id='subTopic'
            name='subTopic'
            label='Sub Topic'
            type='text'
            fullWidth
            variant='outlined'
            value={formData.subTopic}
            onChange={handleInputChange}
          />

          {/* <TextField
            required
            margin='dense'
            id='subcategory'
            name='subcategory'
            label='subcatergory'
            type='text'
            fullWidth
            variant='outlined'
            value={formData.subcategory}
            onChange={handleInputChange}
          /> */}
          <FormControl fullWidth margin='dense'>
            <InputLabel id='form-layouts-separator-select-label'>Categories</InputLabel>
            <Select
              label='Category'
              value={formData.category}
              id='category'
              name='category'
              fullWidth
              variant='outlined'
              labelId='category'
              onChange={(event: any) => {
                handleCategoryChange(event)
                handleInputChange(event)
              }}
            >
              {categories?.map((c: any) => {
                return (
                  <MenuItem key={c._id} value={c._id}>
                    {c.name}
                  </MenuItem>
                )
              })}

              {/* <MenuItem value='false'>Inactive</MenuItem> */}
            </Select>
          </FormControl>

          <FormControl fullWidth margin='dense'>
            <InputLabel id='form-layouts-separator-select-label'>Boards</InputLabel>
            <Select
              label='Board'
              value={formData.board}
              id='board'
              name='board'
              fullWidth
              variant='outlined'
              labelId='board'
              onChange={(event: any) => {
                handleBoardChange(event)
                handleInputChange(event)
              }}
            >
              {boards?.map((c: any) => {
                return (
                  <MenuItem key={c._id} value={c._id}>
                    {c.board}
                  </MenuItem>
                )
              })}

              {/* <MenuItem value='false'>Inactive</MenuItem> */}
            </Select>
          </FormControl>
          <FormControl fullWidth margin='dense'>
            <InputLabel id='form-layouts-separator-select-label'>Subcategories</InputLabel>
            <Select
              label='Subcategory'
              value={formData.subcategory}
              id='subcategory'
              name='subcategory'
              fullWidth
              variant='outlined'
              labelId='subcategory'
              onChange={(event: any) => {
                handleSubcategoryChange(event)
                handleInputChange(event)
              }}
            >
              {subcategories?.map((c: any) => {
                return (
                  <MenuItem key={c._id} value={c._id}>
                    {c.name}
                  </MenuItem>
                )
              })}

              {/* <MenuItem value='false'>Inactive</MenuItem> */}
            </Select>
          </FormControl>
          <FormControl fullWidth margin='dense'>
            <InputLabel id='form-layouts-separator-select-label'>Subjects</InputLabel>
            <Select
              label='Subject'
              value={formData.subject}
              id='subject'
              name='subject'
              fullWidth
              variant='outlined'
              labelId='subject'
              onChange={(event: any) => {
                handleSubjectChange(event)
                handleInputChange(event)
              }}
            >
              {subjects?.map((c: any) => {
                return (
                  <MenuItem key={c._id} value={c._id}>
                    {c.name}
                  </MenuItem>
                )
              })}

              {/* <MenuItem value='false'>Inactive</MenuItem> */}
            </Select>
          </FormControl>

          <FormControl fullWidth margin='dense'>
            <InputLabel id='form-layouts-separator-select-label'>Chapter</InputLabel>
            <Select
              label='Chapter'
              value={formData.chapter}
              id='chapter'
              name='chapter'
              fullWidth
              variant='outlined'
              labelId='chapter'
              onChange={(event: any) => {
                handleChapterChange(event)
                handleInputChange(event)
              }}
            >
              {chapters?.map((c: any) => {
                return (
                  <MenuItem key={c._id} value={c._id}>
                    {c.chapter}
                  </MenuItem>
                )
              })}

              {/* <MenuItem value='false'>Inactive</MenuItem> */}
            </Select>
          </FormControl>

          <FormControl fullWidth margin='dense'>
            <InputLabel id='form-layouts-separator-select-label'>Topic</InputLabel>
            <Select
              label='Topic'
              value={formData.topic}
              id='topic'
              name='topic'
              fullWidth
              variant='outlined'
              labelId='topic'
              onChange={(event: any) => {
                handleInputChange(event)
              }}
            >
              {console.log(topics, 'topics')}
              {topics?.map((c: any) => {
                return (
                  <MenuItem key={c._id} value={c._id}>
                    {c.topic}
                  </MenuItem>
                )
              })}

              {/* <MenuItem value='false'>Inactive</MenuItem> */}
            </Select>
          </FormControl>

          {onUpdate ? (
            <FormControl fullWidth margin='dense'>
              <InputLabel id='form-layouts-separator-select-label'>Status</InputLabel>
              <Select
                label='Status'
                value={formData.status}
                id='status'
                name='status'
                fullWidth
                variant='outlined'
                labelId='status'
                onChange={handleInputChange}
              >
                <MenuItem value='true'>Active</MenuItem>
                <MenuItem value='false'>Inactive</MenuItem>
              </Select>
            </FormControl>
          ) : null}
        </DialogContent>
        <DialogActions>
          <Button onClick={onClick} variant='contained' color='error'>
            Cancel
          </Button>
          <Button type='submit' variant='contained' onClick={handleFormSubmit} color='success' disabled={!isFormValid}>
            {initialData ? 'Update' : 'Save'}
          </Button>
        </DialogActions>
      </form>
    </Dialog>
  )
}
export default SubTopicTable
