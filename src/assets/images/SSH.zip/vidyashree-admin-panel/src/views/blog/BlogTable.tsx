// ** React Imports
import { useState, ChangeEvent, useEffect, ElementType } from 'react'

// ** MUI Imports
import Paper from '@mui/material/Paper'
import Chip from '@mui/material/Chip'
import Table from '@mui/material/Table'
import TableRow from '@mui/material/TableRow'
import TableHead from '@mui/material/TableHead'
import TableBody from '@mui/material/TableBody'
import TableCell from '@mui/material/TableCell'
import TableContainer from '@mui/material/TableContainer'
import TablePagination from '@mui/material/TablePagination'
import {
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  TextField,
  DialogActions,
  Avatar,
  ButtonProps,
  styled,
  Typography
} from '@mui/material'
import { PlusCircleOutline } from 'mdi-material-ui'
import { Pencil } from 'mdi-material-ui'
import { DeleteAlert } from 'mdi-material-ui'

import dynamic from 'next/dynamic' // Import dynamic from next/dynamic
import { EditorProps } from 'react-draft-wysiwyg'
import FormControl from '@mui/material/FormControl'
import InputLabel from '@mui/material/InputLabel'
import MenuItem from '@mui/material/MenuItem'
import Select from '@mui/material/Select'
import Swal from 'sweetalert2'
import { EditorState, convertFromRaw } from 'draft-js'
import 'react-draft-wysiwyg/dist/react-draft-wysiwyg.css'
import { stateToHTML } from 'draft-js-export-html'
import Box from '@mui/material/Box'
import Link from 'next/link'

const Editor = dynamic<EditorProps>(() => import('react-draft-wysiwyg').then(mod => mod.Editor), { ssr: false })

interface Column {
  id: 'author' | 'title' | 'category' | 'likes' | 'blogDate' | 'tags' | 'imageUrl' | 'category_id'
  label: string
  minWidth?: number
  align?: 'left'
  format?: (value: number) => string
}

const columns: readonly Column[] = [
  { id: 'imageUrl', label: 'Blog Image', minWidth: 170 },
  { id: 'author', label: 'Author Name', minWidth: 170 },

  { id: 'title', label: 'Title', minWidth: 170 },
  {
    id: 'category',
    label: 'Category',
    minWidth: 170,
    align: 'left'
  },

  // {
  //   id: 'content',
  //   label: 'Content',
  //   minWidth: 170,
  //   align: 'left'
  // },
  // {
  //   id: 'content',
  //   label: 'Content Title',
  //   minWidth: 170,
  //   align: 'left'
  // },
  {
    id: 'likes',
    label: 'Likes',
    minWidth: 170,
    align: 'left'
  },
  {
    id: 'blogDate',
    label: 'Blog Date',
    minWidth: 170,
    align: 'left'
  },
  { id: 'tags', label: 'Tags', minWidth: 170 }
]

interface Data {
  author: string
  title: string
  category: string
  category_id: string

  // content: string
  content: string
  likes: number
  tags: string
  blogDate: Date
  id: string
  imageUrl: string
}

function createData(
  author: string,
  title: string,
  category: string,

  // content: string,
  content: string,
  likes: number,
  tags: string,
  blogDate: Date,
  id: string,
  imageUrl: string,
  category_id: string
): Data {
  return { author, title, category, content, likes, tags, blogDate, id, imageUrl, category_id }
}

const BlogTable = (props: any) => {
  const [open, setOpen] = useState(false)
  const [rows, setRows] = useState<Data[]>([])

  const [selectedCategory, setSelectedCategory] = useState<string>('')

  const [selectedRow, setSelectedRow] = useState<Data | null>(null)
  const handleClose = () => {
    setOpen(false)

    // setEditOpen(false)
  }
  const { data, onDelete, categories, onAdd, onUpdate } = props
  useEffect(() => {
    const updatedRows = data.map((element: any) =>
      createData(
        element.author,
        element.title,
        element.category ? element.category.name : '',

        // element.content,
        element.content,
        element.likes,
        element.tags,
        element.blogDate,
        element._id,
        element.imageUrl,
        element.category ? element.category._id : 0
      )
    )
    setRows(updatedRows)
  }, [data])
  const filteredRows = selectedCategory ? rows.filter(row => row.category_id === selectedCategory) : rows
  console.log('filteredRows', filteredRows, selectedCategory)
  const handleChange = (event: any) => {
    setSelectedCategory(event.target.value as string)
  }
  const [page, setPage] = useState<number>(0)
  const [rowsPerPage, setRowsPerPage] = useState<number>(10)

  const handleChangePage = (event: unknown, newPage: number) => {
    setPage(newPage)
  }
  const handleEditClick = (row: Data) => {
    setSelectedRow(row)

    // setEditOpen(true)
  }

  const handleChangeRowsPerPage = (event: ChangeEvent<HTMLInputElement>) => {
    setRowsPerPage(+event.target.value)
    setPage(0)
  }

  const handleDelete = (row: any) => {
    Swal.fire({
      title: 'Are you sure?',
      text: 'You will not be able to recover this record!',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#d33',
      cancelButtonColor: '#3085d6',
      confirmButtonText: 'Yes, delete it!'
    }).then(result => {
      if (result.isConfirmed) {
        onDelete(row.id)
        Swal.fire('Deleted!', 'Your record has been deleted.', 'success')
      }
    })
  }

  return (
    <Paper sx={{ width: '100%', overflow: 'hidden' }}>
      <div style={{ margin: 15, float: 'right' }}>
        <Button
          variant='outlined'
          className='btn'
          onClick={() => {
            setSelectedRow(null)
            setOpen(true)
          }}
        >
          <PlusCircleOutline style={{ margin: 5 }} />
          New Record
        </Button>
      </div>
      <div style={{ margin: 15, float: 'right' }}>
        <FormControl>
          <InputLabel id='form-layouts-separator-select-label'>Category</InputLabel>
          <Select
            label='Category'
            value={selectedCategory}
            onChange={handleChange}
            defaultValue=''
            id='form-layouts-separator-select'
            labelId='form-layouts-separator-select-label'
          >
            {categories.map((category: any) => (
              <MenuItem key={category._id} value={category._id}>
                {category.name}
              </MenuItem>
            ))}
            <MenuItem value=''>All</MenuItem>
          </Select>
        </FormControl>
      </div>
      <TableContainer sx={{ maxHeight: 700 }}>
        <Table stickyHeader aria-label='sticky table'>
          <TableHead>
            <TableRow>
              {columns.map(column => (
                <TableCell key={column.id} align={column.align} sx={{ minWidth: column.minWidth }}>
                  {column.label}
                </TableCell>
              ))}
              <TableCell key='edit' align='center'>
                Update
              </TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {filteredRows.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage).map(row => {
              return (
                <TableRow hover role='checkbox' tabIndex={-1} key={row.id}>
                  {columns.map(column => {
                    const value = row[column.id]

                    if (column.id == 'imageUrl') {
                      console.log('--->', `${process.env.NEXT_PUBLIC_FILE_URL}/uploads/${value.toString()}`)

                      return (
                        <TableCell key={column.id} align={column.align}>
                          <Avatar
                            variant='rounded'
                            src={`${process.env.NEXT_PUBLIC_FILE_URL}/uploads/${value.toString()}`}
                            style={{ width: 150, height: 'auto' }}
                          />
                        </TableCell>
                      )
                    } else if (column.id == 'tags') {
                      return (
                        <>
                          <TableCell key={column.id} align={column.align}>
                            {(value as string).split(',').map(item => {
                              return (
                                <Chip
                                  key={item}
                                  label={item}
                                  color={'success'}
                                  sx={{
                                    height: 24,
                                    margin: 1,
                                    fontSize: '0.75rem',
                                    textTransform: 'capitalize',
                                    '& .MuiChip-label': { fontWeight: 500 }
                                  }}
                                />
                              )
                            })}
                          </TableCell>
                        </>
                      )
                    } else {
                      return (
                        <>
                          <TableCell key={column.id} align={column.align}>
                            {column.format && typeof value === 'number' ? column.format(value) : value}
                          </TableCell>
                        </>
                      )
                    }
                  })}
                  <TableCell align='center' style={{ width: 200 }}>
                    <Link href={`/blogs/${row.id}`}>
                      <Button variant='text' className='btn' onClick={() => handleEditClick(row)}>
                        <Pencil
                          color='info'
                          onClick={() => {
                            setSelectedRow(row)
                          }}
                        />
                      </Button>
                    </Link>
                    <Button variant='text' className='btn' onClick={() => handleDelete(row)}>
                      <DeleteAlert color='error' />
                    </Button>
                  </TableCell>
                </TableRow>
              )
            })}
          </TableBody>
        </Table>
      </TableContainer>
      <TablePagination
        rowsPerPageOptions={[10, 25, 100]}
        component='div'
        count={rows.length}
        rowsPerPage={rowsPerPage}
        page={page}
        onPageChange={handleChangePage}
        onRowsPerPageChange={handleChangeRowsPerPage}
      />

      {open ? (
        <FormDialog
          show={open}
          categories={categories}
          onClick={handleClose}
          onUpdate={onUpdate}
          onAdd={onAdd}
          initialData={selectedRow}
        />
      ) : null}
    </Paper>
  )
}

// const Editor = dynamic(() => import('react-draft-wysiwyg').then(mod => mod.Editor), {
//   ssr: false
// })

const ImgStyled = styled('img')(({ theme }) => ({
  width: 120,
  height: 120,
  marginRight: theme.spacing(6.25),
  borderRadius: theme.shape.borderRadius
}))
const ResetButtonStyled = styled(Button)<ButtonProps>(({ theme }) => ({
  marginLeft: theme.spacing(4.5),
  [theme.breakpoints.down('sm')]: {
    width: '100%',
    marginLeft: 0,
    textAlign: 'center',
    marginTop: theme.spacing(4)
  }
}))
function FormDialog(props: any) {
  const { show, onClick, categories, onAdd, onUpdate, initialData } = props
  const [editorState, setEditorState] = useState(EditorState.createEmpty())

  // const [content, setContent] = useState('')

  const [formData, setFormData] = useState({
    author: initialData ? initialData.author : '',
    title: initialData ? initialData.title : '',
    content: initialData ? initialData.content : '',
    category: initialData ? initialData.category : '',
    likes: initialData ? initialData.likes.toString() : '0',
    tags: initialData ? initialData.tags : '',
    blogDate: initialData ? initialData.blogDate : '',
    image: initialData ? initialData.image : ''

    // imageUrl: initialData
    //   ? initialData.imageUrl
    //   : 'https://img.freepik.com/free-photo/group-high-school-students-taking-test-classroom_662251-1868.jpg?w=996&t=st=1708401560~exp=1708402160~hmac=709a38e37d306a5c46d636a69a7eeb4f02272633688a53af3aa9faeb39db59b4'
  })
  useEffect(() => {
    if (initialData && initialData.content) {
      const contentState = convertFromRaw(JSON.parse(initialData.content))
      const editorState = EditorState.createWithContent(contentState)
      setEditorState(editorState)
    }
  }, [initialData])
  const handleEditorChange = (state: EditorState) => {
    setEditorState(state)
  }
  const handleInputChange = (event: any) => {
    const { name, value } = event.target

    setFormData({
      ...formData,
      [name]: value
    })
  }

  const handleFormSubmit = async (event: any) => {
    event.preventDefault()
    const contentState = editorState.getCurrentContent()
    const contentHTML = stateToHTML(contentState)

    // Set formData with the HTML content
    const formDataWithContent = { ...formData, content: contentHTML }

    if (initialData && initialData.id) {
      onUpdate(initialData.id, formDataWithContent)
    } else {
      onAdd(formDataWithContent)
    }
    onClick()
  }
  const ButtonStyled = styled(Button)<ButtonProps & { component?: ElementType; htmlFor?: string }>(({ theme }) => ({
    [theme.breakpoints.down('sm')]: {
      width: '100%',
      textAlign: 'center'
    }
  }))
  const [imgSrc, setImgSrc] = useState<string>('/images/avatars/1.png')
  const onChange = (file: ChangeEvent) => {
    const reader = new FileReader()
    const { files } = file.target as HTMLInputElement
    if (files && files.length !== 0) {
      reader.onload = () => setImgSrc(reader.result as string)
      formData.image = files
      reader.readAsDataURL(files[0])
    }
  }

  return (
    <Dialog open={show} onClose={onClick}>
      <form onSubmit={handleFormSubmit} method='post'>
        <DialogTitle>{initialData ? 'Edit Record' : 'New Record'}</DialogTitle>
        <DialogContent>
          {/* <DialogContentText>
            To subscribe to this website, please enter your email address here. We
            will send updates occasionally.
          </DialogContentText> */}
          <TextField
            autoFocus
            required
            margin='dense'
            id='title'
            name='title'
            label='Title'
            type='text'
            fullWidth
            variant='outlined'
            value={formData.title}
            onChange={handleInputChange}
          />
          {/* <TextField
            autoFocus
            required
            margin='dense'
            id='imageUrl'
            name='imageUrl'
            label='Image'
            type='url'
            fullWidth
            variant='outlined'
            value={formData.imageUrl}
            onChange={handleInputChange}
          /> */}
          <Box sx={{ display: 'flex', alignItems: 'center' }}>
            <ImgStyled src={imgSrc} alt='Profile Pic' />
            <Box>
              <ButtonStyled component='label' variant='contained' htmlFor='account-settings-upload-image'>
                Upload New Photo
                <input
                  hidden
                  type='file'
                  onChange={onChange}
                  accept='image/png, image/jpeg'
                  id='account-settings-upload-image'
                />
              </ButtonStyled>
              <ResetButtonStyled color='error' variant='outlined' onClick={() => setImgSrc('/images/avatars/1.png')}>
                Reset
              </ResetButtonStyled>
              <Typography variant='body2' sx={{ marginTop: 5 }}>
                Allowed PNG or JPEG. Max size of 800K.
              </Typography>
            </Box>
          </Box>
          <TextField
            required
            margin='dense'
            id='author'
            name='author'
            label='Author Name'
            type='text'
            fullWidth
            variant='outlined'
            value={formData.author}
            onChange={handleInputChange}
          />
          <FormControl fullWidth margin='dense'>
            <InputLabel id='form-layouts-separator-select-label'>Categories</InputLabel>
            <Select
              label='Category'
              value={formData.category}
              id='category'
              name='category'
              fullWidth
              variant='outlined'
              labelId='category'
              onChange={handleInputChange}
            >
              {categories?.map((c: any) => {
                return (
                  <MenuItem key={c._id} value={c._id}>
                    {c.name}
                  </MenuItem>
                )
              })}

              {/* <MenuItem value='false'>Inactive</MenuItem> */}
            </Select>
          </FormControl>
          {/* <TextField
            required
            margin='dense'
            id='content'
            name='content'
            label='Content'
            type='text'
            fullWidth
            variant='outlined'
            value={formData.content}
            onChange={handleInputChange}
          /> */}

          <Editor
            editorState={editorState}
            onEditorStateChange={handleEditorChange}
            editorClassName='editor-class'
            toolbarClassName='toolbar-class'
          />

          <TextField
            required
            margin='dense'
            id='likes'
            name='likes'
            label='Likes'
            type='number'
            fullWidth
            variant='outlined'
            value={formData.likes}
            onChange={handleInputChange}
          />
          <TextField
            required
            margin='dense'
            id='tags'
            name='tags'
            label='Tags'
            type='text'
            fullWidth
            variant='outlined'
            value={formData.tags}
            onChange={handleInputChange}
          />
          <TextField
            required
            margin='dense'
            id='blogDate'
            name='blogDate'
            label='Blog Date'
            type='date'
            fullWidth
            variant='outlined'
            value={formData.blogDate}
            onChange={handleInputChange}
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={onClick} variant='contained' color='error'>
            Cancel
          </Button>
          <Button type='submit' variant='contained' onClick={handleFormSubmit} color='success'>
            {initialData ? 'Update' : 'Save'}
          </Button>
        </DialogActions>
      </form>
    </Dialog>
  )
}
export default BlogTable
