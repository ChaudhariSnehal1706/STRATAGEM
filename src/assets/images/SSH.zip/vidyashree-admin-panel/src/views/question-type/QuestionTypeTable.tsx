// ** React Imports
import { useState, ChangeEvent, useEffect } from 'react'

// ** MUI Imports
import Paper from '@mui/material/Paper'
import Table from '@mui/material/Table'
import TableRow from '@mui/material/TableRow'
import TableHead from '@mui/material/TableHead'
import TableBody from '@mui/material/TableBody'
import TableCell from '@mui/material/TableCell'
import TableContainer from '@mui/material/TableContainer'
import TablePagination from '@mui/material/TablePagination'
import { Button, Dialog, DialogTitle, DialogContent, TextField, DialogActions } from '@mui/material'
import { PlusCircleOutline } from 'mdi-material-ui'
import { Pencil } from 'mdi-material-ui'
import { DeleteAlert } from 'mdi-material-ui'
import FormControl from '@mui/material/FormControl'
import InputLabel from '@mui/material/InputLabel'
import MenuItem from '@mui/material/MenuItem'
import Select from '@mui/material/Select'
import Swal from 'sweetalert2'

interface Column {
  id: 'type' | 'status'
  label: string
  minWidth?: number
  align?: 'left'
  format?: (value: number) => string
}

const columns: readonly Column[] = [
  { id: 'type', label: 'type', minWidth: 170 },
  {
    id: 'status',
    label: 'status',
    minWidth: 170,
    align: 'left'
  }
]

interface Data {
  type: string
  status: string
  id: string
}

function createData(type: string, status: boolean, id: string): Data {
  return {
    type,
    status: status ? 'Active' : 'Inactive',
    id
  }
}

const QuestionTypeTable = (props: any) => {
  const [rows, setRows] = useState<Data[]>([])
  const [open, setOpen] = useState(false)

  // const [editOpen, setEditOpen] = useState(false)
  const [selectedRow, setSelectedRow] = useState<Data | null>(null)
  const handleClose = () => {
    setOpen(false)

    // setEditOpen(false)
  }
  const { data, onDelete, onAdd, onUpdate } = props
  useEffect(() => {
    const updatedRows = data.map((element: any) => createData(element.type, element.status, element._id))
    setRows(updatedRows)
  }, [data])

  const [page, setPage] = useState<number>(0)
  const [rowsPerPage, setRowsPerPage] = useState<number>(10)

  const handleChangePage = (event: unknown, newPage: number) => {
    setPage(newPage)
  }
  const handleEditClick = (row: Data) => {
    setSelectedRow(row)

    // setEditOpen(true)
  }

  const handleChangeRowsPerPage = (event: ChangeEvent<HTMLInputElement>) => {
    setRowsPerPage(+event.target.value)
    setPage(0)
  }

  const handleDelete = (row: any) => {
    Swal.fire({
      title: 'Are you sure?',
      text: 'You will not be able to recover this record!',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#d33',
      cancelButtonColor: '#3085d6',
      confirmButtonText: 'Yes, delete it!'
    }).then(result => {
      if (result.isConfirmed) {
        onDelete(row.id)
        Swal.fire('Deleted!', 'Your record has been deleted.', 'success')
      }
    })
  }

  return (
    <Paper sx={{ width: '100%', overflow: 'hidden' }}>
      <div style={{ margin: 15, float: 'right' }}>
        <Button
          variant='outlined'
          className='btn'
          onClick={() => {
            setSelectedRow(null)
            setOpen(true)
          }}
        >
          <PlusCircleOutline style={{ margin: 5 }} />
          New Record
        </Button>
      </div>
      <TableContainer sx={{ maxHeight: 700 }}>
        <Table stickyHeader aria-label='sticky table'>
          <TableHead>
            <TableRow>
              {columns.map(column => (
                <TableCell key={column.id} align={column.align} sx={{ minWidth: column.minWidth }}>
                  {column.label}
                </TableCell>
              ))}
              <TableCell key='edit' align='center'>
                Update
              </TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {rows.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage).map(row => {
              return (
                <TableRow hover role='checkbox' tabIndex={-1} key={row.id}>
                  {columns.map(column => {
                    const value = row[column.id]

                    return (
                      <>
                        <TableCell key={column.id} align={column.align}>
                          {column.format && typeof value === 'number' ? column.format(value) : value}
                        </TableCell>
                      </>
                    )
                  })}
                  <TableCell align='center' style={{ width: 200 }}>
                    <Button variant='text' className='btn' onClick={() => handleEditClick(row)}>
                      <Pencil
                        color='info'
                        onClick={() => {
                          setSelectedRow(row)
                          setOpen(true)
                        }}
                      />
                    </Button>
                    <Button variant='text' className='btn' onClick={() => handleDelete(row)}>
                      <DeleteAlert color='error' />
                    </Button>
                  </TableCell>
                </TableRow>
              )
            })}
          </TableBody>
        </Table>
      </TableContainer>
      <TablePagination
        rowsPerPageOptions={[10, 25, 100]}
        component='div'
        count={rows.length}
        rowsPerPage={rowsPerPage}
        page={page}
        onPageChange={handleChangePage}
        onRowsPerPageChange={handleChangeRowsPerPage}
      />
      {open ? (
        <FormDialog show={open} onClick={handleClose} onUpdate={onUpdate} onAdd={onAdd} initialData={selectedRow} />
      ) : null}
    </Paper>
  )
}

function FormDialog(props: any) {
  const { show, onClick, onAdd, onUpdate, initialData } = props
  const [isFormValid, setIsFormValid] = useState(false) // State to manage form validation

  const [formData, setFormData] = useState({
    type: initialData ? initialData.type : '',
    status: initialData ? (initialData.status === 'Active' ? 'true' : 'false') : 'true'
  })

  const handleInputChange = (event: any) => {
    const { name, value } = event.target
    console.log(name, value)
    setFormData({
      ...formData,
      [name]: value
    })
  }

  const handleFormSubmit = async (event: any) => {
    event.preventDefault()

    // Assuming you have a server endpoint to handle MongoDB insertion
    if (initialData && initialData.id) {
      onUpdate(initialData.id, formData)
    } else {
      onAdd(formData)
    }
    onClick()
  }

  useEffect(() => {
    // Check if all fields are filled
    const isFilled = Object.values(formData).every(value => value !== '')
    setIsFormValid(isFilled)
  }, [formData])

  return (
    <Dialog open={show} onClose={onClick}>
      <form onSubmit={handleFormSubmit}>
        <DialogTitle>{initialData ? 'Edit Record' : 'New Record'}</DialogTitle>
        <DialogContent>
          {/* <DialogContentText>
            To subscribe to this website, please enter your email address here. We
            will send updates occasionally.
          </DialogContentText> */}
          <TextField
            autoFocus
            required
            margin='dense'
            id='type'
            name='type'
            label='Type'
            type='text'
            fullWidth
            variant='outlined'
            value={formData.type}
            onChange={handleInputChange}
          />

          {onUpdate ? (
            <FormControl fullWidth margin='dense'>
              <InputLabel id='form-layouts-separator-select-label'>Status</InputLabel>
              <Select
                label='Status'
                value={formData.status}
                id='status'
                name='status'
                fullWidth
                variant='outlined'
                labelId='status'
                onChange={handleInputChange}
              >
                <MenuItem value='true'>Active</MenuItem>
                <MenuItem value='false'>Inactive</MenuItem>
              </Select>
            </FormControl>
          ) : null}
        </DialogContent>
        <DialogActions>
          <Button onClick={onClick} variant='contained' color='error'>
            Cancel
          </Button>
          <Button type='submit' variant='contained' onClick={handleFormSubmit} color='success' disabled={!isFormValid}>
            {initialData ? 'Update' : 'Save'}
          </Button>
        </DialogActions>
      </form>
    </Dialog>
  )
}
export default QuestionTypeTable
