// ** Icon imports
import HomeOutline from 'mdi-material-ui/HomeOutline'
import AlertCircleOutline from 'mdi-material-ui/AlertCircleOutline'
import GoogleCirclesExtended from 'mdi-material-ui/GoogleCirclesExtended'
import CategoryIcon from '@mui/icons-material/Category'
import ClassIcon from '@mui/icons-material/Class'
import AcUnitIcon from '@mui/icons-material/AcUnit'
import HandshakeIcon from '@mui/icons-material/Handshake'
import FlutterDashIcon from '@mui/icons-material/FlutterDash'
import TopicIcon from '@mui/icons-material/Topic'
import DeveloperBoardIcon from '@mui/icons-material/DeveloperBoard'
import OndemandVideoIcon from '@mui/icons-material/OndemandVideo'
import QuestionAnswerIcon from '@mui/icons-material/QuestionAnswer'
import PsychologyAltIcon from '@mui/icons-material/PsychologyAlt'
import FormatShapesIcon from '@mui/icons-material/FormatShapes'
import ExposureIcon from '@mui/icons-material/Exposure'

// ** Type import
import { VerticalNavItemsType } from 'src/@core/layouts/types'
import { HelpBox, Rss } from 'mdi-material-ui'

const navigation = (): VerticalNavItemsType => {
  return [
    {
      title: 'Dashboard',
      icon: HomeOutline,
      path: '/'
    },
    {
      title: 'Categories',
      icon: CategoryIcon,
      path: '/categories'
    },
    {
      title: 'Board',
      icon: DeveloperBoardIcon,
      path: '/boards'
    },
    {
      title: 'Classes',
      icon: AcUnitIcon,
      path: '/subcategories'
    },
    {
      title: 'Subjects',
      icon: ClassIcon,
      path: '/subjects'
    },
    {
      title: 'Chapters',
      icon: QuestionAnswerIcon,
      path: '/chapters'
    },
    {
      title: 'Topics',
      icon: TopicIcon,
      path: '/topics'
    },
    {
      title: 'SubTopics',
      icon: ExposureIcon,
      path: '/sub-topics'
    },
    {
      title: 'Lectures',
      icon: OndemandVideoIcon,
      path: '/lectures'
    },
    {
      title: 'Question Level',
      icon: FormatShapesIcon,
      path: '/question-level'
    },
    {
      title: 'Question Type',
      icon: PsychologyAltIcon,
      path: '/question-type'
    },
    {
      title: 'Questions',
      icon: QuestionAnswerIcon,
      path: '/questions'
    },
    {
      title: 'Blogs',
      icon: Rss,
      path: '/blogs'
    },

    {
      title: 'Faq',
      icon: HelpBox,
      path: '/faq'
    },
    {
      title: 'Testimonials',
      icon: AlertCircleOutline,
      path: '/testimonials'
    },
    {
      title: 'Partners',
      icon: HandshakeIcon,
      path: '/partners'
    },

    {
      title: 'Wall of Fame',
      icon: FlutterDashIcon,
      path: '/wall-of-fame'
    },
    {
      title: 'Test Series',
      icon: GoogleCirclesExtended,
      path: '/test-series'
    }

    // {
    //   title: 'Account Settings',
    //   icon: AccountCogOutline,
    //   path: '/account-settings'
    // },
    // {
    //   sectionTitle: 'Pages'
    // },
    // {
    //   title: 'Login',
    //   icon: Login,
    //   path: '/pages/login',
    //   openInNewTab: true
    // },
    // {
    //   title: 'Register',
    //   icon: AccountPlusOutline,
    //   path: '/pages/register',
    //   openInNewTab: true
    // },
    // {
    //   title: 'Error',
    //   icon: AlertCircleOutline,
    //   path: '/pages/error',
    //   openInNewTab: true
    // },
    // {
    //   sectionTitle: 'User Interface'
    // },
    // {
    //   title: 'Typography',
    //   icon: FormatLetterCase,
    //   path: '/typography'
    // },
    // {
    //   title: 'Icons',
    //   path: '/icons',
    //   icon: GoogleCirclesExtended
    // },
    // {
    //   title: 'Cards',
    //   icon: CreditCardOutline,
    //   path: '/cards'
    // },
    // {
    //   title: 'Tables',
    //   icon: Table,
    //   path: '/tables'
    // },
    // {
    //   icon: CubeOutline,
    //   title: 'Form Layouts',
    //   path: '/form-layouts'
    // }
  ]
}

export default navigation
