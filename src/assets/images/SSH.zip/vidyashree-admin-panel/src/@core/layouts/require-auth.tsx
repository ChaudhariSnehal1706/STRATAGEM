// components/RequireAuth.js
import { useRouter } from 'next/router'
import { useEffect } from 'react'
import Cookies from 'universal-cookie'

const RequireAuth = (WrappedComponent: any) => {
  const AuthComponent = (props: any) => {
    const router = useRouter()

    useEffect(() => {
      const cookies = new Cookies()
      const email = cookies.get('email')

      if (!email) {
        // User is not logged in, redirect to login page
        router.push('/pages/login')
      }
    }, [])

    return <WrappedComponent {...props} />
  }

  return AuthComponent
}

export default RequireAuth
