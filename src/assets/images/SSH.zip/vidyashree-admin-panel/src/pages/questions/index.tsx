// ** React Imports
import { useEffect, useState } from 'react'

// ** MUI Imports
import Card from '@mui/material/Card'

// ** Third Party Styles Imports
import 'react-datepicker/dist/react-datepicker.css'
import axios from 'axios'
import { CircularProgress } from '@mui/material'
import QuestionTable from 'src/views/questions/QuestionTable'
import React from 'react'

const Questions = () => {
  // ** State
  const [topics, setTopics] = useState([])
  const [subjects, setSubjects] = useState([])
  const [isLoading, setLoading] = useState(true)
  const [boards, setBoards] = useState([])
  const [chapters, setChapters] = useState([])
  const [subcategories, setSubcategories] = useState([])
  const [categories, setCategories] = useState([])
  const [questions, setQuestions] = useState([])
  const [subTopic, setSubTopic] = useState([])
  const [questionLevels, setQuestionLevel] = useState([])
  const [questionTypes, setQuestionType] = useState([])
  const handleAddNewRecord = async (data: any) => {
    // Assuming you have a server endpoint to handle MongoDB insertion
    const formData = new FormData()
    formData.append('category', data.category)
    formData.append('status', data.status)
    formData.append('subcategory', data.subcategory)
    formData.append('subject', data.subject)
    formData.append('board', data.board)
    formData.append('chapter', data.chapter)
    formData.append('topic', data.topic)
    formData.append('question', data.question)
    formData.append('option1', data.option1)
    formData.append('option2', data.option2)
    formData.append('option3', data.option3)
    formData.append('option4', data.option4)
    formData.append('subTopic', data.subTopic)
    formData.append('questionLevel', data.questionLevel)
    formData.append('questionType', data.questionType)
    formData.append('questionMarks', data.questionMarks)
    formData.append('questionImage', data.questionImage)
    formData.append('markingScheme', data.markingScheme)
    formData.append('referenceTags', data.referenceTags)
    formData.append('favQuestion', data.favQuestion)
    formData.append('correctOption', data.correctOption)
    try {
      const config = {
        method: 'post',
        maxBodyLength: Infinity,
        url: `${process.env.NEXT_PUBLIC_BASE_URL}/questions`,
        headers: {
          Accept: '*/*',

          // 'Authorization': 'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VybmFtZSI6IlRlc3QgVXNlciAxIiwiZW1haWwiOiJ0ZXN0QGdhbWlsLmNvbSIsInJvbGUiOjEsImlhdCI6MTcwNjYyODM3NywiZXhwIjoxNzA2NzE0Nzc3fQ.YFhNEXjXcmGPcXvlO9JQ1_yRJsSTDpz7DaV8oNt8V0c',
          'Content-Type': 'application/json'
        },
        data: formData
      }

      await axios.request(config)
      handleRefresh()
    } catch (error: any) {
      console.log(error.response.data.message)
    }
  }
  const handleRefresh = () => {
    setLoading(true)
    axios
      .get(`${process.env.NEXT_PUBLIC_BASE_URL}/questionLevels`)
      .then(response => {
        console.log(response)
        if (response.data.success) {
          const questionLevelData = response.data.data
          setQuestionLevel(questionLevelData)
        }
      })
      .catch(error => {
        console.error('Error:', error.message)
      })
    axios
      .get(`${process.env.NEXT_PUBLIC_BASE_URL}/questionTypes`)
      .then(response => {
        console.log(response)
        if (response.data.success) {
          const questionType = response.data.data
          setQuestionType(questionType)
        }
      })
      .catch(error => {
        console.error('Error:', error.message)
      })
    axios
      .get(`${process.env.NEXT_PUBLIC_BASE_URL}/subTopics`)
      .then(response => {
        console.log(response)
        if (response.data.success) {
          const subTopicData = response.data.data
          setSubTopic(subTopicData)
        }
      })
      .catch(error => {
        console.error('Error:', error.message)
      })
    axios
      .get(`${process.env.NEXT_PUBLIC_BASE_URL}/questions`)
      .then(response => {
        if (response.data.success) {
          const questionData = response.data.data
          setQuestions(questionData)
          console.log('-->', questionData)
        }
      })
      .catch(error => {
        console.error('Error:', error.message)
      })
    axios
      .get(`${process.env.NEXT_PUBLIC_BASE_URL}/subjects`)
      .then(response => {
        if (response.data.success) {
          const subjectData = response.data.data
          setSubjects(subjectData)
        }
      })
      .catch(error => {
        console.error('Error:', error.message)
      })
    axios
      .get(`${process.env.NEXT_PUBLIC_BASE_URL}/topics`)
      .then(response => {
        if (response.data.success) {
          const topicData = response.data.data
          setTopics(topicData)
        }
      })
      .catch(error => {
        console.error('Error:', error.message)
      })
    axios
      .get(`${process.env.NEXT_PUBLIC_BASE_URL}/subcategories`)
      .then(response => {
        if (response.data.success) {
          const subCategoriesData = response.data.data
          setSubcategories(subCategoriesData)
        }
      })
      .catch(error => {
        console.error('Error:', error.message)
      })
    axios
      .get(`${process.env.NEXT_PUBLIC_BASE_URL}/boards`)
      .then(response => {
        if (response.data.success) {
          const boardsData = response.data.data
          setBoards(boardsData)
        }
      })
      .catch(error => {
        console.error('Error:', error.message)
      })
    axios
      .get(`${process.env.NEXT_PUBLIC_BASE_URL}/categories`)
      .then(response => {
        if (response.data.success) {
          const categoriesData = response.data.data
          setCategories(categoriesData)
        }
      })
      .catch(error => {
        console.error('Error:', error.message)
      })
      .finally(() => {
        setLoading(false)
      })
  }
  const handleCategoryChange = (event: any) => {
    const category = event.target.value
    axios
      .get(`${process.env.NEXT_PUBLIC_BASE_URL}/boards?category=${category}`)
      .then(response => {
        if (response.data.success) {
          const boardsData = response.data.data

          setBoards(boardsData)
        }
      })
      .catch(error => {
        console.error('Error:', error.message)
      })
  }
  const handleBoardChange = (event: any) => {
    const board = event.target.value
    axios
      .get(`${process.env.NEXT_PUBLIC_BASE_URL}/subcategories?board=${board}`)
      .then(response => {
        if (response.data.success) {
          const boardsData = response.data.data

          setSubcategories(boardsData)
        }
      })
      .catch(error => {
        console.error('Error:', error.message)
      })
  }
  const handleSubcategoryChange = (event: any) => {
    const subcategory = event.target.value
    axios
      .get(`${process.env.NEXT_PUBLIC_BASE_URL}/subjects?subcategory=${subcategory}`)
      .then(response => {
        if (response.data.success) {
          const boardsData = response.data.data

          setSubjects(boardsData)
        }
      })
      .catch(error => {
        console.error('Error:', error.message)
      })
  }
  const handleSubjectChange = (event: any) => {
    const subjects = event.target.value
    axios
      .get(`${process.env.NEXT_PUBLIC_BASE_URL}/chapters?subjects=${subjects}`)
      .then(response => {
        if (response.data.success) {
          const chapterData = response.data.data
          setChapters(chapterData)
        }
      })
      .catch(error => {
        console.error('Error:', error.message)
      })
  }
  const handleDelete = (questionId: string) => {
    axios
      .delete(`${process.env.NEXT_PUBLIC_BASE_URL}/questions/${questionId}`)
      .then(response => {
        if (response.data.success) {
          handleRefresh()
        }
      })
      .catch(error => {
        console.error('Error:', error.message)
      })
  }

  const handleUpdate = (questionId: string, updatedData: any) => {
    const formData = new FormData()
    formData.append('category', updatedData.category)
    formData.append('status', updatedData.status)
    formData.append('subcategory', updatedData.subcategory)
    formData.append('subject', updatedData.subject)
    formData.append('board', updatedData.board)
    formData.append('chapter', updatedData.chapter)
    formData.append('topic', updatedData.topic)
    formData.append('question', updatedData.question)
    formData.append('option1', updatedData.option1)
    formData.append('option2', updatedData.option2)
    formData.append('option3', updatedData.option3)
    formData.append('option4', updatedData.option4)
    formData.append('subTopic', updatedData.subTopic)
    formData.append('questionLevel', updatedData.questionLevel)
    formData.append('questionType', updatedData.questionType)
    formData.append('questionMarks', updatedData.questionMarks)
    formData.append('questionImage', updatedData.questionImage)
    formData.append('markingScheme', updatedData.markingScheme)
    formData.append('referenceTags', updatedData.referenceTags)
    formData.append('favQuestion', updatedData.favQuestion)
    formData.append('correctOption', updatedData.correctOption)

    axios
      .put(`${process.env.NEXT_PUBLIC_BASE_URL}/questions/${questionId}`, formData, {
        headers: {
          'Content-Type': 'application/json'
        }
      })
      .then(response => {
        if (response.data.success) {
          handleRefresh()
        }
      })
      .catch(error => {
        console.error('Error:', error.message)
      })
  }
  useEffect(() => {
    handleRefresh()
  }, [])

  return (
    <Card>
      {isLoading ? <CircularProgress /> : null}
      {questions.length ? (
        <QuestionTable
          data={questions}
          subjects={subjects}
          subcategories={subcategories}
          chapters={chapters}
          boards={boards}
          topics={topics}
          subTopic={subTopic}
          onDelete={handleDelete}
          onAdd={handleAddNewRecord}
          onUpdate={handleUpdate}
          onRefresh={handleRefresh}
          categories={categories}
          questionLevels={questionLevels}
          questionTypes={questionTypes}
          handleCategoryChange={handleCategoryChange}
          handleBoardChange={handleBoardChange}
          handleSubcategoryChange={handleSubcategoryChange}
          handleSubjectChange={handleSubjectChange}
        />
      ) : null}
    </Card>
  )
}

export default Questions
