// ** React Imports
import { useEffect, useState } from 'react'

// ** MUI Imports
import Card from '@mui/material/Card'

// ** Third Party Styles Imports
import 'react-datepicker/dist/react-datepicker.css'
import axios from 'axios'
import SubcategoryTable from 'src/views/subcategories/SubcategoriesTable'
import { CircularProgress } from '@mui/material'

const SubCategories = () => {
  // ** State

  const [subcategories, setSubcategories] = useState([])
  const [categories, setCategories] = useState([])
  const [boards, setBoards] = useState([])
  const [isLoading, setLoading] = useState(true)
  const handleAddNewRecord = async (data: any) => {
    // Assuming you have a server endpoint to handle MongoDB insertion
    try {
      const config = {
        method: 'post',
        maxBodyLength: Infinity,
        url: `${process.env.NEXT_PUBLIC_BASE_URL}/subcategories`,
        headers: {
          Accept: '*/*',

          // 'Authorization': 'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VybmFtZSI6IlRlc3QgVXNlciAxIiwiZW1haWwiOiJ0ZXN0QGdhbWlsLmNvbSIsInJvbGUiOjEsImlhdCI6MTcwNjYyODM3NywiZXhwIjoxNzA2NzE0Nzc3fQ.YFhNEXjXcmGPcXvlO9JQ1_yRJsSTDpz7DaV8oNt8V0c',
          'Content-Type': 'application/json'
        },
        data: data
      }

      await axios.request(config)
      handleRefresh()
    } catch (error: any) {
      console.log(error.response.data.message)
    }
  }
  const handleRefresh = () => {
    setLoading(true)
    axios
      .get(`${process.env.NEXT_PUBLIC_BASE_URL}/subcategories`)
      .then(response => {
        if (response.data.success) {
          const subcategoriesData = response.data.data

          setSubcategories(subcategoriesData)
        }
      })
      .catch(error => {
        console.error('Error:', error.message)
      })
    axios
      .get(`${process.env.NEXT_PUBLIC_BASE_URL}/boards`)
      .then(response => {
        if (response.data.success) {
          const boardsData = response.data.data

          setBoards(boardsData)
        }
      })
      .catch(error => {
        console.error('Error:', error.message)
      })
    axios
      .get(`${process.env.NEXT_PUBLIC_BASE_URL}/categories`)
      .then(response => {
        if (response.data.success) {
          const categoriesData = response.data.data
          setCategories(categoriesData)
        }
      })
      .catch(error => {
        console.error('Error:', error.message)
      })
      .finally(() => {
        setLoading(false)
      })
  }

  const handleCategoryChange = (event: any) => {
    const category = event.target.value
    axios
      .get(`${process.env.NEXT_PUBLIC_BASE_URL}/boards?category=${category}`)
      .then(response => {
        if (response.data.success) {
          const boardsData = response.data.data

          setBoards(boardsData)
        }
      })
      .catch(error => {
        console.error('Error:', error.message)
      })
  }
  const handleDelete = (subcategoryId: string) => {
    axios
      .delete(`${process.env.NEXT_PUBLIC_BASE_URL}/subcategories/${subcategoryId}`)
      .then(response => {
        if (response.data.success) {
          handleRefresh()
        }
      })
      .catch(error => {
        console.error('Error:', error.message)
      })
  }
  const handleUpdate = (subcategoryId: string, updatedData: any) => {
    axios
      .put(`${process.env.NEXT_PUBLIC_BASE_URL}/subcategories/${subcategoryId}`, updatedData)
      .then(response => {
        if (response.data.success) {
          handleRefresh()
        }
      })
      .catch(error => {
        console.error('Error:', error.message)
      })
  }
  useEffect(() => {
    handleRefresh()
  }, [])

  return (
    <Card>
      {isLoading ? <CircularProgress /> : null}
      {subcategories.length ? (
        <SubcategoryTable
          data={subcategories}
          categories={categories}
          onDelete={handleDelete}
          onAdd={handleAddNewRecord}
          onUpdate={handleUpdate}
          onRefresh={handleRefresh}
          boards={boards}
          handleCategoryChange={handleCategoryChange}
        />
      ) : null}
    </Card>
  )
}

export default SubCategories
