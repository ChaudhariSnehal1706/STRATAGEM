// ** React Imports
import { useEffect, useState } from 'react'

// ** MUI Imports
import Card from '@mui/material/Card'

// ** Third Party Styles Imports
import 'react-datepicker/dist/react-datepicker.css'
import axios from 'axios'
import { CircularProgress } from '@mui/material'
import ChaptersTable from 'src/views/chapters/ChaptersTable'

const Chapters = () => {
  // ** State
  // const [topics, setTopics] = useState([])
  const [subjects, setSubjects] = useState([])
  const [isLoading, setLoading] = useState(true)
  const [boards, setBoards] = useState([])
  const [chapters, setChapters] = useState([])
  const [subcategories, setSubcategories] = useState([])
  const [categories, setCategories] = useState([])
  const handleAddNewRecord = async (data: any) => {
    // Assuming you have a server endpoint to handle MongoDB insertion
    const formData = new FormData()
    formData.append('category', data.category)
    formData.append('status', data.status)
    formData.append('subcategory', data.subcategory)
    formData.append('subject', data.subject)
    formData.append('board', data.board)
    formData.append('chapter', data.chapter)

    try {
      const config = {
        method: 'post',
        maxBodyLength: Infinity,
        url: `${process.env.NEXT_PUBLIC_BASE_URL}/chapters`,
        headers: {
          Accept: '*/*',
          'Content-Type': 'application/json'
        },
        data: formData
      }

      await axios.request(config)
      handleRefresh()
    } catch (error: any) {
      console.log(error.response.data.message)
    }
  }
  const handleRefresh = () => {
    setLoading(true)
    axios
      .get(`${process.env.NEXT_PUBLIC_BASE_URL}/chapters`)
      .then(response => {
        console.log(response)
        if (response.data.success) {
          const chapterData = response.data.data
          setChapters(chapterData)
        }
      })
      .catch(error => {
        console.error('Error:', error.message)
      })
    axios
      .get(`${process.env.NEXT_PUBLIC_BASE_URL}/subjects`)
      .then(response => {
        if (response.data.success) {
          const subjectData = response.data.data
          setSubjects(subjectData)
        }
      })
      .catch(error => {
        console.error('Error:', error.message)
      })

    axios
      .get(`${process.env.NEXT_PUBLIC_BASE_URL}/subcategories`)
      .then(response => {
        if (response.data.success) {
          const subCategoriesData = response.data.data
          setSubcategories(subCategoriesData)
        }
      })
      .catch(error => {
        console.error('Error:', error.message)
      })
    axios
      .get(`${process.env.NEXT_PUBLIC_BASE_URL}/boards`)
      .then(response => {
        if (response.data.success) {
          const boardsData = response.data.data
          setBoards(boardsData)
        }
      })
      .catch(error => {
        console.error('Error:', error.message)
      })
    axios
      .get(`${process.env.NEXT_PUBLIC_BASE_URL}/categories`)
      .then(response => {
        if (response.data.success) {
          const categoriesData = response.data.data
          setCategories(categoriesData)
        }
      })
      .catch(error => {
        console.error('Error:', error.message)
      })
      .finally(() => {
        setLoading(false)
      })
  }
  const handleCategoryChange = (event: any) => {
    const category = event.target.value
    axios
      .get(`${process.env.NEXT_PUBLIC_BASE_URL}/boards?category=${category}`)
      .then(response => {
        if (response.data.success) {
          const boardsData = response.data.data

          setBoards(boardsData)
        }
      })
      .catch(error => {
        console.error('Error:', error.message)
      })
  }
  const handleBoardChange = (event: any) => {
    const board = event.target.value
    axios
      .get(`${process.env.NEXT_PUBLIC_BASE_URL}/subcategories?board=${board}`)
      .then(response => {
        if (response.data.success) {
          const boardsData = response.data.data

          setSubcategories(boardsData)
        }
      })
      .catch(error => {
        console.error('Error:', error.message)
      })
  }
  const handleSubcategoryChange = (event: any) => {
    const subcategory = event.target.value
    axios
      .get(`${process.env.NEXT_PUBLIC_BASE_URL}/subjects?subcategory=${subcategory}`)
      .then(response => {
        if (response.data.success) {
          const boardsData = response.data.data

          setSubjects(boardsData)
        }
      })
      .catch(error => {
        console.error('Error:', error.message)
      })
  }
  const handleDelete = (chapterId: string) => {
    axios
      .delete(`${process.env.NEXT_PUBLIC_BASE_URL}/chapters/${chapterId}`)
      .then(response => {
        if (response.data.success) {
          handleRefresh()
        }
      })
      .catch(error => {
        console.error('Error:', error.message)
      })
  }

  const handleUpdate = (chapterId: string, updatedData: any) => {
    const formData = new FormData()
    formData.append('category', updatedData.category)
    formData.append('status', updatedData.status)
    formData.append('subcategory', updatedData.subcategory)
    formData.append('subject', updatedData.subject)
    formData.append('board', updatedData.board)
    formData.append('chapter', updatedData.chapter)

    axios
      .put(`${process.env.NEXT_PUBLIC_BASE_URL}/chapters/${chapterId}`, formData, {
        headers: {
          'Content-Type': 'application/json'
        }
      })
      .then(response => {
        if (response.data.success) {
          handleRefresh()
        }
      })
      .catch(error => {
        console.error('Error:', error.message)
      })
  }
  useEffect(() => {
    handleRefresh()
  }, [])

  return (
    <Card>
      {isLoading ? <CircularProgress /> : null}
      {chapters.length ? (
        <ChaptersTable
          data={chapters}
          subjects={subjects}
          subcategories={subcategories}
          boards={boards}
          onDelete={handleDelete}
          onAdd={handleAddNewRecord}
          onUpdate={handleUpdate}
          onRefresh={handleRefresh}
          categories={categories}
          handleCategoryChange={handleCategoryChange}
          handleBoardChange={handleBoardChange}
          handleSubcategoryChange={handleSubcategoryChange}
        />
      ) : null}
    </Card>
  )
}

export default Chapters
