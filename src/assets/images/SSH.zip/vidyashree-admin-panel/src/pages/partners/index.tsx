// ** React Imports
import { useEffect, useState } from 'react'

// ** MUI Imports
import Card from '@mui/material/Card'

// ** Third Party Styles Imports
import 'react-datepicker/dist/react-datepicker.css'
import PartnersTable from 'src/views/partners/PartnersTable'
import axios from 'axios'

const Partners = () => {
  // ** State

  const [partners, setPartners] = useState([])
  const handleAddNewRecord = async (data: any) => {
    // Assuming you have a server endpoint to handle MongoDB insertion
    const formData = new FormData()
    formData.append('name', data.name)
    formData.append('status', data.status)
    formData.append('image', data.image[0])
    try {
      const config = {
        method: 'post',
        maxBodyLength: Infinity,
        url: `${process.env.NEXT_PUBLIC_BASE_URL}/partners`,
        headers: {
          Accept: '*/*',

          // 'Authorization': 'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VybmFtZSI6IlRlc3QgVXNlciAxIiwiZW1haWwiOiJ0ZXN0QGdhbWlsLmNvbSIsInJvbGUiOjEsImlhdCI6MTcwNjYyODM3NywiZXhwIjoxNzA2NzE0Nzc3fQ.YFhNEXjXcmGPcXvlO9JQ1_yRJsSTDpz7DaV8oNt8V0c',
          'Content-Type': 'multipart/form-data'
        },
        data: formData
      }

      await axios.request(config)
      handleRefresh()
    } catch (error: any) {
      console.log(error.response.data.message)
    }
  }
  const handleRefresh = () => {
    axios
      .get(`${process.env.NEXT_PUBLIC_BASE_URL}/partners`)
      .then(response => {
        if (response.data.success) {
          const partnerData = response.data.data
          setPartners(partnerData)
        }
      })
      .catch(error => {
        console.error('Error:', error.message)
      })
  }

  const handleDelete = (partnerId: string) => {
    axios
      .delete(`${process.env.NEXT_PUBLIC_BASE_URL}/partners/${partnerId}`)
      .then(response => {
        if (response.data.success) {
          handleRefresh()
        }
      })
      .catch(error => {
        console.error('Error:', error.message)
      })
  }
  const handleUpdate = (partnerId: string, updatedData: any) => {
    const formData = new FormData()
    formData.append('name', updatedData.name)
    formData.append('status', updatedData.status)

    if (updatedData.image && updatedData.image.length > 0) {
      formData.append('image', updatedData.image[0]) // Assuming only one file is uploaded
    }

    axios
      .put(`${process.env.NEXT_PUBLIC_BASE_URL}/partners/${partnerId}`, formData, {
        headers: {
          'Content-Type': 'multipart/form-data'
        }
      })
      .then(response => {
        if (response.data.success) {
          handleRefresh()
        }
      })
      .catch(error => {
        console.error('Error:', error.message)
      })
  }
  useEffect(() => {
    handleRefresh()
  }, [])

  return (
    <Card>
      {partners.length ? (
        <PartnersTable
          data={partners}
          onDelete={handleDelete}
          onAdd={handleAddNewRecord}
          onUpdate={handleUpdate}
          onRefresh={handleRefresh}
        />
      ) : null}
    </Card>
  )
}

export default Partners
