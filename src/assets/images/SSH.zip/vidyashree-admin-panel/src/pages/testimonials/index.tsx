// ** React Imports
import { useEffect, useState } from 'react'

// ** MUI Imports
import Card from '@mui/material/Card'

// ** Third Party Styles Imports
import 'react-datepicker/dist/react-datepicker.css'
import TestimonialsTable from 'src/views/testimonials/TestimonialTable'
import axios from 'axios'

const Testimonials = () => {
  const [testimonials, setTestimonials] = useState([])
  const handleAddNewRecord = async (data: any) => {
    // Assuming you have a server endpoint to handle MongoDB insertion
    try {
      const config = {
        method: 'post',
        maxBodyLength: Infinity,
        url: `${process.env.NEXT_PUBLIC_BASE_URL}/testimonials`,
        headers: {
          Accept: '*/*',

          // 'Authorization': 'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VybmFtZSI6IlRlc3QgVXNlciAxIiwiZW1haWwiOiJ0ZXN0QGdhbWlsLmNvbSIsInJvbGUiOjEsImlhdCI6MTcwNjYyODM3NywiZXhwIjoxNzA2NzE0Nzc3fQ.YFhNEXjXcmGPcXvlO9JQ1_yRJsSTDpz7DaV8oNt8V0c',
          'Content-Type': 'application/json'
        },
        data: data
      }

      await axios.request(config)
      handleRefresh()
    } catch (error: any) {
      console.log(error.response.data.message)
    }
  }
  const handleRefresh = () => {
    axios
      .get(`${process.env.NEXT_PUBLIC_BASE_URL}/testimonials`)
      .then(response => {
        console.log(response.data)
        if (response.data.success) {
          const testimonialData = response.data.data
          const dataArray: any = [...testimonialData]
          setTestimonials(dataArray)
        }
      })
      .catch(error => {
        console.error('Error:', error.message)
      })
  }
  const handleDelete = (testimonialId: string) => {
    axios
      .delete(`${process.env.NEXT_PUBLIC_BASE_URL}/testimonials/${testimonialId}`)
      .then(response => {
        if (response.data.success) {
          handleRefresh()
        }
      })
      .catch(error => {
        console.error('Error:', error.message)
      })
  }
  const handleUpdate = (testimonialId: string, updatedData: any) => {
    axios
      .put(`${process.env.NEXT_PUBLIC_BASE_URL}/testimonials/${testimonialId}`, updatedData)
      .then(response => {
        if (response.data.success) {
          handleRefresh()
        }
      })
      .catch(error => {
        console.error('Error:', error.message)
      })
  }
  useEffect(() => {
    handleRefresh()
  }, [])

  return (
    <Card>
      {testimonials.length ? (
        <TestimonialsTable
          data={testimonials}
          onDelete={handleDelete}
          onUpdate={handleUpdate}
          onRefresh={handleRefresh}
          onAdd={handleAddNewRecord}
        />
      ) : null}
    </Card>
  )
}

export default Testimonials
