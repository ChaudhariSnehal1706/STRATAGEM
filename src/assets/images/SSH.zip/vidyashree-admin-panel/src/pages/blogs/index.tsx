// ** React Imports
import { useEffect, useState } from 'react'

// ** MUI Imports

// ** Third Party Styles Imports
import 'react-datepicker/dist/react-datepicker.css'
import axios from 'axios'
import BlogTable from './../../views/blog/BlogTable'
import Card from '@mui/material/Card'
import { CircularProgress } from '@mui/material'

const Blogs = () => {
  // ** State

  const [blogs, setBlogs] = useState([])
  const [isLoading, setLoading] = useState(true)
  const [categories, setBlogCategories] = useState([])
  const handleAddNewRecord = async (data: any) => {
    // Assuming you have a server endpoint to handle MongoDB insertion
    const formData = new FormData()
    formData.append('image', data.image[0])
    formData.append('author', data.author)
    formData.append('blogDate', data.blogDate)
    formData.append('category', data.category)
    formData.append('content', data.content)
    formData.append('likes', data.likes)
    formData.append('tags', data.tags)
    formData.append('title', data.title)
    console.log(formData)
    try {
      const config = {
        method: 'post',
        maxBodyLength: Infinity,
        url: `${process.env.NEXT_PUBLIC_BASE_URL}/blogs`,
        headers: {
          'Content-Type': 'multipart/form-data',

          Accept: '*/*'
        },
        data: formData
      }

      await axios.request(config)
      handleRefresh()
    } catch (error: any) {
      console.log(error.response.data.message)
    }
  }
  const handleRefresh = () => {
    setLoading(true)
    axios
      .get(`${process.env.NEXT_PUBLIC_BASE_URL}/blogs`)
      .then(response => {
        if (response.data.success) {
          const blogData = response.data.data
          setBlogs(blogData.blogs_data)
        }
      })
      .catch(error => {
        console.error('Error:', error.message)
      })
    axios
      .get(`${process.env.NEXT_PUBLIC_BASE_URL}/blogs-categories`)
      .then(response => {
        if (response.data.success) {
          const categoriesData = response.data.data
          setBlogCategories(categoriesData)
        }
      })
      .catch(error => {
        console.error('Error:', error.message)
      })
      .finally(() => {
        setLoading(false)
      })
  }

  const handleDelete = (blogId: string) => {
    axios
      .delete(`${process.env.NEXT_PUBLIC_BASE_URL}/blogs/${blogId}`)
      .then(response => {
        if (response.data.success) {
          handleRefresh()
        }
      })
      .catch(error => {
        console.error('Error:', error.message)
      })
  }
  const handleUpdate = async (blogId: string, updatedData: any) => {
    const formData = new FormData()
    formData.append('image', updatedData.image[0])
    formData.append('author', updatedData.author)
    formData.append('blogDate', updatedData.blogDate)
    formData.append('category', updatedData.category)
    formData.append('content', updatedData.content)
    formData.append('likes', updatedData.likes)
    formData.append('tags', updatedData.tags)
    formData.append('title', updatedData.title)

    const config = {
      method: 'put',
      maxBodyLength: Infinity,
      url: `${process.env.NEXT_PUBLIC_BASE_URL}/blogs/${blogId}`,
      headers: {
        'Content-Type': 'multipart/form-data',
        Accept: '*/*'
      },
      data: formData
    }

    await axios.request(config)
    handleRefresh()

    // axios
    //   .put(`${process.env.NEXT_PUBLIC_BASE_URL}/blogs/${blogId}`, updatedData,)
    //   .then(response => {
    //     if (response.data.success) {
    //       handleRefresh()
    //     }
    //   })
    //   .catch(error => {
    //     console.error('Error:', error.message)
    //   })
  }
  useEffect(() => {
    handleRefresh()
  }, [])

  return (
    <Card>
      {isLoading ? <CircularProgress /> : null}
      <BlogTable
        data={blogs}
        categories={categories}
        onDelete={handleDelete}
        onAdd={handleAddNewRecord}
        onUpdate={handleUpdate}
        onRefresh={handleRefresh}
      />
    </Card>
  )
}

export default Blogs
