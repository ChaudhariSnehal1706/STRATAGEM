// pages/index.js
import React, { ChangeEvent, ElementType, useEffect, useState } from 'react'
import {
  TextField,
  Button,
  Typography,
  Box,
  ButtonProps,
  FormControl,
  InputLabel,
  MenuItem,
  Select,
  styled
} from '@mui/material'
import axios from 'axios'

import dynamic from 'next/dynamic'
import { EditorProps } from 'react-draft-wysiwyg'

// import { Editor } from 'react-draft-wysiwyg'
import { EditorState, convertToRaw } from 'draft-js'
import draftToHtml from 'draftjs-to-html'

const Editor = dynamic<EditorProps>(() => import('react-draft-wysiwyg').then(mod => mod.Editor), { ssr: false })
const ButtonStyled = styled(Button)<ButtonProps & { component?: ElementType; htmlFor?: string }>(({ theme }) => ({
  [theme.breakpoints.down('sm')]: {
    width: '100%',
    textAlign: 'center'
  }
}))
const ImgStyled = styled('img')(({ theme }) => ({
  width: 120,
  height: 120,
  marginRight: theme.spacing(6.25),
  borderRadius: theme.shape.borderRadius
}))
const ResetButtonStyled = styled(Button)<ButtonProps>(({ theme }) => ({
  marginLeft: theme.spacing(4.5),
  [theme.breakpoints.down('sm')]: {
    width: '100%',
    marginLeft: 0,
    textAlign: 'center',
    marginTop: theme.spacing(4)
  }
}))
export default function AddForm(props: any) {
  const { initialData } = props
  const [formData, setFormData] = useState(initialData)
  const [categories, setCategories] = useState<any[]>([])
  const [imgSrc, setImgSrc] = useState<string>('/images/avatars/1.png')
  const [editorState, setEditorState] = useState(EditorState.createEmpty())
  const fetchCategories = async () => {
    try {
      const response = await axios.get(`${process.env.NEXT_PUBLIC_BASE_URL}/blogs-categories`) // Use Axios for GET request
      console.log(response)
      setCategories(response.data.data) // Assuming response.data is the array of categories
    } catch (error) {
      console.error('Error fetching categories:', error)

      // Handle error
    }
  }
  useEffect(() => {
    fetchCategories()
  }, [])

  // const onChange = (file: ChangeEvent) => {
  //     const reader = new FileReader()
  //     const { files } = file.target as HTMLInputElement
  //     if (files && files.length !== 0) {
  //         reader.onload = () => setImgSrc(reader.result as string)
  //         formData?.image = files
  //         reader.readAsDataURL(files[0])
  //     }
  // }
  // const handleChange = (e: any) => {
  //     const { name, value } = e.target;
  //     setFormData((prevData) => ({
  //         ...prevData,
  //         [name]: value,
  //     }));
  // };

  const handleChange = (e: any) => {
    const { name, value } = e.target
    setFormData({ ...formData, [name]: value })
  }
  const handleSave = async (event: any) => {
    event.preventDefault()
    try {
      formData.likes = Number(formData?.likes)

      //const response: AxiosResponse = await axios.post(`${process.env.NEXT_PUBLIC_BASE_URL}/blogs`, formData) // Use Axios for POST request
      // Redirect to the previous page or any other page after update
      // router.back(); // Redirect to the previous page
    } catch (error) {
      console.error('Error adding data:', error)

      // Handle error
    }
  }

  const onChange = (file: ChangeEvent) => {
    const reader = new FileReader()
    const { files } = file.target as HTMLInputElement
    if (files && files.length !== 0) {
      reader.onload = () => setImgSrc(reader.result as string)
      formData.image = files
      reader.readAsDataURL(files[0])
    }
  }
  const handleEditorChange = (newState: EditorState) => {
    setEditorState(newState)
    const contentState = newState.getCurrentContent()

    // Convert contentState to raw JSON format if needed
    const rawContent = convertToRaw(contentState)

    // Convert rawContent to HTML
    const htmlContent = draftToHtml(rawContent)

    // Update formData with the htmlContent
    setFormData({ ...formData, content: htmlContent })
  }

  return (
    <form>
      <TextField
        autoFocus
        margin='dense'
        id='title'
        name='title'
        label='Title'
        type='text'
        fullWidth
        variant='outlined'
        value={formData?.title}
        onChange={handleChange}
      />
      <Box sx={{ display: 'flex', alignItems: 'center' }}>
        <ImgStyled src={imgSrc} alt='Profile Pic' />
        <Box>
          <ButtonStyled component='label' variant='contained' htmlFor='account-settings-upload-image'>
            Upload New Photo
            <input
              hidden
              type='file'
              onChange={onChange}
              accept='image/png, image/jpeg'
              id='account-settings-upload-image'
            />
          </ButtonStyled>
          <ResetButtonStyled color='error' variant='outlined' onClick={() => setImgSrc('/images/avatars/1.png')}>
            Reset
          </ResetButtonStyled>
          <Typography variant='body2' sx={{ marginTop: 5 }}>
            Allowed PNG or JPEG. Max size of 800K.
          </Typography>
        </Box>
      </Box>
      <TextField
        margin='dense'
        id='author'
        name='author'
        label='Author Name'
        type='text'
        fullWidth
        variant='outlined'
        value={formData?.author}
        onChange={handleChange}
      />
      <FormControl fullWidth margin='dense'>
        <InputLabel id='form-layouts-separator-select-label'>Categories</InputLabel>
        <Select
          label='Category'
          value={formData?.category}
          id='category'
          name='category'
          fullWidth
          variant='outlined'
          labelId='category'
          onChange={handleChange}
        >
          {categories?.map((c: any) => {
            return (
              <MenuItem key={c._id} value={c._id}>
                {c?.name}
              </MenuItem>
            )
          })}

          {/* <MenuItem value='false'>Inactive</MenuItem> */}
        </Select>
      </FormControl>
      <Editor
        editorState={editorState}
        onEditorStateChange={handleEditorChange}
        editorClassName='editor-class'
        toolbarClassName='toolbar-class'
      />

      <TextField
        margin='dense'
        id='likes'
        name='likes'
        label='Likes'
        type='number'
        fullWidth
        variant='outlined'
        value={formData?.likes}
        onChange={handleChange}
      />
      <TextField
        margin='dense'
        id='tags'
        name='tags'
        label='Tags'
        type='text'
        fullWidth
        variant='outlined'
        value={formData?.tags}
        onChange={handleChange}
      />
      <TextField
        margin='dense'
        id='blogDate'
        name='blogDate'
        label='Blog Date'
        type='date'
        fullWidth
        variant='outlined'
        value={formData?.blogDate}
        onChange={handleChange}
      />

      {/* Add more fields as needed */}

      <Button
        type='submit'
        variant='contained'
        onClick={event => {
          handleSave(event)
        }}
        color='success'
      >
        Save
      </Button>
    </form>
  )
}
