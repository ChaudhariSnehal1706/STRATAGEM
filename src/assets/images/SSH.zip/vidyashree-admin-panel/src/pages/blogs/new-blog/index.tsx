// import { useState } from 'react'
import { useRouter } from 'next/router'
import AddForm from './addFrom'

export default function EditBlog() {
  const router = useRouter()
  const { id } = router.query

  // const [initialData, setInitialData] = useState(null) // Initialize initialData as null

  if (!id) {
    // Check if id or initialData is null
    return <div>Loading...</div>
  }

  return (
    <div>
      <h1>New Blog</h1>
      <AddForm />
    </div>
  )
}
