import { useEffect, useState } from 'react'
import { useRouter } from 'next/router'
import UpdateForm from './updateFrom'

export default function EditBlog() {
  const router = useRouter()
  const { id } = router.query
  const [initialData, setInitialData] = useState(null) // Initialize initialData as null

  useEffect(() => {
    // Fetch initial data using the ID from the params
    const fetchData = async () => {
      try {
        const response = await fetch(`${process.env.NEXT_PUBLIC_BASE_URL}/testseries/${id}`) // Fetch data for a specific blog post using the provided ID
        if (!response.ok) {
          throw new Error('Failed to fetch data')
        }
        const data = await response.json()

        setInitialData(data.data)
      } catch (error) {
        console.error('Error fetching data:', error)
      }
    }

    if (id) {
      fetchData()
    }
  }, [id])
  if (!id || initialData === null) {
    // Check if id or initialData is null
    return <div>Loading...</div>
  }

  return (
    <div>
      <h1>Test Serie</h1>
      <UpdateForm id={id} initialData={initialData} />
    </div>
  )
}
