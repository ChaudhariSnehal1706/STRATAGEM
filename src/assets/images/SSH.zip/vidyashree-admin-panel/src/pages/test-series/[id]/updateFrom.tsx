// components/UpdateForm.js
import { ChangeEvent, ElementType, useEffect, useState } from 'react'
import {
  TextField,
  Button,
  Box,
  ButtonProps,
  Typography,
  styled,
  FormControl,
  InputLabel,
  MenuItem,
  Select
} from '@mui/material'
import { useRouter } from 'next/router'
import 'react-draft-wysiwyg/dist/react-draft-wysiwyg.css'
import axios from 'axios'

const ButtonStyled = styled(Button)<ButtonProps & { component?: ElementType; htmlFor?: string }>(({ theme }) => ({
  [theme.breakpoints.down('sm')]: {
    width: '100%',
    textAlign: 'center'
  }
}))
const ImgStyled = styled('img')(({ theme }) => ({
  width: 120,
  height: 120,
  marginRight: theme.spacing(6.25),
  borderRadius: theme.shape.borderRadius
}))
const ResetButtonStyled = styled(Button)<ButtonProps>(({ theme }) => ({
  marginLeft: theme.spacing(4.5),
  [theme.breakpoints.down('sm')]: {
    width: '100%',
    marginLeft: 0,
    textAlign: 'center',
    marginTop: theme.spacing(4)
  }
}))
export default function UpdateForm({ id, initialData }: any) {
  const router = useRouter()
  const [formData, setFormData] = useState(initialData)
  const [categories, setCategories] = useState<any[]>([])
  const [imgSrc, setImgSrc] = useState<string>('/images/avatars/1.png')
  const [subcategory, setSubcategory] = useState([])
  useEffect(() => {
    setFormData(initialData)
    fetchCategories()
    fetchSubCategories()
    if (initialData.content) {
    }
  }, [initialData])

  const fetchCategories = async () => {
    try {
      const response = await axios.get(`${process.env.NEXT_PUBLIC_BASE_URL}/categories`)
      console.log(response)
      setCategories(response.data.data)
    } catch (error) {
      console.error('Error fetching categories:', error)
    }
  }
  const fetchSubCategories = async () => {
    try {
      const response = await axios.get(`${process.env.NEXT_PUBLIC_BASE_URL}/subcategories`)
      console.log(response)
      setSubcategory(response.data.data)
    } catch (error) {
      console.error('Error fetching categories:', error)
    }
  }
  const handleChange = (e: any) => {
    const { name, value } = e.target
    setFormData({ ...formData, [name]: value })
  }

  const handleSave = async (event: any, id: string) => {
    event.preventDefault()
    try {
      const data = new FormData()
      data.append('image', formData.image[0])
      data.append('name', formData.name)
      data.append('description', formData.description)
      data.append('category', formData.category)
      data.append('subcategory', formData.subcategory)
      data.append('noOfQuestions', formData.noOfQuestions)
      data.append('durationMinutes', formData.durationMinutes)
      data.append('maxMarks', formData.maxMarks)
      data.append('scheduleStartTime', formData.scheduleStartTime)
      data.append('scheduleEndTime', formData.scheduleEndTime)
      data.append('featured_flag', formData.featured_flag)

      const config = {
        method: 'put',
        maxBodyLength: Infinity,
        url: `${process.env.NEXT_PUBLIC_BASE_URL}/testseries/${id}`,
        headers: {
          'Content-Type': 'multipart/form-data',
          Accept: '*/*'
        },
        data: data
      }

      const response = await axios.request(config)
      console.log(response)

      if (response.status == 200) {
        //throw new Error('Failed to update data');
        router.push('/test-series')
      }

      // Redirect to the previous page or any other page after update
      // router.back(); // Redirect to the previous page
    } catch (error) {
      console.error('Error updating data:', error)

      // Handle error
    }
  }

  const onChange = (file: ChangeEvent) => {
    const reader = new FileReader()
    const { files } = file.target as HTMLInputElement
    if (files && files.length !== 0) {
      reader.onload = () => setImgSrc(reader.result as string)
      formData.image = files
      reader.readAsDataURL(files[0])
    }
  }

  // const handleEditorChange = (newState: EditorState) => {
  //   setEditorState(newState)
  //   const contentState = newState.getCurrentContent()

  //   // Convert contentState to raw JSON format if needed
  //   const rawContent = convertToRaw(contentState)

  //   // Convert rawContent to HTML
  //   const htmlContent = draftToHtml(rawContent)

  //   // Update formData with the htmlContent
  //   setFormData({ ...formData, content: htmlContent })
  // }

  return (
    <form>
      <TextField
        autoFocus
        margin='dense'
        id='name'
        name='name'
        label='Name'
        type='text'
        fullWidth
        variant='outlined'
        value={formData?.name}
        onChange={handleChange}
      />
      <Box sx={{ display: 'flex', alignItems: 'center' }}>
        <ImgStyled src={imgSrc} alt='Profile Pic' />
        <Box>
          <ButtonStyled component='label' variant='contained' htmlFor='account-settings-upload-image'>
            Upload New Photo
            <input
              hidden
              type='file'
              onChange={onChange}
              accept='image/png, image/jpeg'
              id='account-settings-upload-image'
            />
          </ButtonStyled>
          <ResetButtonStyled color='error' variant='outlined' onClick={() => setImgSrc('/images/avatars/1.png')}>
            Reset
          </ResetButtonStyled>
          <Typography variant='body2' sx={{ marginTop: 5 }}>
            Allowed PNG or JPEG. Max size of 800K.
          </Typography>
        </Box>
      </Box>
      <TextField
        margin='dense'
        id='description'
        name='description'
        label='Description'
        type='text'
        fullWidth
        variant='outlined'
        value={formData?.description}
        onChange={handleChange}
      />
      <FormControl fullWidth margin='dense'>
        <InputLabel id='form-layouts-separator-select-label'>Categories</InputLabel>
        <Select
          label='Category'
          value={formData?.category}
          id='category'
          name='category'
          fullWidth
          variant='outlined'
          labelId='category'
          onChange={handleChange}
        >
          {categories?.map((c: any) => {
            return (
              <MenuItem key={c._id} value={c._id}>
                {c?.name}
              </MenuItem>
            )
          })}

          {/* <MenuItem value='false'>Inactive</MenuItem> */}
        </Select>
      </FormControl>
      <FormControl fullWidth margin='dense'>
        <InputLabel id='form-layouts-separator-select-label'>Sub Category</InputLabel>
        <Select
          label='SubCategory'
          value={formData?.subcategory}
          id='subcategory'
          name='subcategory'
          fullWidth
          variant='outlined'
          labelId='subcategory'
          onChange={handleChange}
        >
          {subcategory?.map((c: any) => {
            return (
              <MenuItem key={c._id} value={c._id}>
                {c?.name}
              </MenuItem>
            )
          })}

          {/* <MenuItem value='false'>Inactive</MenuItem> */}
        </Select>
      </FormControl>
      {/* <Editor
                editorState={editorState}
                onEditorStateChange={handleEditorChange}
                editorClassName='editor-class'
                toolbarClassName='toolbar-class'
            /> */}

      <TextField
        margin='dense'
        id='noOfQuestions'
        name='noOfQuestions'
        label='No of Questions'
        type='number'
        fullWidth
        variant='outlined'
        value={formData?.noOfQuestions}
        onChange={handleChange}
      />
      <TextField
        margin='dense'
        id='durationMinutes'
        name='durationMinutes'
        label='Duration'
        type='number'
        fullWidth
        variant='outlined'
        value={formData?.durationMinutes}
        onChange={handleChange}
      />
      <TextField
        margin='dense'
        id='maxMarks'
        name='maxMarks'
        label='Max Marks'
        type='number'
        fullWidth
        variant='outlined'
        value={formData?.maxMarks}
        onChange={handleChange}
      />
      <TextField
        required
        margin='dense'
        id='scheduleStartTime'
        name='scheduleStartTime'
        label='Schedule Start Time'
        type='datetime-local'
        fullWidth
        variant='outlined'
        value={formData?.scheduleStartTime}
        onChange={handleChange}
      />
      <InputLabel id='form-layouts-separator-select-label'>Schedule End Time</InputLabel>
      <TextField
        required
        margin='dense'
        id='scheduleEndTime'
        name='scheduleEndTime'
        label='Schedule End Time'
        type='datetime-local'
        fullWidth
        variant='outlined'
        value={formData?.scheduleEndTime}
        onChange={handleChange}
      />
      {initialData ? (
        <FormControl fullWidth margin='dense'>
          <InputLabel id='form-layouts-separator-select-label'>Status</InputLabel>
          <Select
            label='Status'
            value={formData?.status}
            id='status'
            name='status'
            fullWidth
            variant='outlined'
            labelId='status'
            onChange={handleChange}
          >
            <MenuItem value='true'>Active</MenuItem>
            <MenuItem value='false'>Inactive</MenuItem>
          </Select>
        </FormControl>
      ) : null}
      <FormControl fullWidth margin='dense'>
        <InputLabel id='form-layouts-separator-select-label'>Featured Flag</InputLabel>
        <Select
          label='Featured Flag'
          value={formData?.featured_flag}
          id='featured_flag'
          name='featured_flag'
          fullWidth
          variant='outlined'
          labelId='featured_flag'
          onChange={handleChange}
        >
          <MenuItem value='true'>Active</MenuItem>
          <MenuItem value='false'>Inactive</MenuItem>
        </Select>
      </FormControl>
      {/* Add more fields as needed */}

      <Button
        type='submit'
        variant='contained'
        onClick={event => {
          handleSave(event, id)
        }}
        color='success'
      >
        {initialData ? 'Update' : 'Save'}
      </Button>
    </form>
  )
}
