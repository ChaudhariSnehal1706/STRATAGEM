// ** React Imports
import { useEffect, useState } from 'react'

// ** MUI Imports
import Card from '@mui/material/Card'

// ** Third Party Styles Imports
import 'react-datepicker/dist/react-datepicker.css'
import TestSeriesTable from 'src/views/testseries/TestSeriesTable'
import axios from 'axios'

const TestSeries = () => {
  const [categories, setCategories] = useState([])
  const [subcategory, setSubcategory] = useState([])
  const [testseries, setTestSeries] = useState([])
  const handleAddNewRecord = async (data: any) => {
    // Assuming you have a server endpoint to handle MongoDB insertion
    const formData = new FormData()
    formData.append('image', data.image[0])
    formData.append('name', data.name)
    formData.append('description', data.description)
    formData.append('category', data.category)
    formData.append('subcategory', data.subcategory)
    formData.append('noOfQuestions', data.noOfQuestions)
    formData.append('durationMinutes', data.durationMinutes)
    formData.append('maxMarks', data.maxMarks)
    formData.append('scheduleStartTime', data.scheduleStartTime)
    formData.append('scheduleEndTime', data.scheduleEndTime)
    formData.append('featured_flag', data.featured_flag)
    try {
      const config = {
        method: 'post',
        maxBodyLength: Infinity,
        url: `${process.env.NEXT_PUBLIC_BASE_URL}/testseries`,
        headers: {
          Accept: '*/*',

          // 'Authorization': 'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VybmFtZSI6IlRlc3QgVXNlciAxIiwiZW1haWwiOiJ0ZXN0QGdhbWlsLmNvbSIsInJvbGUiOjEsImlhdCI6MTcwNjYyODM3NywiZXhwIjoxNzA2NzE0Nzc3fQ.YFhNEXjXcmGPcXvlO9JQ1_yRJsSTDpz7DaV8oNt8V0c',
          'Content-Type': 'multipart/form-data'
        },
        data: formData
      }

      await axios.request(config)
      handleRefresh()
    } catch (error: any) {
      console.log(error.response.data.message)
    }
  }
  const handleRefresh = () => {
    axios
      .get(`${process.env.NEXT_PUBLIC_BASE_URL}/testseries`)
      .then(response => {
        if (response.data.success) {
          const testSeriesData = response.data.data
          setTestSeries(testSeriesData)
        }
      })
      .catch(error => {
        console.error('Error:', error.message)
      })
    axios
      .get(`${process.env.NEXT_PUBLIC_BASE_URL}/subcategories`)
      .then(response => {
        if (response.data.success) {
          const subCategoriesData = response.data.data
          setSubcategory(subCategoriesData)
        }
      })
      .catch(error => {
        console.error('Error:', error.message)
      })
    axios
      .get(`${process.env.NEXT_PUBLIC_BASE_URL}/categories`)
      .then(response => {
        if (response.data.success) {
          const categoriesData = response.data.data
          setCategories(categoriesData)
        }
      })
      .catch(error => {
        console.error('Error:', error.message)
      })
  }
  const getSubcategories = (category: string) => {
    setSubcategory([])
    axios
      .get(`${process.env.NEXT_PUBLIC_BASE_URL}/subcategories?category=${category}`)
      .then(response => {
        if (response.data.success) {
          const subCategoriesData = response.data.data
          setSubcategory(subCategoriesData)
        }
      })
      .catch(error => {
        console.error('Error:', error.message)
      })
  }
  const handleDelete = (testSeriesID: string) => {
    axios
      .delete(`${process.env.NEXT_PUBLIC_BASE_URL}/testseries/${testSeriesID}`)
      .then(response => {
        if (response.data.success) {
          handleRefresh()
        }
      })
      .catch(error => {
        console.error('Error:', error.message)
      })
  }

  const handleUpdate = async (id: string, updatedData: any) => {
    const formData = new FormData()
    formData.append('image', updatedData.image[0])
    formData.append('name', updatedData.name)
    formData.append('description', updatedData.description)
    formData.append('category', updatedData.category)
    formData.append('subcategory', updatedData.subcategory)
    formData.append('noOfQuestions', updatedData.noOfQuestions)
    formData.append('durationMinutes', updatedData.durationMinutes)
    formData.append('maxMarks', updatedData.maxMarks)
    formData.append('scheduleStartTime', updatedData.scheduleStartTime)
    formData.append('scheduleEndTime', updatedData.scheduleEndTime)
    formData.append('featured_flag', updatedData.featured_flag)

    const config = {
      method: 'put',
      maxBodyLength: Infinity,
      url: `${process.env.NEXT_PUBLIC_BASE_URL}/testseries/${id}`,
      headers: {
        'Content-Type': 'multipart/form-data',
        Accept: '*/*'
      },
      data: formData
    }

    await axios.request(config)
    handleRefresh()
  }
  useEffect(() => {
    handleRefresh()
  }, [])

  return (
    <Card>
      {testseries.length ? (
        <TestSeriesTable
          data={testseries}
          categories={categories}
          subcategory={subcategory}
          onUpdate={handleUpdate}
          onRefresh={handleRefresh}
          onDelete={handleDelete}
          onAdd={handleAddNewRecord}
          onCategoryChange={getSubcategories}
        />
      ) : null}
    </Card>
  )
}

export default TestSeries
