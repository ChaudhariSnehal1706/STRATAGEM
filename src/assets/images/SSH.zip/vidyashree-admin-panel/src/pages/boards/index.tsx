// ** React Imports
import { useEffect, useState } from 'react'

// ** MUI Imports
import Card from '@mui/material/Card'

// ** Third Party Styles Imports
import 'react-datepicker/dist/react-datepicker.css'
import axios from 'axios'
import { CircularProgress } from '@mui/material'
import BoardTable from 'src/views/boards/BoardTable'

const Boards = () => {
  // ** State

  const [boards, setBoards] = useState([])
  const [isLoading, setLoading] = useState(true)

  // const [subcategories, setSubcategories] = useState([])
  const [categories, setCategories] = useState([])
  const handleAddNewRecord = async (data: any) => {
    // Assuming you have a server endpoint to handle MongoDB insertion
    const formData = new FormData()
    formData.append('board', data.board)
    formData.append('status', data.status)
    formData.append('category', data.category)
    try {
      const config = {
        method: 'post',
        maxBodyLength: Infinity,
        url: `${process.env.NEXT_PUBLIC_BASE_URL}/boards`,
        headers: {
          Accept: '*/*',

          // 'Authorization': 'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VybmFtZSI6IlRlc3QgVXNlciAxIiwiZW1haWwiOiJ0ZXN0QGdhbWlsLmNvbSIsInJvbGUiOjEsImlhdCI6MTcwNjYyODM3NywiZXhwIjoxNzA2NzE0Nzc3fQ.YFhNEXjXcmGPcXvlO9JQ1_yRJsSTDpz7DaV8oNt8V0c',
          'Content-Type': 'application/json'
        },
        data: formData
      }

      await axios.request(config)
      handleRefresh()
    } catch (error: any) {
      console.log(error.response.data.message)
    }
  }
  const handleRefresh = () => {
    setLoading(true)
    axios
      .get(`${process.env.NEXT_PUBLIC_BASE_URL}/boards`)
      .then(response => {
        if (response.data.success) {
          const boardsData = response.data.data
          setBoards(boardsData)
        }
      })
      .catch(error => {
        console.error('Error:', error.message)
      })
    axios
      .get(`${process.env.NEXT_PUBLIC_BASE_URL}/categories`)
      .then(response => {
        if (response.data.success) {
          const categoriesData = response.data.data
          setCategories(categoriesData)
        }
      })
      .catch(error => {
        console.error('Error:', error.message)
      })
      .finally(() => {
        setLoading(false)
      })
  }

  const handleDelete = (boardId: string) => {
    axios
      .delete(`${process.env.NEXT_PUBLIC_BASE_URL}/boards/${boardId}`)
      .then(response => {
        if (response.data.success) {
          handleRefresh()
        }
      })
      .catch(error => {
        console.error('Error:', error.message)
      })
  }

  const handleUpdate = (boardId: string, updatedData: any) => {
    const formData = new FormData()
    formData.append('board', updatedData.board)
    formData.append('status', updatedData.status)
    formData.append('category', updatedData.category)
    axios
      .put(`${process.env.NEXT_PUBLIC_BASE_URL}/boards/${boardId}`, formData, {
        headers: {
          'Content-Type': 'application/json'
        }
      })
      .then(response => {
        if (response.data.success) {
          handleRefresh()
        }
      })
      .catch(error => {
        console.error('Error:', error.message)
      })
  }
  useEffect(() => {
    handleRefresh()
  }, [])

  return (
    <Card>
      {isLoading ? <CircularProgress /> : null}
      {boards.length ? (
        <BoardTable
          data={boards}
          onDelete={handleDelete}
          onAdd={handleAddNewRecord}
          onUpdate={handleUpdate}
          onRefresh={handleRefresh}
          categories={categories}
        />
      ) : null}
    </Card>
  )
}

export default Boards
