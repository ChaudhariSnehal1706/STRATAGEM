// ** React Imports
import { useEffect, useState } from 'react'

// ** MUI Imports
import Card from '@mui/material/Card'

// ** Third Party Styles Imports
import 'react-datepicker/dist/react-datepicker.css'
import axios from 'axios'
import FaqTable from 'src/views/faq/FaqTable'
import { CircularProgress } from '@mui/material'

const Faq = () => {
  // ** State

  const [faq, setFaq] = useState([])
  const [isLoading, setLoading] = useState(true)
  const [categories, setCategories] = useState([])
  const handleAddNewRecord = async (data: any) => {
    // Assuming you have a server endpoint to handle MongoDB insertion
    try {
      const config = {
        method: 'post',
        maxBodyLength: Infinity,
        url: `${process.env.NEXT_PUBLIC_BASE_URL}/faq`,
        headers: {
          Accept: '*/*',

          // 'Authorization': 'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VybmFtZSI6IlRlc3QgVXNlciAxIiwiZW1haWwiOiJ0ZXN0QGdhbWlsLmNvbSIsInJvbGUiOjEsImlhdCI6MTcwNjYyODM3NywiZXhwIjoxNzA2NzE0Nzc3fQ.YFhNEXjXcmGPcXvlO9JQ1_yRJsSTDpz7DaV8oNt8V0c',
          'Content-Type': 'application/json'
        },
        data: data
      }

      await axios.request(config)
      handleRefresh()
    } catch (error: any) {
      console.log(error.response.data.message)
    }
  }
  const handleRefresh = () => {
    setLoading(true)
    axios
      .get(`${process.env.NEXT_PUBLIC_BASE_URL}/faq`)
      .then(response => {
        if (response.data.success) {
          const faqData = response.data.data
          setFaq(faqData)
        }
      })
      .catch(error => {
        console.error('Error:', error.message)
      })
    axios
      .get(`${process.env.NEXT_PUBLIC_BASE_URL}/categories`)
      .then(response => {
        if (response.data.success) {
          const categoriesData = response.data.data
          setCategories(categoriesData)
        }
      })
      .catch(error => {
        console.error('Error:', error.message)
      })
      .finally(() => {
        setLoading(false)
      })
  }

  const handleDelete = (faqId: string) => {
    axios
      .delete(`${process.env.NEXT_PUBLIC_BASE_URL}/faq/${faqId}`)
      .then(response => {
        if (response.data.success) {
          handleRefresh()
        }
      })
      .catch(error => {
        console.error('Error:', error.message)
      })
  }
  const handleUpdate = (faqId: string, updatedData: any) => {
    axios
      .put(`${process.env.NEXT_PUBLIC_BASE_URL}/faq/${faqId}`, updatedData)
      .then(response => {
        if (response.data.success) {
          handleRefresh()
        }
      })
      .catch(error => {
        console.error('Error:', error.message)
      })
  }
  useEffect(() => {
    handleRefresh()
  }, [])

  return (
    <Card>
      {isLoading ? <CircularProgress /> : null}
      <FaqTable
        data={faq}
        categories={categories}
        onDelete={handleDelete}
        onAdd={handleAddNewRecord}
        onUpdate={handleUpdate}
        onRefresh={handleRefresh}
      />
    </Card>
  )
}

export default Faq
