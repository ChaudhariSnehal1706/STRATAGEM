// ** React Imports
import { useEffect, useState } from 'react'

// ** MUI Imports
import Card from '@mui/material/Card'

// ** Third Party Styles Imports
import 'react-datepicker/dist/react-datepicker.css'
import axios from 'axios'
import { CircularProgress } from '@mui/material'
import LectureTable from 'src/views/lectures/LectureTable'

const Lectures = () => {
  // ** State

  const [subjects, setSubjects] = useState([])
  const [isLoading, setLoading] = useState(true)
  const [subcategories, setSubcategories] = useState([])
  const [categories, setCategories] = useState([])
  const handleAddNewRecord = async (data: any) => {
    // Assuming you have a server endpoint to handle MongoDB insertion
    const formData = new FormData()
    formData.append('name', data.name)
    formData.append('status', data.status)
    formData.append('image', data.image[0])
    formData.append('subcategory', data.subcategory)
    try {
      const config = {
        method: 'post',
        maxBodyLength: Infinity,
        url: `${process.env.NEXT_PUBLIC_BASE_URL}/subjects`,
        headers: {
          Accept: '*/*',

          // 'Authorization': 'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VybmFtZSI6IlRlc3QgVXNlciAxIiwiZW1haWwiOiJ0ZXN0QGdhbWlsLmNvbSIsInJvbGUiOjEsImlhdCI6MTcwNjYyODM3NywiZXhwIjoxNzA2NzE0Nzc3fQ.YFhNEXjXcmGPcXvlO9JQ1_yRJsSTDpz7DaV8oNt8V0c',
          'Content-Type': 'multipart/form-data'
        },
        data: formData
      }

      await axios.request(config)
      handleRefresh()
    } catch (error: any) {
      console.log(error.response.data.message)
    }
  }
  const handleRefresh = () => {
    setLoading(true)
    axios
      .get(`${process.env.NEXT_PUBLIC_BASE_URL}/subjects`)
      .then(response => {
        if (response.data.success) {
          const subjectData = response.data.data
          setSubjects(subjectData)
        }
      })
      .catch(error => {
        console.error('Error:', error.message)
      })
    axios
      .get(`${process.env.NEXT_PUBLIC_BASE_URL}/subcategories`)
      .then(response => {
        if (response.data.success) {
          const subCategoriesData = response.data.data
          setSubcategories(subCategoriesData)
        }
      })
      .catch(error => {
        console.error('Error:', error.message)
      })
    axios
      .get(`${process.env.NEXT_PUBLIC_BASE_URL}/categories`)
      .then(response => {
        if (response.data.success) {
          const categoriesData = response.data.data
          setCategories(categoriesData)
        }
      })
      .catch(error => {
        console.error('Error:', error.message)
      })
      .finally(() => {
        setLoading(false)
      })
  }

  const handleDelete = (subjectId: string) => {
    axios
      .delete(`${process.env.NEXT_PUBLIC_BASE_URL}/subjects/${subjectId}`)
      .then(response => {
        if (response.data.success) {
          handleRefresh()
        }
      })
      .catch(error => {
        console.error('Error:', error.message)
      })
  }

  const handleUpdate = (subjectId: string, updatedData: any) => {
    const formData = new FormData()
    formData.append('name', updatedData.name)
    formData.append('status', updatedData.status)

    if (updatedData.image && updatedData.image.length > 0) {
      formData.append('image', updatedData.image[0]) // Assuming only one file is uploaded
    }
    formData.append('subcategory', updatedData.subcategory)
    axios
      .put(`${process.env.NEXT_PUBLIC_BASE_URL}/subjects/${subjectId}`, formData, {
        headers: {
          'Content-Type': 'multipart/form-data'
        }
      })
      .then(response => {
        if (response.data.success) {
          handleRefresh()
        }
      })
      .catch(error => {
        console.error('Error:', error.message)
      })
  }
  useEffect(() => {
    handleRefresh()
  }, [])

  return (
    <Card>
      {isLoading ? <CircularProgress /> : null}
      {subjects.length ? (
        <LectureTable
          data={subjects}
          subcategories={subcategories}
          onDelete={handleDelete}
          onAdd={handleAddNewRecord}
          onUpdate={handleUpdate}
          onRefresh={handleRefresh}
          categories={categories}
        />
      ) : null}
    </Card>
  )
}

export default Lectures
